# Phase 5 — Premium Local Interaction Design

## Selected Reminder Model

Salary, bill, budget, and savings reminders are scheduled locally on the device. A salary-day and optional salary-eve reminder can reach the user without an internet connection. Actual salary, recurring-bill, and automatic-savings ledger processing remains part of the existing local startup refresh, where its cycle identifiers prevent duplicates. A reminder is therefore a user-experience layer, never the accounting source of truth.

## Sound and Motion Boundaries

Short bundled MP3 clips provide optional button, transaction, salary, and goal-completion feedback. Playback is best-effort only: a disabled sound preference, muted device, system interruption, or playback error never prevents a save, delete, salary refresh, or calculation. The app does not change device volume, audio focus policy, or Do Not Disturb state.

Motion is brief and informative: balance numbers crossfade between values, rows enter or leave gently, and progress fills animate on appearance. Reduced-motion preferences replace non-essential movement with immediate state updates. Goal and salary celebrations are emitted only when stored milestone state records a genuine transition.

## Local Event State

Phase 5 adds only additive preference and event-state fields. Settings cover a master sound switch plus individual categories, motion enablement, salary reminder timing, bill lead days, and budget/savings notifications. Local milestone IDs prevent a single salary cycle, bill reminder, budget threshold, savings percentage, or goal completion from repeatedly triggering.
