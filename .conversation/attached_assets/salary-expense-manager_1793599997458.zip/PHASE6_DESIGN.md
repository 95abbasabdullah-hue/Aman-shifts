# Phase 6 — Usability and Reset Compatibility Plan

## Financial Safety

Dashboard summary figures remain derived values. Salary, fixed bills, variable expenses, and savings are interactive navigation targets only: each takes the user to the underlying editable local record or management screen. **Available to spend** supports a deliberate target adjustment from the main screen: the app calculates the difference and stores one labeled local income or expense adjustment transaction rather than overwriting the derived amount or changing any earlier record.

## Form Editing

Descriptions are optional for all financial record types. When absent, a type-appropriate local fallback label is stored or rendered so history remains readable without blocking a valid amount, category, account, or date. User-selectable transaction, bill, savings, and recurring-expense dates use a device-native calendar picker. Salary day remains a day-of-month setting because it drives the salary-cycle algorithm.

## Reset Boundary

Reset Everything is the only operation that clears local financial data. It requires two explicit confirmations, first warns of permanent local deletion, and then cancels all app-scheduled reminders before removing the stored finance snapshot. The in-memory state changes to the empty snapshot, routing returns to onboarding, and the next local refresh starts from a clean configuration.
