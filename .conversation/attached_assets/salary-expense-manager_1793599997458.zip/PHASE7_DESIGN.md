# Phase 7 — Deletion and Back Navigation Plan

## Deletion Safety

Deleting a transaction must first persist a ledger with the target entry removed. If it belongs to an internal transfer, both linked transfer entries are removed atomically. The editor navigates away only after the deletion promise succeeds, ensuring the dashboard and transaction history react to the persisted snapshot rather than stale in-memory state.

## Android Back Behavior

Normal back navigation remains owned by the existing route stack. The root Home tab alone intercepts Android back presses and offers an exit confirmation. Nested routes, modal dialogs, date pickers, and other tabs handle back first through their normal component or navigation behavior. The confirmation dismisses on Cancel and exits only after explicit Exit confirmation; neither action mutates local financial data.
