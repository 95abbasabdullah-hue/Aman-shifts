# Phase 8 Stability Notes

This maintenance update leaves the local finance snapshot schema, storage key, migrations, calculations, notifications, sounds, backups, and reset behavior unchanged. Existing on-device financial records therefore remain in place.

Keyboard reliability is protected by disabling the experimental React Compiler runtime for this Expo configuration and by using one shared, forwarded-ref `AppTextInput` that stays editable unless a screen explicitly disables it. Amount, currency, description, note, and setup fields continue to use their existing controlled local state.

Transaction deletion now uses an in-app confirmation sheet rather than a platform-alert callback. The confirmed transaction ID is deleted only after local persistence completes; linked transfer rows are still removed atomically. The editor returns to the prior screen where possible and otherwise replaces itself with the Transactions ledger for direct-link entry.
