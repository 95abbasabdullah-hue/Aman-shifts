# Final QA and Release-Readiness Plan

## Scope and Data-Preservation Rule

This final pass is additive. Existing Phase 1, Phase 2, and Phase 3 data remains in the local snapshot and is migrated through additive defaults only. No audit task may reset, recreate, or clear the local store. Backup restore remains user-confirmed and validates the versioned payload before it changes stored data.

## Regression Priorities

| Area | Final acceptance check |
|---|---|
| Core accounting | Salary minus fixed bills, net savings, and variable expenses equals available spending. Account transfers alter only the relevant account balances. |
| Calendar logic | Salary cycles and recurring entries are correct for February, 30/31-day months, and payment days 1, 15, 27–31 without duplicate entries. |
| Persistence | Local records survive hydration, process restart, and all supported migration paths. |
| Offline operation | Accounting, search, reporting, backup preparation, restore validation, and settings do not make a network request. |
| Restore safety | Invalid files fail before persistence; users explicitly choose merge or replace. |
| Local privacy | No login, remote database, API key, analytics endpoint, or cloud synchronisation is introduced. |
| Release checks | Type checking, linting, and deterministic tests complete before a checkpoint is created. |

## Android Build Boundary

The managed project is prepared for Android release metadata and local-notification configuration. Android binary generation is intentionally initiated through the workspace **Publish** action after the final checkpoint rather than through a manual sandbox APK build. This avoids resource exhaustion and lets the managed build process produce the distributable APK/AAB.
