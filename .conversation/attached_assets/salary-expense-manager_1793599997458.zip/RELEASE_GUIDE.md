# Salary & Expense Manager — Release Guide

## Release Metadata

The application display name is **Salary & Expense Manager**. Its Android package is `com.app.salaryexpensemanager`, the application version is `1.0.0`, and the Android version code is `1`. The launcher, splash, favicon, and adaptive Android icon all use the project’s custom finance icon.

The Android configuration requests only the notification permission, which is used only after a user enables local reminders. The application does not require an account, a cloud database, an API key, or an online exchange-rate service.

## Validate Before Building

Run the project quality commands from the project folder before starting a managed Android build:

```bash
pnpm test
pnpm lint
pnpm check
```

Do not run manual Android Gradle, APK, or AAB builds in the sandbox. After a checkpoint has been created, use the workspace **Publish** control to initiate the managed Android build flow and obtain the available Android artifacts. This avoids local resource exhaustion and uses the release configuration in `app.config.ts`.

## Install and Test Offline

Install the generated testing APK using the Android device’s normal installer flow. Then enable airplane mode and exercise salary setup, expense and income entry, accounts, transfers, recurring expenses, savings, budgets, statistics, transaction search, and settings. These workflows operate against local device storage and do not depend on a network connection.

## Create a Backup

Open **More → Backup, restore & privacy → Export local backup**. The app writes a versioned JSON backup locally and opens the device share sheet to choose a destination. The file includes settings, salary data, transactions, bills, accounts, budgets, savings goals, currencies, and recurring rules.

## Restore a Backup

Open **More → Backup, restore & privacy → Select backup to restore**. The app validates the selected file before showing a decision. Choose **Merge** to keep local records absent from the backup, or choose **Replace** only when the backup should become the complete local dataset. Both choices require an explicit confirmation.

## Update Without Losing Data

Install a newer build that retains the same Android package identifier. The app uses additive local snapshot migrations: prior records are preserved and newer fields receive safe defaults. Never clear application storage while updating. For additional protection, export a backup before installing any major update.
