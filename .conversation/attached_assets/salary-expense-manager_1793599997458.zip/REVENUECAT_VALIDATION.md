# RevenueCat integration validation

Date: 2026-11-02

## Passed

- Baseline and updated TypeScript checks: `pnpm check`.
- Focused tests: 20 passed across RevenueCat, Premium access and preview navigation.
- Full test suite: 128 passed, 1 pre-existing skipped auth test; 38 suites passed, 1 skipped.
- Changed TypeScript/TSX and plugin ESLint: no lint errors. Node emitted the existing module-type warning for eslint.config.js.
- Expo config introspection: Android package `com.app.salaryexpensemanager`; generated MainActivity launchMode `singleTop`.
- Android Metro export: succeeded, 1,998 modules, Hermes bundle produced. This verifies bundling, not native compilation, signing, installation or purchases.

The first bundle attempt used an isolated dependency layout imposed by the environment's package-manager wrapper and could not resolve NativeWind's CSS interop runtime. Reinstalling with the repository's existing `node-linker=hoisted` setting resolved it. No dependency versions, package.json, or pnpm lockfile were changed.

## Not verified

- Dashboard ownership of the embedded public Google Play SDK key.
- Live RevenueCat Offering `default`, product/base-plan mapping, and service-account credentials.
- Live product attachment to the confirmed `salary_manager_pro` entitlement.
- Google Play prices, countries, product activation, license testers or release tracks.
- Native-device UI layout and Google Play purchase, cancellation, pending-payment, expiry and restoration flows.
- Native Gradle build, upload signing or AAB generation.

The 15 new billing tests mock the SDK. They prove adapter behavior under simulated responses, not Google Play connectivity. Local unit tests, static checking and successful bundling are not a claim that real payments are activated.

## Review notes

- App startup already wrapped the app in PremiumAccessProvider; it remains in place.
- Store entitlement is the only input to Premium gates. No free Premium toggle was added.
- Existing public key, entitlement, offering and package identifiers are preserved.
- Concurrent SDK initialization is shared; failed initialization can retry.
- Unsupported platforms do not configure the Google Play SDK or simulate a Premium purchase.
- Offering errors do not suppress valid CustomerInfo or restored access.
- Missing default Offering cannot silently fall back to selling another Offering.
- Foreground and paywall refreshes use the SDK's CustomerInfo caching policy. Access changes are not claimed to be instantaneous push notifications from the dashboard.
- Store reads and mutations are serialized at the provider; stale snapshots cannot overwrite a newer entitlement event.
- Cancellation and pending payment do not grant access.
- Effects clean up JS subscribers and the AppState subscription. The module deliberately maintains one SDK listener.
- Paywall content scrolls, actions have accessibility labels, status changes announce politely, and buttons disable while a request is running.
- Restoring and managing subscriptions remain accessible for active subscribers.
- Google Play launches externally for subscription management; link failures have a visible fallback.

See REVENUECAT_SETUP_AR.md for account configuration and device acceptance checks.
