import { Tabs, usePathname, useRouter } from "expo-router";
import { useMemo } from "react";
import { PanResponder, Platform, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useReducedMotion } from "@/components/finance-motion";
import { useFinance } from "@/lib/finance/provider";
import { adjacentBottomTabRoute } from "@/lib/navigation/bottom-tab-swipe";
import { pageTransition } from "@/lib/navigation/page-transitions";

function activeTabPath(pathname: string) {
  if (pathname === "/" || pathname === "/index") return "/";
  return ["/transactions", "/bills", "/savings", "/accounts", "/more"].find((route) => pathname === route) ?? "";
}

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const pathname = usePathname();
  const { isReady, snapshot } = useFinance();
  const reducedMotion = useReducedMotion();
  const animation = pageTransition(isReady && snapshot.settings.animationEffectsEnabled, reducedMotion);
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  const tabBarHeight = 56 + bottomPadding;
  const swipeHandlers = useMemo(() => PanResponder.create({
    onMoveShouldSetPanResponder: (_, gesture) => Math.abs(gesture.dx) > 18 && Math.abs(gesture.dx) > Math.abs(gesture.dy),
    onPanResponderRelease: (_, gesture) => {
      const nextRoute = adjacentBottomTabRoute(activeTabPath(pathname), gesture.dx);
      if (nextRoute) router.replace(nextRoute as never);
    },
  }).panHandlers, [pathname, router]);

  return <View style={{ flex: 1 }} {...swipeHandlers}><Tabs screenOptions={{ animation, tabBarActiveTintColor: colors.tint, headerShown: false, tabBarButton: HapticTab, tabBarStyle: { paddingTop: 8, paddingBottom: bottomPadding, height: tabBarHeight, backgroundColor: colors.surface, borderTopColor: colors.border, borderTopWidth: 1 } }}><Tabs.Screen name="index" options={{ title: "Home", tabBarIcon: ({ color }) => <IconSymbol size={28} name="house.fill" color={color} /> }} /><Tabs.Screen name="transactions" options={{ title: "Transactions", tabBarIcon: ({ color }) => <IconSymbol size={26} name="list.bullet" color={color} /> }} /><Tabs.Screen name="bills" options={{ title: "Bills", tabBarIcon: ({ color }) => <IconSymbol size={26} name="doc.text.fill" color={color} /> }} /><Tabs.Screen name="savings" options={{ title: "Savings", tabBarIcon: ({ color }) => <IconSymbol size={26} name="target" color={color} /> }} /><Tabs.Screen name="accounts" options={{ title: "Accounts", tabBarIcon: ({ color }) => <IconSymbol size={25} name="creditcard.fill" color={color} /> }} /><Tabs.Screen name="more" options={{ title: "More", tabBarIcon: ({ color }) => <IconSymbol size={26} name="ellipsis.circle.fill" color={color} /> }} /></Tabs></View>;
}
