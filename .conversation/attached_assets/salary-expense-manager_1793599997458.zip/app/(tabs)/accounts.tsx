import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useRouter } from "expo-router";
import { FlatList, Text, TouchableOpacity, View } from "react-native";
import { EmptyState, LoadingScreen } from "@/components/finance-ui";
import { ScreenContainer } from "@/components/screen-container";
import { useAndroidExitConfirmation } from "@/hooks/use-android-exit-confirmation";
import { formatMoney } from "@/lib/finance/format";
import { useFinance } from "@/lib/finance/provider";

const accountIcon = { bank: "account-balance", cash: "payments", savings: "savings", credit_card: "credit-card", other: "wallet" } as const;

export default function AccountsScreen() {
  const router = useRouter();
  useAndroidExitConfirmation();
  const { isReady, accounts, snapshot } = useFinance();
  if (!isReady) return <LoadingScreen />;
  return <ScreenContainer className="px-5"><FlatList data={accounts} keyExtractor={(item) => item.id} contentContainerStyle={{ paddingTop: 10, paddingBottom: 28, gap: 10, flexGrow: 1 }} ListHeaderComponent={<View className="mb-4 gap-4"><View className="flex-row items-start justify-between"><View className="flex-1 mr-3"><Text className="text-[30px] font-bold tracking-tight text-foreground">Accounts</Text><Text className="mt-1 text-sm text-muted">Balances across bank, cash, and savings.</Text></View><TouchableOpacity accessibilityLabel="Add account" activeOpacity={0.78} onPress={() => router.push("/account-form" as never)} className="h-11 w-11 items-center justify-center rounded-2xl bg-primary"><MaterialIcons name="add" size={25} color="#FFFFFF" /></TouchableOpacity></View><TouchableOpacity activeOpacity={0.78} onPress={() => router.push("/transfer-form" as never)} className="flex-row items-center justify-center gap-2 rounded-2xl bg-surface border border-border py-3"><MaterialIcons name="swap-horiz" size={20} color="#123A4A" /><Text className="text-sm font-bold text-primary">Transfer between accounts</Text></TouchableOpacity></View>} ListEmptyComponent={<EmptyState icon="account-balance" title="No accounts yet" description="Create a bank account, cash wallet, savings account, or credit card." />} renderItem={({ item }) => <TouchableOpacity activeOpacity={0.72} onPress={() => router.push(`/account-form?id=${item.id}` as never)} className="rounded-2xl border border-border bg-surface px-4 py-4"><View className="flex-row items-center gap-3"><View className="h-11 w-11 items-center justify-center rounded-2xl bg-primary/10"><MaterialIcons name={accountIcon[item.type]} size={22} color="#123A4A" /></View><View className="flex-1"><Text className="text-[16px] font-bold text-foreground">{item.name}</Text><Text className="mt-0.5 text-xs text-muted">{item.type.replace("_", " ").replace(/^./, (value) => value.toUpperCase())} · {item.currency}</Text></View><View className="items-end"><Text className="text-[16px] font-bold text-foreground">{formatMoney(item.balanceMinor, item.currency)}</Text>{item.currency !== snapshot.settings.currency ? <Text className="mt-0.5 text-[11px] text-muted">{formatMoney(item.balanceBaseMinor, snapshot.settings.currency)}</Text> : null}</View></View></TouchableOpacity>} /></ScreenContainer>;
}
