import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useRouter } from "expo-router";
import { FlatList, Switch, Text, TouchableOpacity, View } from "react-native";
import { EmptyState, LoadingScreen } from "@/components/finance-ui";
import { ScreenContainer } from "@/components/screen-container";
import { useAndroidExitConfirmation } from "@/hooks/use-android-exit-confirmation";
import { formatDate, formatMoney } from "@/lib/finance/format";
import { useFinance } from "@/lib/finance/provider";

export default function BillsScreen() {
  const router = useRouter();
  useAndroidExitConfirmation();
  const { isReady, snapshot, saveBill } = useFinance();
  if (!isReady) return <LoadingScreen />;
  const bills = [...snapshot.bills].sort((first, second) => Number(second.active) - Number(first.active) || first.name.localeCompare(second.name));
  const setBillActive = (id: string, active: boolean) => {
    const bill = snapshot.bills.find((item) => item.id === id);
    if (!bill) return;
    const { id: _id, createdAt: _createdAt, updatedAt: _updatedAt, ...input } = bill;
    void saveBill({ ...input, active }, id);
  };

  return (
    <ScreenContainer className="px-5">
      <FlatList
        data={bills}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingTop: 10, paddingBottom: 28, gap: 10, flexGrow: 1 }}
        ListHeaderComponent={<View className="flex-row items-start justify-between mb-4"><View><Text className="text-[30px] font-bold tracking-tight text-foreground">Fixed bills</Text><Text className="mt-1 text-sm text-muted">Recurring payments applied once per cycle.</Text></View><TouchableOpacity accessibilityLabel="Add fixed bill" activeOpacity={0.78} onPress={() => router.push("/bill-form" as never)} className="h-11 w-11 items-center justify-center rounded-2xl bg-primary"><MaterialIcons name="add" size={25} color="#FFFFFF" /></TouchableOpacity></View>}
        ListEmptyComponent={<EmptyState icon="account-balance-wallet" title="No fixed bills" description="Add rent, utilities, subscriptions, or another recurring commitment." />}
        renderItem={({ item }) => <TouchableOpacity accessibilityRole="button" accessibilityLabel={`Edit ${item.name}`} activeOpacity={0.7} onPress={() => router.push(`/bill-form?id=${item.id}` as never)} className="rounded-2xl border border-border bg-surface px-4 py-3.5"><View className="flex-row items-center justify-between gap-3"><View className="min-w-0 flex-1"><View className="flex-row items-center gap-2"><Text className="text-[15px] font-bold text-foreground" numberOfLines={1}>{item.name}</Text><View className={item.active ? "rounded-full bg-success/15 px-2 py-0.5" : "rounded-full bg-muted/15 px-2 py-0.5"}><Text className={item.active ? "text-[10px] font-bold text-success" : "text-[10px] font-bold text-muted"}>{item.active ? "ACTIVE" : "PAUSED"}</Text></View></View><Text className="mt-1 text-xs text-muted">{item.frequency === "monthly" ? "Monthly" : "Yearly"} · Due {formatDate(item.dueDate)}</Text></View><View className="items-end gap-2"><Text className="text-[15px] font-bold text-foreground">{formatMoney(item.amountMinor, item.currency)}</Text><Switch accessibilityLabel={`${item.name} is active`} value={item.active} onValueChange={(value) => setBillActive(item.id, value)} trackColor={{ false: "#D8D5CD", true: "#956000" }} thumbColor="#FFFFFF" /></View></View></TouchableOpacity>}
        ListFooterComponent={<TouchableOpacity accessibilityRole="button" accessibilityLabel="Other bills" accessibilityHint="Manage weekly, yearly, and custom recurring expenses" activeOpacity={0.74} onPress={() => router.push("/recurring-expenses" as never)} className="mt-4 flex-row items-center justify-between rounded-2xl border border-border bg-accentSoft px-4 py-4"><View className="flex-1"><Text className="text-[16px] font-bold text-foreground">Other bills</Text><Text className="mt-1 text-xs leading-5 text-muted">Weekly, yearly, or custom repeating payments.</Text></View><MaterialIcons name="chevron-right" size={22} color="#956000" /></TouchableOpacity>}
      />
    </ScreenContainer>
  );
}
