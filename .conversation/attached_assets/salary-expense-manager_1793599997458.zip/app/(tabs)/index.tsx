import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { Redirect, useRouter } from "expo-router";
import { FlatList, StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { AdMobHomeBanner } from "@/components/admob-home-banner";
import { AvailableToSpendEditor } from "@/components/available-to-spend-editor";
import { MotionEntrance, PremiumFeedbackBanner } from "@/components/finance-motion";
import { EmptyState, LoadingScreen, PrimaryButton, ScreenTitle, TransactionRow } from "@/components/finance-ui";
import { QuickExpenseSection } from "@/components/quick-expense-section";
import { ScreenContainer } from "@/components/screen-container";
import { useAndroidExitConfirmation } from "@/hooks/use-android-exit-confirmation";
import { useColors } from "@/hooks/use-colors";
import { formatCycleRange, formatMoney } from "@/lib/finance/format";
import { quickExpenseTemplateRoute } from "@/lib/finance/quick-expenses";
import { useFinance } from "@/lib/finance/provider";
import { usePremiumAccess } from "@/lib/premium/premium-access-provider";

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();
  const {
    isReady,
    snapshot,
    cycleSummary,
    recentTransactions,
    dailySpending,
    savingsGoals,
    budgetStatuses,
    premiumFeedback,
    dismissPremiumFeedback,
  } = useFinance();
  const { isPremium } = usePremiumAccess();
  useAndroidExitConfirmation();

  const mostUrgentBudget = budgetStatuses[0];
  const leadingSavingsGoal = savingsGoals[0];

  if (!isReady) return <LoadingScreen />;
  if (!snapshot.settings.onboardingCompleted) return <Redirect href={"/setup" as never} />;

  return (
    <ScreenContainer className="px-5">
      <View style={styles.screen}>
        <FlatList
          data={recentTransactions.slice(0, 5)}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
          style={styles.list}
          contentContainerStyle={styles.listContent}
          ListHeaderComponent={(
            <View className="gap-5">
              <ScreenTitle
                title="Overview"
                subtitle={`Salary cycle · ${formatCycleRange(cycleSummary.cycle.start, cycleSummary.cycle.end)}`}
              />
              <PremiumFeedbackBanner
                event={premiumFeedback}
                currency={snapshot.settings.currency}
                enabled={snapshot.settings.animationEffectsEnabled}
                onDismiss={dismissPremiumFeedback}
              />
              <View
                style={{ backgroundColor: colors.accent, borderColor: colors.border, borderWidth: 1 }}
                className="gap-2 overflow-hidden rounded-[28px] px-6 py-6"
              >
                <View className="flex-row items-center justify-between">
                  <Text style={{ color: "#302310" }} className="text-sm font-semibold">Available to spend</Text>
                  <View style={{ backgroundColor: colors.background }} className="h-9 w-9 items-center justify-center rounded-xl">
                    <MaterialIcons name="account-balance-wallet" size={20} color={colors.primary} />
                  </View>
                </View>
                <AvailableToSpendEditor
                  availableMinor={cycleSummary.availableMinor}
                  currency={snapshot.settings.currency}
                  animationEnabled={snapshot.settings.animationEffectsEnabled}
                />
                <Text style={{ color: "#302310" }} className="text-xs leading-5 opacity-70">
                  Calculated automatically from income, recurring bills, expenses, and savings.
                </Text>
                <View className="mt-3">
                  <PrimaryButton
                    label="Add expense"
                    icon="add"
                    onPress={() => router.push("/transaction-form?type=variable_expense&source=home" as never)}
                    secondary
                  />
                </View>
              </View>
              <QuickExpenseSection
                templates={snapshot.quickExpenseTemplates}
                currency={snapshot.settings.currency}
                isPremium={isPremium}
                onManage={() => router.push("/quick-expenses" as never)}
                onUseTemplate={(templateId) => router.push(quickExpenseTemplateRoute(templateId) as never)}
                onExplorePremium={() => router.push("/premium" as never)}
              />
              <View className="flex-row gap-3">
                <View className="flex-1 rounded-2xl border border-border bg-surface px-4 py-3">
                  <Text className="text-xs font-semibold text-muted">Safe daily spending</Text>
                  <Text className="mt-1 text-[17px] font-bold text-foreground">
                    {formatMoney(dailySpending.safeDailySpendingMinor, snapshot.settings.currency)}
                  </Text>
                  <Text className="mt-0.5 text-[11px] text-muted">per day · {dailySpending.daysRemaining} days left</Text>
                </View>
                <TouchableOpacity
                  accessibilityRole="button"
                  accessibilityLabel="Open savings progress"
                  activeOpacity={0.72}
                  onPress={() => router.push("/(tabs)/savings" as never)}
                  className="flex-1 rounded-2xl border border-border bg-surface px-4 py-3"
                >
                  <Text className="text-xs font-semibold text-muted">Savings progress</Text>
                  <Text className="mt-1 text-[17px] font-bold text-foreground">
                    {leadingSavingsGoal ? `${Math.round(leadingSavingsGoal.progressPercent)}%` : "Set a goal"}
                  </Text>
                  <Text className="mt-0.5 text-[11px] text-muted" numberOfLines={1}>
                    {leadingSavingsGoal?.name ?? "Start building a cushion"}
                  </Text>
                </TouchableOpacity>
              </View>
              {mostUrgentBudget ? (
                <TouchableOpacity
                  accessibilityRole="button"
                  accessibilityLabel="Open budget status"
                  activeOpacity={0.72}
                  onPress={() => router.push("/budget-settings" as never)}
                  className="flex-row items-center justify-between rounded-2xl border border-border bg-surface px-4 py-3"
                >
                  <View>
                    <Text className="text-xs font-semibold text-muted">Budget status</Text>
                    <Text className="mt-0.5 text-sm font-bold text-foreground">
                      {mostUrgentBudget.budget.category} · {Math.round(mostUrgentBudget.usedPercent)}% used
                    </Text>
                  </View>
                  <Text
                    className={
                      mostUrgentBudget.state === "exceeded"
                        ? "text-sm font-bold text-error"
                        : mostUrgentBudget.state === "warning"
                          ? "text-sm font-bold text-warning"
                          : "text-sm font-bold text-success"
                    }
                  >
                    {mostUrgentBudget.state === "exceeded"
                      ? "Exceeded"
                      : mostUrgentBudget.state === "warning"
                        ? "Near limit"
                        : "On track"}
                  </Text>
                </TouchableOpacity>
              ) : null}
              <View className="mt-1 flex-row items-center justify-between">
                <Text className="text-lg font-bold text-foreground">Recent activity</Text>
                <TouchableOpacity
                  accessibilityRole="button"
                  accessibilityLabel="See all transactions"
                  activeOpacity={0.65}
                  onPress={() => router.push("/(tabs)/transactions" as never)}
                >
                  <Text className="text-sm font-bold text-primary">See all</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
          ListEmptyComponent={(
            <EmptyState
              icon="receipt-long"
              title="No activity yet"
              description="Your salary and spending will appear here after you add them."
            />
          )}
          renderItem={({ item, index }) => (
            <MotionEntrance enabled={snapshot.settings.animationEffectsEnabled} delay={Math.min(index * 35, 140)}>
              <TransactionRow transaction={item} onPress={() => router.push(`/transaction-form?id=${item.id}` as never)} />
            </MotionEntrance>
          )}
        />
        <AdMobHomeBanner isPremium={isPremium} />
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  list: { flex: 1 },
  listContent: { gap: 10, paddingBottom: 24, paddingTop: 10 },
  screen: { flex: 1 },
});
