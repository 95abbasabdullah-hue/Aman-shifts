import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState, type ReactNode } from "react";
import { useRouter } from "expo-router";
import { ScrollView, Switch, Text, TouchableOpacity, View } from "react-native";
import { ResetEverythingSheet, type ResetConfirmationStep } from "@/components/reset-everything-sheet";
import { PremiumUnlockSheet } from "@/components/premium-unlock-sheet";
import { LoadingScreen, ScreenTitle } from "@/components/finance-ui";
import { ScreenContainer } from "@/components/screen-container";
import { useFinance } from "@/lib/finance/provider";
import { nextResetConfirmationStep } from "@/lib/finance/reset-confirmation";
import { type PremiumFeature } from "@/lib/premium/access";
import { usePremiumAccess } from "@/lib/premium/premium-access-provider";
import { useThemeContext } from "@/lib/theme-provider";

function SettingRow({ icon, title, subtitle, onPress, right }: {
  icon: React.ComponentProps<typeof MaterialIcons>["name"];
  title: string;
  subtitle?: string;
  onPress?: () => void;
  right?: ReactNode;
}) {
  return (
    <TouchableOpacity
      disabled={!onPress}
      activeOpacity={0.7}
      onPress={onPress}
      className="flex-row items-center gap-3 border-b border-border px-4 py-4 last:border-b-0"
    >
      <View className="h-9 w-9 items-center justify-center rounded-xl bg-primary/10">
        <MaterialIcons name={icon} size={19} color="#956000" />
      </View>
      <View className="flex-1">
        <Text className="text-[15px] font-semibold text-foreground">{title}</Text>
        {subtitle ? <Text className="mt-0.5 text-xs text-muted">{subtitle}</Text> : null}
      </View>
      {right ?? (onPress ? <MaterialIcons name="chevron-right" size={20} color="#756B56" /> : null)}
    </TouchableOpacity>
  );
}

function SettingsSection({ label, children }: { label: string; children: ReactNode }) {
  return (
    <View>
      <Text className="mb-2 ml-1 text-xs font-bold tracking-wider text-muted">{label}</Text>
      <View className="overflow-hidden rounded-2xl border border-border bg-surface">{children}</View>
    </View>
  );
}

export default function MoreScreen() {
  const router = useRouter();
  const { colorScheme, setColorScheme } = useThemeContext();
  const { isReady, snapshot, updateSettings, resetData } = useFinance();
  const { isPremium } = usePremiumAccess();
  const [resetStep, setResetStep] = useState<ResetConfirmationStep | null>(null);
  const [resetting, setResetting] = useState(false);
  const [resetError, setResetError] = useState("");
  const [lockedFeature, setLockedFeature] = useState<PremiumFeature | null>(null);
  if (!isReady) return <LoadingScreen />;

  const isDark = colorScheme === "dark";
  const setDarkMode = (value: boolean) => {
    const next = value ? "dark" : "light";
    setColorScheme(next);
    void updateSettings({ themePreference: next });
  };
  const openReset = () => { setResetError(""); setResetStep("review"); };
  const completeReset = async () => {
    setResetting(true); setResetError("");
    try { await resetData(); router.replace("/setup" as never); }
    catch (error) { setResetError(error instanceof Error ? error.message : "Unable to reset local data. Please try again."); }
    finally { setResetting(false); }
  };

  return (
    <ScreenContainer className="px-5">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 10, paddingBottom: 28, gap: 18 }}>
        <ScreenTitle title="More" subtitle="Preferences and local finance settings." />

        <SettingsSection label="MONEY">
          <SettingRow icon="payments" title="Salary & income" subtitle={`${snapshot.settings.currency} · paid on the ${snapshot.settings.salaryPaymentDay}${snapshot.settings.salaryPaymentDay === 1 ? "st" : snapshot.settings.salaryPaymentDay === 2 ? "nd" : snapshot.settings.salaryPaymentDay === 3 ? "rd" : "th"}`} onPress={() => router.push("/salary-settings" as never)} />
          <SettingRow icon="bolt" title="Quick expense templates" subtitle="Save and reuse common one-off expenses." onPress={() => router.push("/quick-expenses" as never)} />
          <SettingRow icon="pie-chart-outline" title="Budget management" subtitle="Category limits and spending alerts." onPress={() => router.push("/budget-settings" as never)} />
          <SettingRow icon="insights" title="Financial summary" subtitle="A clear view of your current cycle." onPress={() => router.push("/financial-summary" as never)} />
          <SettingRow icon="bar-chart" title="Statistics" subtitle={isPremium ? "Local charts and period filters." : "Premium local charts and period filters."} onPress={() => isPremium ? router.push("/statistics" as never) : setLockedFeature("statistics")} right={<MaterialIcons name={isPremium ? "chevron-right" : "lock-outline"} size={20} color="#956000" />} />
          <SettingRow icon="autorenew" title="Recurring expenses" subtitle="Weekly, monthly, yearly, or custom intervals." onPress={() => router.push("/recurring-expenses" as never)} />
          <SettingRow icon="currency-exchange" title="Currencies" subtitle="Manual offline currency rates." onPress={() => router.push("/currency-settings" as never)} />
        </SettingsSection>

        <SettingsSection label="APPEARANCE & FEEDBACK">
          <SettingRow icon="workspace-premium" title="Premium preview" subtitle="Forecasts and custom reports." onPress={() => router.push("/premium" as never)} />
          <SettingRow icon="dark-mode" title="Dark mode" subtitle={isDark ? "On" : "Off"} onPress={() => setDarkMode(!isDark)} right={<Switch accessibilityLabel="Dark mode" value={isDark} onValueChange={setDarkMode} trackColor={{ false: "#E9D8A7", true: "#956000" }} thumbColor="#FFFFFF" />} />
          <SettingRow icon="settings" title="Settings" subtitle="Sound effects and haptic feedback." onPress={() => router.push("/settings" as never)} />
          <SettingRow icon="volume-up" title="Feedback & reminders" subtitle="Motion, sounds, and local reminders." onPress={() => router.push("/premium-preferences" as never)} />
          <SettingRow icon="exit-to-app" title="Confirm before exit" subtitle="Always ask before Android Back closes the app." right={<Text className="text-xs font-bold text-success">ALWAYS ON</Text>} />
        </SettingsSection>

        <SettingsSection label="ON THIS DEVICE">
          <SettingRow icon="phone-android" title="Offline storage" subtitle="Financial data stays only on this device." />
          <SettingRow icon="backup" title="Backup, restore & privacy" subtitle="Export or restore local records securely." onPress={() => router.push("/local-data-tools" as never)} />
          <SettingRow icon="delete-outline" title="Reset Everything" subtitle="Permanently remove local records and finance reminders." onPress={openReset} right={<MaterialIcons name="chevron-right" size={20} color="#C55750" />} />
        </SettingsSection>

        <Text className="px-2 text-center text-xs leading-5 text-muted">Salary & Expense Manager works without sign-in or internet access.</Text>
      </ScrollView>
      <ResetEverythingSheet step={resetStep} resetting={resetting} error={resetError} onCancel={() => { if (!resetting) { setResetStep(null); setResetError(""); } }} onContinue={() => setResetStep((step) => step ? nextResetConfirmationStep(step) : null)} onReset={() => void completeReset()} />
      <PremiumUnlockSheet visible={lockedFeature !== null} feature={lockedFeature} onClose={() => setLockedFeature(null)} />
    </ScreenContainer>
  );
}
