import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useRouter } from "expo-router";
import { useState } from "react";
import { FlatList, Modal, Text, TouchableOpacity, View } from "react-native";
import { EmptyState, LoadingScreen, TransactionRow } from "@/components/finance-ui";
import { ScreenContainer } from "@/components/screen-container";
import { useAndroidExitConfirmation } from "@/hooks/use-android-exit-confirmation";
import { transactionDeletePrompt } from "@/lib/finance/transaction-row-actions";
import { useFinance } from "@/lib/finance/provider";
import type { FinanceTransaction } from "@/lib/finance/types";

export default function TransactionsScreen() {
  const router = useRouter();
  useAndroidExitConfirmation();
  const { isReady, recentTransactions, deleteTransaction } = useFinance();
  const [selected, setSelected] = useState<FinanceTransaction | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState("");
  if (!isReady) return <LoadingScreen />;

  const removeSelected = async () => {
    if (!selected) return;
    setDeleting(true);
    setDeleteError("");
    try {
      await deleteTransaction(selected.id);
      setSelected(null);
    } catch (error) {
      setDeleteError(error instanceof Error ? error.message : "Unable to delete this transaction. Please try again.");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <ScreenContainer className="px-5">
      <FlatList
        data={recentTransactions}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingTop: 10, paddingBottom: 28, gap: 10, flexGrow: 1 }}
        ListHeaderComponent={<View className="flex-row items-start justify-between mb-4"><View className="flex-1 mr-3"><Text className="text-[30px] font-bold tracking-tight text-foreground">Transactions</Text><Text className="mt-1 text-sm text-muted">Every income, expense, savings move, and transfer.</Text></View><View className="flex-row gap-2"><TouchableOpacity accessibilityLabel="Search and filter transactions" activeOpacity={0.78} onPress={() => router.push("/transaction-search" as never)} className="h-11 w-11 items-center justify-center rounded-2xl bg-surface border border-border"><MaterialIcons name="search" size={23} color="#123A4A" /></TouchableOpacity><TouchableOpacity accessibilityLabel="Add transaction" activeOpacity={0.78} onPress={() => router.push("/transaction-form" as never)} className="h-11 w-11 items-center justify-center rounded-2xl bg-primary"><MaterialIcons name="add" size={25} color="#FFFFFF" /></TouchableOpacity></View></View>}
        ListEmptyComponent={<EmptyState icon="receipt-long" title="Your ledger is empty" description="Add an income or expense to begin tracking this salary cycle." />}
        renderItem={({ item }) => <TransactionRow transaction={item} onPress={() => router.push(`/transaction-form?id=${item.id}` as never)} onLongPress={() => { setDeleteError(""); setSelected(item); }} />}
      />
      <Modal visible={Boolean(selected)} transparent animationType="fade" onRequestClose={() => { if (!deleting) setSelected(null); }}>
        <View className="flex-1 justify-end bg-black/45 px-4 pb-6">
          <View className="rounded-[28px] border border-border bg-background p-5">
            <Text className="text-xl font-bold text-foreground">Delete transaction?</Text>
            <Text className="mt-2 text-sm leading-5 text-muted">{selected ? transactionDeletePrompt(selected) : ""}</Text>
            {deleteError ? <Text className="mt-3 text-sm font-medium text-error">{deleteError}</Text> : null}
            <View className="mt-5 flex-row gap-3">
              <TouchableOpacity accessibilityRole="button" disabled={deleting} onPress={() => setSelected(null)} className="flex-1 items-center rounded-2xl border border-border bg-surface py-3">
                <Text className="text-sm font-bold text-muted">Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity accessibilityRole="button" accessibilityLabel="Delete selected transaction permanently" disabled={deleting} onPress={() => void removeSelected()} className="flex-1 items-center rounded-2xl bg-error py-3">
                <Text className="text-sm font-bold text-white">{deleting ? "Deleting…" : "Delete permanently"}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
