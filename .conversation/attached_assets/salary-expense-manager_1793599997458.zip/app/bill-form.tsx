import { useEffect, useMemo, useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, ScrollView, Switch, Text, TouchableOpacity, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { DatePickerField } from "@/components/date-picker-field";
import { DeleteConfirmationSheet } from "@/components/delete-confirmation-sheet";
import { AppTextInput, ChoicePills, FormField } from "@/components/finance-form";
import { PrimaryButton } from "@/components/finance-ui";
import { ScreenContainer } from "@/components/screen-container";
import { todayIsoDate } from "@/lib/finance/cycle";
import { parseAmountToMinor } from "@/lib/finance/format";
import { deleteReturnAction } from "@/lib/navigation/delete-return";
import { useFinance } from "@/lib/finance/provider";
import { BILL_CATEGORIES, type BillCategory } from "@/lib/finance/types";
import { validateBill, type FieldErrors } from "@/lib/finance/validation";

export default function BillFormScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ id?: string }>();
  const { snapshot, saveBill, deleteBill } = useFinance();
  const existing = useMemo(() => snapshot.bills.find((bill) => bill.id === params.id), [params.id, snapshot.bills]);
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [dueDate, setDueDate] = useState(todayIsoDate());
  const [frequency, setFrequency] = useState<"monthly" | "yearly">("monthly");
  const [category, setCategory] = useState<BillCategory>("Other");
  const [note, setNote] = useState("");
  const [active, setActive] = useState(true);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [saving, setSaving] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState("");

  useEffect(() => {
    if (!existing) return;
    setName(existing.name); setAmount((existing.amountMinor / 100).toFixed(2)); setDueDate(existing.dueDate); setFrequency(existing.frequency); setCategory(existing.category); setNote(existing.note ?? ""); setActive(existing.active);
  }, [existing]);

  const submit = async () => {
    const input = { name, amountMinor: parseAmountToMinor(amount), currency: snapshot.settings.currency, dueDate, frequency, category, note: note.trim() || undefined, active };
    const nextErrors = validateBill(input, snapshot.settings.currency);
    if (Object.keys(nextErrors).length) { setErrors(nextErrors); return; }
    setSaving(true);
    try { await saveBill(input, existing?.id); router.back(); } catch { Alert.alert("Unable to save", "Please try again."); } finally { setSaving(false); }
  };
  const remove = async () => {
    if (!existing) return;
    setDeleting(true); setDeleteError("");
    try {
      await deleteBill(existing.id);
      setDeleteOpen(false);
      if (deleteReturnAction(router.canGoBack()) === "back") router.back(); else router.replace("/(tabs)/bills" as never);
    } catch (error) { setDeleteError(error instanceof Error ? error.message : "Unable to delete this fixed bill. Please try again."); } finally { setDeleting(false); }
  };

  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5"><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} className="flex-1"><ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingTop: 10, paddingBottom: 28, gap: 20 }}><View className="flex-row items-center justify-between"><View><Text className="text-[29px] font-bold tracking-tight text-foreground">{existing ? "Edit fixed bill" : "New fixed bill"}</Text><Text className="mt-1 text-sm text-muted">Applied automatically once per cycle.</Text></View><TouchableOpacity accessibilityLabel="Close fixed bill editor" activeOpacity={0.7} onPress={() => router.back()} className="h-10 w-10 items-center justify-center rounded-full bg-surface"><Text className="text-xl text-muted">×</Text></TouchableOpacity></View><FormField label="Bill name" error={errors.name}><AppTextInput value={name} onChangeText={setName} placeholder="e.g. Apartment rent" /></FormField><FormField label="Amount" error={errors.amount}><AppTextInput value={amount} onChangeText={setAmount} placeholder="0.00" keyboardType="decimal-pad" /></FormField><FormField label="Category"><ChoicePills options={BILL_CATEGORIES} selected={category} onChange={(value) => setCategory(value as BillCategory)} /></FormField><FormField label="Frequency" error={errors.frequency}><ChoicePills options={["Monthly", "Yearly"]} selected={frequency === "monthly" ? "Monthly" : "Yearly"} onChange={(value) => setFrequency(value === "Monthly" ? "monthly" : "yearly")} /></FormField><DatePickerField label="Due date" value={dueDate} onChange={setDueDate} error={errors.dueDate} /><FormField label="Note (Optional)"><AppTextInput value={note} onChangeText={setNote} placeholder="Add more detail" multiline style={{ minHeight: 78, paddingTop: 13, textAlignVertical: "top" }} /></FormField><View className="flex-row items-center justify-between rounded-2xl border border-border bg-surface px-4 py-3"><View><Text className="text-[15px] font-bold text-foreground">Bill is active</Text><Text className="mt-0.5 text-xs text-muted">Turning it off restores this cycle’s generated charge.</Text></View><Switch accessibilityLabel="Bill is active" value={active} onValueChange={setActive} trackColor={{ false: "#E9D8A7", true: "#956000" }} thumbColor="#FFFFFF" /></View><View className="mt-1 gap-3"><PrimaryButton label={saving ? "Saving…" : "Save fixed bill"} onPress={submit} disabled={saving || deleting} />{existing ? <TouchableOpacity accessibilityRole="button" accessibilityLabel="Delete fixed bill" disabled={saving || deleting} activeOpacity={0.7} onPress={() => { setDeleteError(""); setDeleteOpen(true); }} className="items-center rounded-2xl border border-error/30 bg-surface py-3"><Text className="text-sm font-bold text-error">Delete fixed bill</Text></TouchableOpacity> : null}</View></ScrollView></KeyboardAvoidingView><DeleteConfirmationSheet visible={deleteOpen} title="Delete fixed bill?" detail="Past transactions stay in your history, but this bill will no longer be applied in future cycles." error={deleteError} deleting={deleting} onCancel={() => { setDeleteOpen(false); setDeleteError(""); }} onConfirm={() => void remove()} /></ScreenContainer>;
}
