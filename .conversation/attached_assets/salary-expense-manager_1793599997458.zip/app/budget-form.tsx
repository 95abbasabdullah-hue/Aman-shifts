import { useEffect, useMemo, useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, ScrollView, Text, TouchableOpacity, View } from "react-native";
import { DeleteConfirmationSheet } from "@/components/delete-confirmation-sheet";
import { useLocalSearchParams, useRouter } from "expo-router";
import { AppTextInput, ChoicePills, FormField } from "@/components/finance-form";
import { PrimaryButton } from "@/components/finance-ui";
import { ScreenContainer } from "@/components/screen-container";
import { parseAmountToMinor } from "@/lib/finance/format";
import { useFinance } from "@/lib/finance/provider";
import { EXPENSE_CATEGORIES, type ExpenseCategory } from "@/lib/finance/types";
import { validateBudget, type FieldErrors } from "@/lib/finance/validation";

export default function BudgetFormScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ id?: string }>();
  const { snapshot, saveBudget, deleteBudget } = useFinance();
  const existing = useMemo(() => snapshot.budgets.find((budget) => budget.id === params.id), [params.id, snapshot.budgets]);
  const [category, setCategory] = useState<ExpenseCategory>("Food");
  const [limit, setLimit] = useState("");
  const [errors, setErrors] = useState<FieldErrors>({});
  const [saving, setSaving] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState("");
  useEffect(() => { if (existing) { setCategory(existing.category); setLimit((existing.limitMinor / 100).toFixed(2)); } }, [existing]);
  const submit = async () => { const input = { category, limitMinor: parseAmountToMinor(limit) }; const nextErrors = validateBudget(input); if (Object.keys(nextErrors).length) return setErrors(nextErrors); setSaving(true); try { await saveBudget(input, existing?.id); router.back(); } catch { Alert.alert("Unable to save", "Please try again."); } finally { setSaving(false); } };
  const remove = async () => { if (!existing) return; setDeleting(true); setDeleteError(""); try { await deleteBudget(existing.id); setDeleteOpen(false); if (router.canGoBack()) router.back(); else router.replace("/budget-settings" as never); } catch (error) { setDeleteError(error instanceof Error ? error.message : "Unable to delete this budget. Please try again."); } finally { setDeleting(false); } };
  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5"><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} className="flex-1"><ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 10, paddingBottom: 28, gap: 20 }}><View className="flex-row items-center justify-between"><View><Text className="text-[29px] font-bold tracking-tight text-foreground">{existing ? "Edit budget" : "New budget"}</Text><Text className="mt-1 text-sm text-muted">Limits reset for each calendar month.</Text></View><TouchableOpacity activeOpacity={0.7} onPress={() => router.back()} className="h-10 w-10 items-center justify-center rounded-full bg-surface"><Text className="text-xl text-muted">×</Text></TouchableOpacity></View><FormField label="Category" error={errors.category}><ChoicePills options={EXPENSE_CATEGORIES} selected={category} onChange={(value) => setCategory(value as ExpenseCategory)} /></FormField><FormField label="Monthly spending limit" error={errors.limit}><AppTextInput value={limit} onChangeText={setLimit} placeholder="0.00" keyboardType="decimal-pad" /></FormField><View className="gap-3"><PrimaryButton label={saving ? "Saving…" : "Save budget"} onPress={submit} disabled={saving || deleting} />{existing ? <TouchableOpacity accessibilityRole="button" accessibilityLabel="Delete budget" disabled={saving || deleting} activeOpacity={0.7} onPress={() => { setDeleteError(""); setDeleteOpen(true); }} className="items-center rounded-2xl border border-error/30 bg-surface py-3"><Text className="text-sm font-bold text-error">Delete budget</Text></TouchableOpacity> : null}</View></ScrollView></KeyboardAvoidingView><DeleteConfirmationSheet visible={deleteOpen} title="Delete budget?" detail="This removes the spending limit and its alerts. Your transaction history remains intact." error={deleteError} deleting={deleting} onCancel={() => { setDeleteOpen(false); setDeleteError(""); }} onConfirm={() => void remove()} /></ScreenContainer>;
}
