import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import { AnimatedProgress } from "@/components/finance-motion";
import { AppTextInput, FormField } from "@/components/finance-form";
import { PrimaryButton } from "@/components/finance-ui";
import { ScreenContainer } from "@/components/screen-container";
import { formatMoney } from "@/lib/finance/format";
import { parseBudgetThresholds } from "@/lib/finance/budget-thresholds";
import { budgetSettingsExitAction } from "@/lib/navigation/budget-settings-exit";
import { useFinance } from "@/lib/finance/provider";
import { useRouter } from "expo-router";

export default function BudgetSettingsScreen() {
  const router = useRouter();
  const { snapshot, budgetStatuses, updateSettings } = useFinance();
  const [warning, setWarning] = useState(String(snapshot.settings.budgetWarningThresholdPercent));
  const [exceeded, setExceeded] = useState(String(snapshot.settings.budgetExceededThresholdPercent));
  const [saving, setSaving] = useState(false);
  const [thresholdError, setThresholdError] = useState("");
  const [savedMessage, setSavedMessage] = useState("");
  const exitScreen = () => {
    if (budgetSettingsExitAction(router.canGoBack()) === "back") {
      router.back();
      return;
    }
    router.replace("/(tabs)/more" as never);
  };
  const saveThresholds = async () => {
    const parsed = parseBudgetThresholds(warning, exceeded);
    if ("error" in parsed) { setThresholdError(parsed.error); setSavedMessage(""); return; }
    setSaving(true); setThresholdError(""); setSavedMessage("");
    try { await updateSettings({ budgetWarningThresholdPercent: parsed.warning, budgetExceededThresholdPercent: parsed.exceeded }); setSavedMessage("Thresholds saved locally."); }
    catch { setThresholdError("Unable to save thresholds. Please try again."); }
    finally { setSaving(false); }
  };
  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5"><ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 10, paddingBottom: 28, gap: 20 }}><View className="flex-row items-center justify-between"><View className="flex-1 pr-3"><Text className="text-[29px] font-bold tracking-tight text-foreground">Budgets</Text><Text className="mt-1 text-sm text-muted">Current-month limits by spending category.</Text></View><View className="flex-row gap-2"><TouchableOpacity accessibilityRole="button" accessibilityLabel="Close Budget Management" activeOpacity={0.72} onPress={exitScreen} className="h-11 w-11 items-center justify-center rounded-2xl bg-surface"><Text className="text-xl text-muted">×</Text></TouchableOpacity><TouchableOpacity accessibilityRole="button" accessibilityLabel="Add budget" activeOpacity={0.78} onPress={() => router.push("/budget-form" as never)} className="h-11 w-11 items-center justify-center rounded-2xl bg-primary"><MaterialIcons name="add" size={25} color="#FFFFFF" /></TouchableOpacity></View></View>{budgetStatuses.length ? <View className="gap-2">{budgetStatuses.map((status) => <TouchableOpacity accessibilityRole="button" accessibilityLabel={`${status.budget.category} budget, ${Math.round(status.usedPercent)} percent used`} key={status.budget.id} activeOpacity={0.72} onPress={() => router.push(`/budget-form?id=${status.budget.id}` as never)} className="rounded-2xl border border-border bg-surface px-4 py-3"><View className="flex-row justify-between gap-3"><View className="flex-1"><Text className="text-[15px] font-bold text-foreground">{status.budget.category}</Text><Text className="mt-1 text-xs text-muted">{formatMoney(status.spentMinor, snapshot.settings.currency)} spent of {formatMoney(status.budget.limitMinor, snapshot.settings.currency)}</Text></View><Text className={status.state === "exceeded" ? "text-sm font-bold text-error" : status.state === "warning" ? "text-sm font-bold text-warning" : "text-sm font-bold text-success"}>{Math.round(status.usedPercent)}%</Text></View><AnimatedProgress progress={status.usedPercent} enabled={snapshot.settings.animationEffectsEnabled} color={status.state === "exceeded" ? "#D45B5B" : status.state === "warning" ? "#D69A2D" : "#198B73"} /></TouchableOpacity>)}</View> : <View className="rounded-3xl border border-dashed border-border bg-surface px-6 py-8"><Text className="text-center text-base font-bold text-foreground">No category budgets</Text><Text className="mt-2 text-center text-sm leading-5 text-muted">Add limits for Food, Transportation, Entertainment, Shopping, and more.</Text></View>}<View className="mt-1 gap-4"><Text className="ml-1 text-xs font-bold tracking-wider text-muted">ALERT THRESHOLDS</Text><Text className="-mt-2 ml-1 text-xs leading-5 text-muted">Saved locally and used to mark category budgets as warning or exceeded.</Text><FormField label="Warning at (%)" error={thresholdError}><AppTextInput value={warning} onChangeText={(value) => { setWarning(value); setThresholdError(""); setSavedMessage(""); }} keyboardType="decimal-pad" returnKeyType="next" /></FormField><FormField label="Exceeded at (%)"><AppTextInput value={exceeded} onChangeText={(value) => { setExceeded(value); setThresholdError(""); setSavedMessage(""); }} keyboardType="decimal-pad" returnKeyType="done" onSubmitEditing={() => void saveThresholds()} /></FormField>{savedMessage ? <Text accessibilityLiveRegion="polite" className="-mt-2 text-sm font-semibold text-success">{savedMessage}</Text> : null}<PrimaryButton label={saving ? "Saving…" : "Save thresholds"} onPress={saveThresholds} disabled={saving} secondary /></View></ScrollView></ScreenContainer>;
}
