import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useMemo, useState } from "react";
import { ActivityIndicator, Alert, Platform, ScrollView, Text, TouchableOpacity, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { buildLocalFinanceReport, exportLocalReport, type ReportExportFormat, type ReportPeriod } from "@/lib/finance/local-reports";
import { formatMoney } from "@/lib/finance/format";
import { useFinance } from "@/lib/finance/provider";
import { usePremiumAccess } from "@/lib/premium/premium-access-provider";
import { customReportsExitRoute } from "@/lib/navigation/custom-reports-exit";
import { PremiumFeatureLocked } from "@/components/premium-feature-locked";
import { useRouter } from "expo-router";

const periods: { value: ReportPeriod; label: string }[] = [{ value: "current_cycle", label: "Cycle" }, { value: "previous_cycle", label: "Previous" }, { value: "month", label: "Month" }, { value: "year", label: "Year" }];

export default function CustomReportsScreen() {
  const { isPremium } = usePremiumAccess();
  if (!isPremium) return <PremiumFeatureLocked feature="reports" />;
  return <CustomReportsContent />;
}

function CustomReportsContent() {
  const router = useRouter();
  const { snapshot } = useFinance();
  const [period, setPeriod] = useState<ReportPeriod>("current_cycle");
  const [exporting, setExporting] = useState<ReportExportFormat | null>(null);
  const report = useMemo(() => buildLocalFinanceReport(snapshot, period, new Date().toISOString().slice(0, 10)), [snapshot, period]);
  const close = () => {
    if (customReportsExitRoute(router.canGoBack()) === "back") router.back();
    else router.replace("/premium" as never);
  };
  const exportReport = async (format: ReportExportFormat) => {
    if (exporting) return;
    setExporting(format);
    try {
      const result = await exportLocalReport(report, format);
      if (Platform.OS === "web" && result.mode === "print") Alert.alert("PDF ready to save", "The print dialog is open. Choose Save as PDF to store the report locally.");
      if (Platform.OS === "web" && result.mode === "download") Alert.alert("CSV download started", "Your local report is downloading in this browser.");
      if (Platform.OS !== "web") Alert.alert("Report ready", `${result.fileName} was created on this device. Use the share sheet to save or send it.`);
    } catch (error) {
      Alert.alert("Could not export report", error instanceof Error ? error.message : "Please try again.");
    } finally { setExporting(null); }
  };
  const currency = report.currency;
  const summary = [{ label: "Income", value: report.totals.incomeMinor, tone: "text-success" }, { label: "Expenses", value: report.totals.fixedExpensesMinor + report.totals.variableExpensesMinor, tone: "text-error" }, { label: "Net savings", value: report.totals.netSavingsMinor, tone: "text-primary" }];
  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5"><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 10, paddingBottom: 32, gap: 18 }}><View className="flex-row items-center justify-between"><View className="mr-4 flex-1"><Text className="text-[29px] font-bold tracking-tight text-foreground">Custom reports</Text><Text className="mt-1 text-sm leading-5 text-muted">Create a private file from the finance data stored on this device.</Text></View><TouchableOpacity accessibilityLabel="Close Custom reports" activeOpacity={0.72} onPress={close} className="h-10 w-10 items-center justify-center rounded-full bg-surface"><Text className="text-xl text-muted">×</Text></TouchableOpacity></View><View><Text className="mb-2 ml-1 text-xs font-bold tracking-wider text-muted">REPORT PERIOD</Text><View className="flex-row rounded-2xl border border-border bg-surface p-1">{periods.map((option) => <TouchableOpacity key={option.value} accessibilityRole="button" accessibilityState={{ selected: option.value === period }} activeOpacity={0.75} onPress={() => setPeriod(option.value)} className={`flex-1 items-center rounded-xl px-1 py-2.5 ${option.value === period ? "bg-background" : ""}`}><Text numberOfLines={1} className={`text-xs font-bold ${option.value === period ? "text-primary" : "text-muted"}`}>{option.label}</Text></TouchableOpacity>)}</View></View><View className="overflow-hidden rounded-3xl border border-primary/25 bg-primary"><View className="p-5"><Text className="text-xs font-bold tracking-wider text-white/80">LOCAL FINANCIAL REPORT</Text><Text className="mt-2 text-2xl font-bold text-white">{report.periodLabel}</Text><Text className="mt-2 text-sm leading-5 text-white/80">{report.transactions.length} ledger record{report.transactions.length === 1 ? "" : "s"} and {report.activeBills.length} active bill{report.activeBills.length === 1 ? "" : "s"} included.</Text></View><View className="border-t border-white/20 bg-black/10 px-5 py-4"><Text className="text-xs text-white/75">Available to spend</Text><Text className="mt-1 text-2xl font-bold text-white">{formatMoney(report.totals.availableSpendingMinor, currency)}</Text></View></View><View className="flex-row gap-3">{summary.map((item) => <View key={item.label} className="flex-1 rounded-2xl border border-border bg-surface p-3"><Text numberOfLines={1} className="text-[11px] font-semibold text-muted">{item.label}</Text><Text numberOfLines={1} className={`mt-2 text-sm font-bold ${item.tone}`}>{formatMoney(item.value, currency)}</Text></View>)}</View><View className="rounded-3xl border border-border bg-surface p-4"><View className="flex-row items-center gap-2"><MaterialIcons name="summarize" size={19} color="#956000" /><Text className="text-base font-bold text-foreground">What is included</Text></View><Text className="mt-2 text-sm leading-5 text-muted">A period summary, every local ledger record with its original currency and main-currency amount, plus active bill details. Transfers are listed separately and never counted as income or spending.</Text></View><View><Text className="mb-2 ml-1 text-xs font-bold tracking-wider text-muted">EXPORT A LOCAL FILE</Text><TouchableOpacity accessibilityRole="button" accessibilityLabel="Export custom report as CSV" disabled={Boolean(exporting)} activeOpacity={0.78} onPress={() => exportReport("csv")} className="mb-3 flex-row items-center rounded-3xl border border-border bg-surface p-4 disabled:opacity-60"><View className="mr-3 h-11 w-11 items-center justify-center rounded-2xl bg-success/15"><MaterialIcons name="table-chart" size={22} color="#198B73" /></View><View className="flex-1"><Text className="text-base font-bold text-foreground">Export CSV</Text><Text className="mt-1 text-xs leading-4 text-muted">Spreadsheet-ready records and totals.</Text></View>{exporting === "csv" ? <ActivityIndicator color="#956000" /> : <MaterialIcons name="file-download" size={21} color="#956000" />}</TouchableOpacity><TouchableOpacity accessibilityRole="button" accessibilityLabel="Export custom report as PDF" disabled={Boolean(exporting)} activeOpacity={0.78} onPress={() => exportReport("pdf")} className="flex-row items-center rounded-3xl bg-primary p-4 disabled:opacity-60"><View className="mr-3 h-11 w-11 items-center justify-center rounded-2xl bg-white/15"><MaterialIcons name="picture-as-pdf" size={22} color="#ffffff" /></View><View className="flex-1"><Text className="text-base font-bold text-white">Export PDF</Text><Text className="mt-1 text-xs leading-4 text-white/80">Printable summary with ledger and bills.</Text></View>{exporting === "pdf" ? <ActivityIndicator color="#ffffff" /> : <MaterialIcons name="file-download" size={21} color="#ffffff" />}</TouchableOpacity></View><Text className="px-2 text-center text-xs leading-5 text-muted">Exports are generated only on your device. Native builds open the share sheet; on web, CSV downloads and PDF opens the browser print dialog for Save as PDF.</Text></ScrollView></ScreenContainer>;
}
