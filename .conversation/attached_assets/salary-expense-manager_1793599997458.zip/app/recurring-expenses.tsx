import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useRouter } from "expo-router";
import { FlatList, Switch, Text, TouchableOpacity, View } from "react-native";
import { EmptyState } from "@/components/finance-ui";
import { ScreenContainer } from "@/components/screen-container";
import { formatMoney } from "@/lib/finance/format";
import { recurringExpensesExitAction } from "@/lib/navigation/recurring-expenses-exit";
import { useFinance } from "@/lib/finance/provider";

export default function RecurringExpensesScreen() {
  const router = useRouter();
  const { snapshot, saveRecurringExpense } = useFinance();
  const exitScreen = () => {
    if (recurringExpensesExitAction(router.canGoBack()) === "back") router.back();
    else router.replace("/(tabs)/bills" as never);
  };
  const setRecurringExpenseActive = (id: string, active: boolean) => {
    const expense = snapshot.recurringExpenses.find((item) => item.id === id);
    if (!expense) return;
    const { id: _id, createdAt: _createdAt, updatedAt: _updatedAt, ...input } = expense;
    void saveRecurringExpense({ ...input, active }, id);
  };

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5">
      <FlatList
        data={snapshot.recurringExpenses}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingTop: 10, paddingBottom: 28, gap: 10, flexGrow: 1 }}
        ListHeaderComponent={<View className="mb-4 flex-row items-start justify-between"><View className="mr-3 flex-1"><Text className="text-[29px] font-bold tracking-tight text-foreground">Recurring expenses</Text><Text className="mt-1 text-sm text-muted">Automatic local entries, never duplicated.</Text></View><View className="flex-row gap-2"><TouchableOpacity accessibilityRole="button" accessibilityLabel="Close recurring expenses" accessibilityHint="Returns to the previous screen" activeOpacity={0.75} onPress={exitScreen} className="h-11 w-11 items-center justify-center rounded-2xl border border-border bg-surface"><MaterialIcons name="close" size={22} color="#756B56" /></TouchableOpacity><TouchableOpacity accessibilityRole="button" accessibilityLabel="Add recurring expense" activeOpacity={0.78} onPress={() => router.push("/recurring-expense-form" as never)} className="h-11 w-11 items-center justify-center rounded-2xl bg-primary"><MaterialIcons name="add" size={25} color="#FFFFFF" /></TouchableOpacity></View></View>}
        ListEmptyComponent={<EmptyState icon="autorenew" title="No recurring expenses" description="Add weekly, monthly, yearly, or custom payments such as Netflix or gym membership." />}
        renderItem={({ item }) => <TouchableOpacity accessibilityRole="button" accessibilityLabel={`Edit ${item.name}`} activeOpacity={0.72} onPress={() => router.push(`/recurring-expense-form?id=${item.id}` as never)} className="rounded-2xl border border-border bg-surface px-4 py-3.5"><View className="flex-row items-center justify-between"><View className="flex-1"><View className="flex-row items-center gap-2"><Text className="text-[15px] font-bold text-foreground">{item.name}</Text>{!item.active ? <Text className="rounded-full bg-muted/15 px-2 py-0.5 text-[10px] font-bold text-muted">PAUSED</Text> : null}</View><Text className="mt-1 text-xs text-muted">{item.frequency === "custom" ? `Every ${item.customIntervalDays} days` : item.frequency.replace(/^./, (value) => value.toUpperCase())} · {item.category}</Text></View><View className="items-end gap-2"><Text className="text-[15px] font-bold text-foreground">{formatMoney(item.amountMinor, item.currency)}</Text><Switch accessibilityLabel={`${item.name} is active`} value={item.active} onValueChange={(value) => setRecurringExpenseActive(item.id, value)} trackColor={{ false: "#D8D5CD", true: "#956000" }} thumbColor="#FFFFFF" /></View></View></TouchableOpacity>}
      />
    </ScreenContainer>
  );
}
