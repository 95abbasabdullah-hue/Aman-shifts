import { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, ScrollView, Switch, Text, TouchableOpacity, View } from "react-native";
import { useRouter } from "expo-router";
import { DayOfMonthPicker } from "@/components/day-of-month-picker";
import { AppTextInput, FormField } from "@/components/finance-form";
import { PrimaryButton } from "@/components/finance-ui";
import { ScreenContainer } from "@/components/screen-container";
import { parseAmountToMinor } from "@/lib/finance/format";
import { useFinance } from "@/lib/finance/provider";
import { validateSalary, type FieldErrors } from "@/lib/finance/validation";

export default function SalarySettingsScreen() {
  const router = useRouter();
  const { snapshot, updateSettings } = useFinance();
  const [salary, setSalary] = useState(snapshot.settings.monthlySalaryMinor ? (snapshot.settings.monthlySalaryMinor / 100).toFixed(2) : "");
  const [currency, setCurrency] = useState(snapshot.settings.currency);
  const [paymentDay, setPaymentDay] = useState(snapshot.settings.salaryPaymentDay);
  const [automatic, setAutomatic] = useState(snapshot.settings.automaticSalaryEnabled);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [saving, setSaving] = useState(false);
  const save = async () => {
    const input = { monthlySalaryMinor: parseAmountToMinor(salary), currency: currency.trim().toUpperCase(), salaryPaymentDay: paymentDay };
    const nextErrors = validateSalary(input);
    if (Object.keys(nextErrors).length) return setErrors(nextErrors);
    setSaving(true);
    try { await updateSettings({ ...input, automaticSalaryEnabled: automatic }); router.back(); }
    catch { Alert.alert("Unable to save", "Please try again."); }
    finally { setSaving(false); }
  };
  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5">
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} className="flex-1">
      <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingTop: 10, paddingBottom: 28, gap: 20 }}>
        <View className="flex-row items-center justify-between">
          <View><Text className="text-[29px] font-bold tracking-tight text-foreground">Salary & income</Text><Text className="mt-1 text-sm text-muted">Set the rules for your pay cycle.</Text></View>
          <TouchableOpacity accessibilityLabel="Close salary settings" activeOpacity={0.7} onPress={() => router.back()} className="h-10 w-10 items-center justify-center rounded-full bg-surface"><Text className="text-xl text-muted">×</Text></TouchableOpacity>
        </View>
        <FormField label="Monthly salary" error={errors.amount}><AppTextInput value={salary} onChangeText={setSalary} placeholder="0.00" keyboardType="decimal-pad" /></FormField>
        <FormField label="Currency" error={errors.currency}><AppTextInput value={currency} onChangeText={(value) => setCurrency(value.toUpperCase())} autoCapitalize="characters" maxLength={3} /></FormField>
        <DayOfMonthPicker value={paymentDay} onChange={setPaymentDay} error={errors.salaryPaymentDay} />
        <View className="flex-row items-center justify-between rounded-2xl border border-border bg-surface px-4 py-3">
          <View className="mr-4 flex-1"><Text className="text-[15px] font-bold text-foreground">Automatic monthly salary</Text><Text className="mt-0.5 text-xs leading-4 text-muted">Create the next salary transaction when a new salary cycle begins.</Text></View>
          <Switch accessibilityLabel="Automatic monthly salary" value={automatic} onValueChange={setAutomatic} trackColor={{ false: "#D7DDD9", true: "#198B73" }} thumbColor="#FFFFFF" />
        </View>
        <Text className="text-xs leading-5 text-muted">When a selected day is not in a month, the last calendar day is used consistently.</Text>
        <PrimaryButton label={saving ? "Saving…" : "Save salary settings"} onPress={save} disabled={saving} />
      </ScrollView>
    </KeyboardAvoidingView>
  </ScreenContainer>;
}
