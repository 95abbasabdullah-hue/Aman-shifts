import { useEffect, useMemo, useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, ScrollView, Switch, Text, TouchableOpacity, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { AppTextInput, FormField } from "@/components/finance-form";
import { PrimaryButton } from "@/components/finance-ui";
import { ScreenContainer } from "@/components/screen-container";
import { formatMoney, parseAmountToMinor } from "@/lib/finance/format";
import { useFinance } from "@/lib/finance/provider";
import { validateSavingsGoal, type FieldErrors } from "@/lib/finance/validation";

export default function SavingsGoalFormScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ id?: string }>();
  const { snapshot, savingsGoals, saveSavingsGoal, deleteSavingsGoal } = useFinance();
  const existing = useMemo(() => snapshot.savingsGoals.find((goal) => goal.id === params.id), [params.id, snapshot.savingsGoals]);
  const existingSummary = savingsGoals.find((goal) => goal.id === params.id);
  const [name, setName] = useState("");
  const [target, setTarget] = useState("");
  const [monthlyTarget, setMonthlyTarget] = useState("0.00");
  const [automaticAllocation, setAutomaticAllocation] = useState("0.00");
  const [note, setNote] = useState("");
  const [active, setActive] = useState(true);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => { if (existing) { setName(existing.name); setTarget((existing.targetMinor / 100).toFixed(2)); setMonthlyTarget((existing.monthlyTargetMinor / 100).toFixed(2)); setAutomaticAllocation((existing.automaticAllocationMinor / 100).toFixed(2)); setNote(existing.note ?? ""); setActive(existing.active); } }, [existing]);
  const submit = async () => {
    const input = { name, targetMinor: parseAmountToMinor(target), monthlyTargetMinor: parseAmountToMinor(monthlyTarget), automaticAllocationMinor: parseAmountToMinor(automaticAllocation), note: note.trim() || undefined, active };
    const nextErrors = validateSavingsGoal(input);
    if (Object.keys(nextErrors).length) return setErrors(nextErrors);
    setSaving(true);
    try { await saveSavingsGoal(input, existing?.id); router.back(); } catch { Alert.alert("Unable to save", "Please try again."); } finally { setSaving(false); }
  };
  const confirmDelete = () => Alert.alert("Delete savings goal?", "The goal will be removed. Its prior savings transfers stay in your financial history.", [{ text: "Cancel", style: "cancel" }, { text: "Delete", style: "destructive", onPress: () => { if (existing) { void deleteSavingsGoal(existing.id); router.back(); } } }]);

  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5"><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} className="flex-1"><ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 10, paddingBottom: 28, gap: 20 }}><View className="flex-row items-center justify-between"><View><Text className="text-[29px] font-bold tracking-tight text-foreground">{existing ? "Edit savings goal" : "New savings goal"}</Text><Text className="mt-1 text-sm text-muted">Savings stays separate from spending money.</Text></View><TouchableOpacity activeOpacity={0.7} onPress={() => router.back()} className="h-10 w-10 items-center justify-center rounded-full bg-surface"><Text className="text-xl text-muted">×</Text></TouchableOpacity></View>{existingSummary ? <View className="rounded-2xl bg-success/10 px-4 py-3"><Text className="text-xs font-semibold text-success">CURRENT SAVINGS</Text><Text className="mt-1 text-lg font-bold text-foreground">{formatMoney(existingSummary.savedMinor, snapshot.settings.currency)}</Text></View> : null}<FormField label="Goal name" error={errors.name}><AppTextInput value={name} onChangeText={setName} placeholder="e.g. Car" /></FormField><FormField label="Target amount" error={errors.target}><AppTextInput value={target} onChangeText={setTarget} placeholder="20,000.00" keyboardType="decimal-pad" /></FormField><FormField label="Monthly savings target" error={errors.monthlyTarget}><AppTextInput value={monthlyTarget} onChangeText={setMonthlyTarget} placeholder="0.00" keyboardType="decimal-pad" /></FormField><FormField label="Automatic saving each salary cycle" error={errors.automaticAllocation}><AppTextInput value={automaticAllocation} onChangeText={setAutomaticAllocation} placeholder="1,500.00" keyboardType="decimal-pad" /></FormField><Text className="-mt-3 px-1 text-xs leading-5 text-muted">When salary is recorded, this amount is allocated once to this goal and excluded from available spending.</Text><FormField label="Note (optional)"><AppTextInput value={note} onChangeText={setNote} placeholder="Why this goal matters" multiline style={{ minHeight: 78, paddingTop: 13, textAlignVertical: "top" }} /></FormField><View className="flex-row items-center justify-between rounded-2xl border border-border bg-surface px-4 py-3"><View><Text className="text-[15px] font-bold text-foreground">Goal is active</Text><Text className="mt-0.5 text-xs text-muted">Paused goals receive no automatic deposits.</Text></View><Switch value={active} onValueChange={setActive} trackColor={{ false: "#D7DDD9", true: "#198B73" }} thumbColor="#FFFFFF" /></View><View className="gap-3"><PrimaryButton label={saving ? "Saving…" : "Save savings goal"} onPress={submit} disabled={saving} />{existing ? <TouchableOpacity activeOpacity={0.7} onPress={confirmDelete} className="items-center py-3"><Text className="text-sm font-bold text-error">Delete savings goal</Text></TouchableOpacity> : null}</View></ScrollView></KeyboardAvoidingView></ScreenContainer>;
}
