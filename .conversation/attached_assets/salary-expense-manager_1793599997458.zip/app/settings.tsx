import { useRouter } from "expo-router";
import { ScrollView, Switch, Text, TouchableOpacity, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useFinance } from "@/lib/finance/provider";

function ToggleRow({ label, detail, value, onChange }: { label: string; detail: string; value: boolean; onChange: (value: boolean) => void }) {
  return (
    <View className="flex-row items-center justify-between border-b border-border px-4 py-4 last:border-b-0">
      <View className="mr-4 flex-1">
        <Text className="text-[15px] font-semibold text-foreground">{label}</Text>
        <Text className="mt-1 text-xs leading-5 text-muted">{detail}</Text>
      </View>
      <Switch accessibilityLabel={label} value={value} onValueChange={onChange} trackColor={{ false: "#E9D8A7", true: "#956000" }} thumbColor="#FFFFFF" />
    </View>
  );
}

export default function SettingsScreen() {
  const router = useRouter();
  const { snapshot, updateSettings } = useFinance();
  const preferences = snapshot.settings.soundPreferences;
  const updatePreference = (change: Partial<typeof preferences>) => {
    void updateSettings({ soundPreferences: { ...preferences, ...change } });
  };

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 10, paddingBottom: 32, gap: 18 }}>
        <View className="flex-row items-center justify-between">
          <View className="mr-4 flex-1">
            <Text className="text-[29px] font-bold tracking-tight text-foreground">Settings</Text>
            <Text className="mt-1 text-sm leading-5 text-muted">Choose the feedback that feels right on this device.</Text>
          </View>
          <TouchableOpacity accessibilityLabel="Close settings" onPress={() => router.replace("/more" as never)} className="h-10 w-10 items-center justify-center rounded-full bg-surface">
            <Text className="text-xl text-muted">×</Text>
          </TouchableOpacity>
        </View>

        <View>
          <Text className="mb-2 ml-1 text-xs font-bold tracking-wider text-muted">INTERACTION FEEDBACK</Text>
          <View className="overflow-hidden rounded-2xl border border-border bg-surface">
            <ToggleRow label="Sound effects" detail="Play quiet clicks, confirmations, bill, and savings sounds." value={preferences.enabled} onChange={(enabled) => updatePreference({ enabled })} />
            <ToggleRow label="Haptic feedback" detail="Feel a subtle device tap when a choice changes." value={preferences.hapticsEnabled} onChange={(hapticsEnabled) => updatePreference({ hapticsEnabled })} />
          </View>
        </View>

        <View className="rounded-2xl border border-primary/20 bg-primary/5 p-4">
          <Text className="text-sm font-bold text-foreground">Fine-tune feedback</Text>
          <Text className="mt-1 text-sm leading-5 text-muted">Use Feedback & reminders to choose individual sound types, animation effects, and local reminders.</Text>
          <TouchableOpacity accessibilityLabel="Open detailed feedback preferences" onPress={() => router.push("/premium-preferences" as never)} className="mt-3 self-start rounded-xl bg-primary/10 px-4 py-2.5">
            <Text className="text-sm font-bold text-primary">Open Feedback & reminders</Text>
          </TouchableOpacity>
        </View>

        <Text className="px-2 text-center text-xs leading-5 text-muted">Sounds and haptics remain local. Device mute, Do Not Disturb, and system haptic settings are always respected.</Text>
      </ScrollView>
    </ScreenContainer>
  );
}
