import { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { AppTextInput, FormField } from "@/components/finance-form";
import { PrimaryButton } from "@/components/finance-ui";
import { ScreenContainer } from "@/components/screen-container";
import { parseAmountToMinor } from "@/lib/finance/format";
import { useFinance } from "@/lib/finance/provider";
import { validateSalary, type FieldErrors } from "@/lib/finance/validation";

export default function SetupScreen() {
  const router = useRouter();
  const { snapshot, updateSettings } = useFinance();
  const [salary, setSalary] = useState("");
  const [currency, setCurrency] = useState(snapshot.settings.currency);
  const [paymentDay, setPaymentDay] = useState(String(snapshot.settings.salaryPaymentDay));
  const [errors, setErrors] = useState<FieldErrors>({});
  const [saving, setSaving] = useState(false);

  const save = async () => {
    const settings = { monthlySalaryMinor: parseAmountToMinor(salary), currency: currency.trim().toUpperCase(), salaryPaymentDay: Number(paymentDay) };
    const nextErrors = validateSalary(settings);
    if (Object.keys(nextErrors).length) return setErrors(nextErrors);
    setSaving(true);
    try {
      await updateSettings({ ...settings, onboardingCompleted: true });
      router.replace("/");
    } catch {
      Alert.alert("Unable to save", "Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const skip = async () => {
    await updateSettings({ onboardingCompleted: true });
    router.replace("/");
  };

  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-6"><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} className="flex-1"><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1, paddingVertical: 28 }} keyboardShouldPersistTaps="handled"><View className="flex-1 justify-between gap-9"><View className="gap-7"><View className="gap-3"><View className="h-12 w-12 items-center justify-center rounded-2xl bg-success"><Text className="text-2xl font-black text-white">$</Text></View><View><Text className="text-[32px] leading-[39px] font-bold tracking-tight text-foreground">Set your starting point</Text><Text className="mt-2 text-base leading-6 text-muted">A few details help calculate what is available to spend in each salary cycle.</Text></View></View><View className="gap-5"><FormField label="Monthly salary" error={errors.amount}><AppTextInput value={salary} onChangeText={setSalary} placeholder="10,000.00" keyboardType="decimal-pad" returnKeyType="done" /></FormField><FormField label="Currency" error={errors.currency}><AppTextInput value={currency} onChangeText={(value) => setCurrency(value.toUpperCase())} placeholder="QAR" autoCapitalize="characters" maxLength={3} /></FormField><FormField label="Salary payment day" error={errors.salaryPaymentDay}><AppTextInput value={paymentDay} onChangeText={setPaymentDay} placeholder="27" keyboardType="number-pad" maxLength={2} /></FormField><Text className="text-xs leading-5 text-muted">If a payment day does not exist in a month, the app safely uses that month’s final day.</Text></View></View><View className="gap-4"><PrimaryButton label={saving ? "Saving…" : "Continue"} onPress={save} disabled={saving} /><PrimaryButton label="Set up later" onPress={skip} secondary /></View></View></ScrollView></KeyboardAvoidingView></ScreenContainer>;
}
