import { useMemo, useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import { ChoicePills } from "@/components/finance-form";
import { ScreenContainer } from "@/components/screen-container";
import { SpendingPieChart } from "@/components/spending-pie-chart";
import { formatMoney } from "@/lib/finance/format";
import { selectedPeriodTransactions } from "@/lib/finance/phase3";
import { ledgerItemBreakdown } from "@/lib/finance/statistics-ledger";
import { type StatisticsPeriod } from "@/lib/finance/statistics-navigation";
import { statisticsExitHref } from "@/lib/navigation/statistics-exit";
import { useFinance } from "@/lib/finance/provider";
import { usePremiumAccess } from "@/lib/premium/premium-access-provider";
import { PremiumFeatureLocked } from "@/components/premium-feature-locked";
import { useRouter } from "expo-router";

export default function StatisticsScreen() {
  const { isPremium } = usePremiumAccess();
  if (!isPremium) return <PremiumFeatureLocked feature="statistics" />;
  return <StatisticsContent />;
}

function StatisticsContent() {
  const router = useRouter();
  const { snapshot } = useFinance();
  const [period, setPeriod] = useState<StatisticsPeriod>("current_cycle");
  const periodTransactions = useMemo(() => selectedPeriodTransactions(snapshot, period), [period, snapshot]);
  const total = (type: string) => periodTransactions.filter((item) => item.type === type).reduce((sum, item) => sum + (item.baseAmountMinor ?? item.amountMinor), 0);
  const income = total("income"); const fixed = total("fixed_expense"); const variable = total("variable_expense"); const savingsDeposits = total("savings"); const savingsWithdrawals = total("savings_withdrawal"); const netSavings = savingsDeposits - savingsWithdrawals; const transfersOut = total("transfer_out"); const transfersIn = total("transfer_in"); const remaining = income - fixed - variable - netSavings;
  const spending = useMemo(() => ledgerItemBreakdown(periodTransactions, { excludeIncome: true }), [periodTransactions]);
  const activeDays = Math.max(1, new Set(periodTransactions.filter((item) => item.type === "variable_expense").map((item) => item.date)).size);
  const averageDaily = Math.round(variable / activeDays);
  const periodLabel = period === "current_cycle" ? "Current cycle" : period === "previous_cycle" ? "Previous cycle" : period === "month" ? "Month" : "Year";
  const exitScreen = () => {
    router.replace(statisticsExitHref() as never);
  };

  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5"><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 10, paddingBottom: 28, gap: 18 }}><View className="flex-row items-center justify-between"><View><Text className="text-[29px] font-bold tracking-tight text-foreground">Statistics</Text><Text className="mt-1 text-sm text-muted">Readable local insights from your complete ledger.</Text></View><TouchableOpacity accessibilityRole="button" accessibilityLabel="Close statistics" onPress={exitScreen} className="h-10 w-10 items-center justify-center rounded-full bg-surface"><Text className="text-xl text-muted">×</Text></TouchableOpacity></View><ChoicePills options={["Current cycle", "Previous cycle", "Month", "Year"]} selected={periodLabel} onChange={(value) => setPeriod(value === "Current cycle" ? "current_cycle" : value === "Previous cycle" ? "previous_cycle" : value === "Month" ? "month" : "year")} /><View><SpendingPieChart spending={spending} currency={snapshot.settings.currency} salaryMinor={income} /><Text className="mt-2 text-center text-xs text-muted">Each segment shows the item amount as a share of salary. Salary income is excluded from the chart.</Text></View><View className="overflow-hidden rounded-3xl border border-border bg-surface px-4 py-1">{[["Income", income, "text-success"], ["Fixed bills", fixed, "text-warning"], ["Variable expenses", variable, "text-error"], ["Savings deposits", savingsDeposits, "text-primary"], ["Savings withdrawals", savingsWithdrawals, "text-warning"], ["Net savings", netSavings, "text-primary"], ["Transfers out", transfersOut, "text-muted"], ["Transfers in", transfersIn, "text-muted"], ["Remaining balance", remaining, "text-foreground"], ["Average daily spending", averageDaily, "text-foreground"]].map(([label, amount, color]) => <View key={String(label)} className="flex-row justify-between border-b border-border py-3.5 last:border-b-0"><Text className="text-sm text-muted">{label}</Text><Text className={`text-[15px] font-bold ${color}`}>{formatMoney(Number(amount), snapshot.settings.currency)}</Text></View>)}</View><Text className="px-1 text-xs leading-5 text-muted">Bills, spending, savings, and transfers remain visible by item; income is used only as the percentage base. This view is informational and does not change records.</Text></ScrollView></ScreenContainer>;
}
