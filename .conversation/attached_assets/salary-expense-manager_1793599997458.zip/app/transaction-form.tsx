import { useEffect, useMemo, useState } from "react";
import { KeyboardAvoidingView, Modal, Platform, ScrollView, Switch, Text, TouchableOpacity, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { DatePickerField } from "@/components/date-picker-field";
import { AppTextInput, ChoicePills, FormField } from "@/components/finance-form";
import { PrimaryButton } from "@/components/finance-ui";
import { ScreenContainer } from "@/components/screen-container";
import { todayIsoDate } from "@/lib/finance/cycle";
import { transactionDeleteExit } from "@/lib/finance/transaction-delete-navigation";
import { parseAmountToMinor } from "@/lib/finance/format";
import { homeFixedBillInput, isHomeFixedBillFlow } from "@/lib/finance/home-fixed-bill";
import { useFinance } from "@/lib/finance/provider";
import { usePremiumAccess } from "@/lib/premium/premium-access-provider";
import { PremiumFeatureLocked } from "@/components/premium-feature-locked";
import { BILL_CATEGORIES, EXPENSE_CATEGORIES, type BillCategory, type TransactionType } from "@/lib/finance/types";
import { validateTransaction, type FieldErrors } from "@/lib/finance/validation";

const TYPE_LABELS: Record<TransactionType, string> = {
  income: "Income",
  fixed_expense: "Fixed bill",
  variable_expense: "Expense",
  savings: "Savings",
  savings_withdrawal: "Savings withdrawal",
  transfer_out: "Transfer out",
  transfer_in: "Transfer in",
};

const defaultDescription = (type: TransactionType) =>
  type === "income"
    ? "Income"
    : type === "fixed_expense"
      ? "Fixed bill"
      : type === "savings"
        ? "Savings contribution"
        : type === "savings_withdrawal"
          ? "Savings withdrawal"
          : "Expense";

export default function TransactionFormScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ id?: string; type?: string; source?: string; quickTemplateId?: string }>();
  const { isPremium } = usePremiumAccess();
  const { snapshot, saveTransaction, deleteTransaction, saveBill, accounts } = useFinance();
  const existing = useMemo(
    () => snapshot.transactions.find((transaction) => transaction.id === params.id),
    [params.id, snapshot.transactions],
  );
  const quickTemplate = useMemo(
    () => snapshot.quickExpenseTemplates.find((template) => template.id === params.quickTemplateId),
    [params.quickTemplateId, snapshot.quickExpenseTemplates],
  );
  const [type, setType] = useState<TransactionType>(
    params.type === "income" || params.type === "fixed_expense" ? params.type : "variable_expense",
  );
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("Food");
  const [date, setDate] = useState(todayIsoDate());
  const [description, setDescription] = useState("");
  const [note, setNote] = useState("");
  const [billActive, setBillActive] = useState(true);
  const [accountId, setAccountId] = useState(accounts[0]?.id ?? "");
  const [errors, setErrors] = useState<FieldErrors>({});
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteConfirmationOpen, setDeleteConfirmationOpen] = useState(false);

  useEffect(() => {
    if (!existing) return;
    setType(existing.type);
    setAmount((existing.amountMinor / 100).toFixed(2));
    setCategory(existing.category);
    setDate(existing.date);
    setDescription(existing.description);
    setNote(existing.note ?? "");
    setAccountId(existing.accountId ?? accounts[0]?.id ?? "");
  }, [accounts, existing]);
  useEffect(() => {
    if (existing || !quickTemplate) return;
    setType("variable_expense");
    setAmount((quickTemplate.amountMinor / 100).toFixed(2));
    setCategory(quickTemplate.category);
    setDescription(quickTemplate.name);
    setAccountId(quickTemplate.accountId ?? accounts[0]?.id ?? "");
  }, [accounts, existing, quickTemplate]);

  if (params.quickTemplateId && !isPremium) return <PremiumFeatureLocked feature="quick_expenses" />;

  const categories =
    type === "variable_expense"
      ? EXPENSE_CATEGORIES
      : type === "fixed_expense"
        ? BILL_CATEGORIES
        : type === "income"
          ? ["Salary", "Bonus", "Other"]
          : ["Savings"];

  const selectType = (nextType: TransactionType) => {
    setType(nextType);
    setCategory(
      nextType === "variable_expense"
        ? "Food"
        : nextType === "fixed_expense"
          ? "Other"
          : nextType === "income"
            ? "Salary"
            : "Savings",
    );
  };

  const createsHomeFixedBill = !existing && isHomeFixedBillFlow(params.source, type);

  const returnAfterDelete = () => {
    if (transactionDeleteExit(router.canGoBack()) === "back") {
      router.back();
      return;
    }
    router.replace("/(tabs)/transactions" as never);
  };

  const submit = async () => {
    const cleanDescription = description.trim() || defaultDescription(type);
    const input = {
      type,
      amountMinor: parseAmountToMinor(amount),
      currency: snapshot.settings.currency,
      category,
      date,
      description: cleanDescription,
      note: note.trim() || undefined,
      recurringKey: existing?.recurringKey,
      sourceBillId: existing?.sourceBillId,
      savingsGoalId: existing?.savingsGoalId,
      accountId,
    };
    const nextErrors = validateTransaction(input, snapshot.settings.currency);
    if (Object.keys(nextErrors).length) {
      setErrors(nextErrors);
      return;
    }
    setSaving(true);
    try {
      if (createsHomeFixedBill) {
        await saveBill(homeFixedBillInput({ name: cleanDescription, amountMinor: input.amountMinor, currency: input.currency, category: category as BillCategory, dueDate: date, note: input.note, active: billActive }));
        router.back();
        return;
      }
      await saveTransaction(input, existing?.id);
      router.back();
    } catch {
      setErrors({ form: "Unable to save this transaction. Please try again." });
    } finally {
      setSaving(false);
    }
  };

  const remove = async (transactionId: string) => {
    setDeleting(true);
    try {
      await deleteTransaction(transactionId);
      setDeleteConfirmationOpen(false);
      returnAfterDelete();
    } catch (error) {
      setErrors({
        form: error instanceof Error ? error.message : "Unable to delete this transaction. Please try again.",
      });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5">
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} className="flex-1">
        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingTop: 10, paddingBottom: 28, gap: 20 }}
        >
          <View className="flex-row items-center justify-between">
            <View>
              <Text className="text-[29px] font-bold tracking-tight text-foreground">
                {existing ? "Edit transaction" : "New transaction"}
              </Text>
              <Text className="mt-1 text-sm text-muted">Rates remain offline and user-defined.</Text>
            </View>
            <TouchableOpacity
              accessibilityLabel="Close transaction editor"
              activeOpacity={0.7}
              onPress={() => router.back()}
              className="h-10 w-10 items-center justify-center rounded-full bg-surface"
            >
              <Text className="text-xl text-muted">×</Text>
            </TouchableOpacity>
          </View>

          {errors.form ? <Text className="-mb-2 text-sm font-medium text-error">{errors.form}</Text> : null}

          <FormField label="Transaction type">
            <ChoicePills
              options={["Income", "Fixed bill", "Expense", "Savings", "Savings withdrawal"]}
              selected={TYPE_LABELS[type]}
              onChange={(value) =>
                selectType(
                  value === "Income"
                    ? "income"
                    : value === "Fixed bill"
                      ? "fixed_expense"
                      : value === "Savings"
                        ? "savings"
                        : value === "Savings withdrawal"
                          ? "savings_withdrawal"
                          : "variable_expense",
                )
              }
            />
          </FormField>
          <FormField label="Amount" error={errors.amount}>
            <AppTextInput
              value={amount}
              onChangeText={setAmount}
              placeholder="0.00"
              keyboardType="decimal-pad"
              returnKeyType="done"
            />
          </FormField>
          <FormField label="Description (Optional)">
            <AppTextInput
              value={description}
              onChangeText={setDescription}
              placeholder={
                type === "income"
                  ? "e.g. Salary payment"
                  : type === "savings"
                    ? "e.g. Savings deposit"
                    : "e.g. Weekly groceries"
              }
            />
          </FormField>
          <FormField label="Category">
            <ChoicePills options={categories} selected={category} onChange={setCategory} />
          </FormField>
          {createsHomeFixedBill ? (
            <View className="flex-row items-center justify-between rounded-2xl border border-border bg-surface px-4 py-3">
              <View className="flex-1 pr-4">
                <Text className="text-[15px] font-bold text-foreground">Active fixed bill</Text>
                <Text className="mt-0.5 text-xs leading-4 text-muted">Active bills are added automatically on their monthly due date.</Text>
              </View>
              <Switch accessibilityLabel="Fixed bill is active" value={billActive} onValueChange={setBillActive} trackColor={{ false: "#E9D8A7", true: "#956000" }} thumbColor="#FFFFFF" />
            </View>
          ) : null}
          {accounts.length ? (
            <FormField label="Account">
              <ChoicePills
                options={accounts.map((item) => item.name)}
                selected={accounts.find((item) => item.id === accountId)?.name ?? ""}
                onChange={(value) => setAccountId(accounts.find((item) => item.name === value)?.id ?? "")}
              />
            </FormField>
          ) : null}
          <DatePickerField label="Date" value={date} onChange={setDate} error={errors.date} />
          <FormField label="Note (Optional)">
            <AppTextInput
              value={note}
              onChangeText={setNote}
              placeholder="Add more detail"
              multiline
              style={{ minHeight: 78, paddingTop: 13, textAlignVertical: "top" }}
            />
          </FormField>

          <View className="mt-1 gap-3">
            <PrimaryButton label={saving ? "Saving…" : createsHomeFixedBill ? "Save fixed bill" : "Save transaction"} onPress={submit} disabled={saving || deleting} />
            {existing ? (
              <TouchableOpacity
                accessibilityRole="button"
                accessibilityLabel="Delete transaction"
                accessibilityHint="Opens a confirmation before permanently removing this transaction"
                disabled={deleting || saving}
                activeOpacity={0.7}
                onPress={() => setDeleteConfirmationOpen(true)}
                className="items-center rounded-2xl border border-error/30 bg-surface py-3"
              >
                <Text className="text-sm font-bold text-error">Delete transaction</Text>
              </TouchableOpacity>
            ) : null}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal
        visible={deleteConfirmationOpen}
        transparent
        animationType="fade"
        onRequestClose={() => {
          if (!deleting) setDeleteConfirmationOpen(false);
        }}
      >
        <View className="flex-1 justify-end bg-black/45 px-5 pb-8">
          <View className="rounded-3xl bg-background p-5">
            <Text className="text-xl font-bold text-foreground">Delete transaction?</Text>
            <Text className="mt-2 text-sm leading-5 text-muted">
              This permanently removes the transaction and recalculates all local balances. Linked transfer entries are removed together.
            </Text>
            <View className="mt-5 gap-3">
              <TouchableOpacity
                accessibilityRole="button"
                disabled={deleting}
                activeOpacity={0.72}
                onPress={() => setDeleteConfirmationOpen(false)}
                className="items-center rounded-2xl bg-surface py-3"
              >
                <Text className="text-sm font-bold text-foreground">Keep transaction</Text>
              </TouchableOpacity>
              <TouchableOpacity
                accessibilityRole="button"
                accessibilityLabel="Confirm delete transaction"
                disabled={deleting || !existing}
                activeOpacity={0.72}
                onPress={() => {
                  if (existing) void remove(existing.id);
                }}
                className="items-center rounded-2xl bg-error py-3"
              >
                <Text className="text-sm font-bold text-white">{deleting ? "Deleting…" : "Delete permanently"}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
