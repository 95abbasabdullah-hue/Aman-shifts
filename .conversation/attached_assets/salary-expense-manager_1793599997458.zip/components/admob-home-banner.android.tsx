import { useEffect, useState } from "react";
import { ActivityIndicator, Platform, StyleSheet, useWindowDimensions, View } from "react-native";
import { BannerAd, BannerAdSize } from "react-native-google-mobile-ads";

import { useAdMob } from "@/lib/ads/admob-provider";
import { canShowHomeBanner, resolveBannerAdUnitId } from "@/lib/ads/admob-config";
import { useColors } from "@/hooks/use-colors";

type BannerStatus = "loading" | "loaded" | "failed";

export function AdMobHomeBanner({ isPremium }: { isPremium: boolean }) {
  const { isSdkReady } = useAdMob();
  const colors = useColors();
  const { width: viewportWidth } = useWindowDimensions();
  const isTestBuild = typeof __DEV__ === "boolean" ? __DEV__ : false;
  const unitId = resolveBannerAdUnitId(isTestBuild);
  const bannerWidth = Math.max(1, Math.floor(viewportWidth - 32));
  const [status, setStatus] = useState<BannerStatus>("loading");
  const [bannerHeight, setBannerHeight] = useState(52);
  const shouldRender = canShowHomeBanner({
    isAndroid: Platform.OS === "android",
    isPremium,
    isSdkReady,
  });

  useEffect(() => {
    setStatus("loading");
    setBannerHeight(52);
  }, [bannerWidth, unitId]);

  if (!shouldRender || status === "failed") return null;

  return (
    <View
      accessibilityLabel="Advertisement"
      accessibilityRole="summary"
      style={[styles.container, { backgroundColor: colors.surface, borderColor: colors.border, minHeight: bannerHeight }]}
    >
      {status === "loading" ? <ActivityIndicator color={colors.muted} size="small" style={styles.loader} /> : null}
      <BannerAd
        key={`${unitId}-${bannerWidth}`}
        unitId={unitId}
        size={BannerAdSize.LARGE_ANCHORED_ADAPTIVE_BANNER}
        width={bannerWidth}
        onAdLoaded={({ height }) => {
          setBannerHeight(Math.max(52, height));
          setStatus("loaded");
        }}
        onAdFailedToLoad={() => setStatus("failed")}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
    justifyContent: "center",
    marginHorizontal: 16,
    marginTop: 16,
    overflow: "hidden",
  },
  loader: {
    position: "absolute",
  },
});
