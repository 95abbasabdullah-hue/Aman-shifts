/**
 * Native Google Mobile Ads are not available in web previews. Android receives
 * the platform-specific implementation in admob-home-banner.android.tsx.
 */
export function AdMobHomeBanner(_: { isPremium: boolean }) {
  return null;
}

