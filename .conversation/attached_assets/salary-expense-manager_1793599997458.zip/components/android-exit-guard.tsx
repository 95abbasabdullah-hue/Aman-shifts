import { useEffect } from "react";
import { BackHandler, Platform } from "react-native";
import { useRouter } from "expo-router";
import { useExitConfirmation } from "@/components/exit-confirmation-provider";
import { resolveRootBackAction } from "@/lib/navigation/root-back";

/** Last-line Android Back protection for direct links or any no-history screen outside a focused root-tab listener. */
export function AndroidExitGuard() {
  const router = useRouter();
  const { isExitDialogOpen, requestExitConfirmation } = useExitConfirmation();
  useEffect(() => {
    if (Platform.OS !== "android") return undefined;
    const subscription = BackHandler.addEventListener("hardwareBackPress", () => {
      const action = resolveRootBackAction(Platform.OS, isExitDialogOpen(), router.canGoBack());
      if (action === "delegate") return false;
      if (action === "consume") return true;
      requestExitConfirmation();
      return true;
    });
    return () => subscription.remove();
  }, [isExitDialogOpen, requestExitConfirmation, router]);
  return null;
}
