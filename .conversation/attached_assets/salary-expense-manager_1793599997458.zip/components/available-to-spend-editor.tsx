import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { KeyboardAvoidingView, Modal, Platform, Text, TouchableOpacity, View } from "react-native";
import { AppTextInput } from "@/components/finance-form";
import { PrimaryButton } from "@/components/finance-ui";
import { AnimatedMoney } from "@/components/finance-motion";
import { useColors } from "@/hooks/use-colors";
import { buildAvailableToSpendAdjustment } from "@/lib/finance/available-to-spend-adjustment";
import { todayIsoDate } from "@/lib/finance/cycle";
import { parseAmountToMinor } from "@/lib/finance/format";
import { useFinance } from "@/lib/finance/provider";

function amountInputValue(amountMinor: number) {
  return (Math.max(0, amountMinor) / 100).toFixed(2);
}

export function AvailableToSpendEditor({ availableMinor, currency, animationEnabled }: { availableMinor: number; currency: string; animationEnabled: boolean }) {
  const colors = useColors();
  const { accounts, saveTransaction } = useFinance();
  const [open, setOpen] = useState(false);
  const [target, setTarget] = useState(amountInputValue(availableMinor));
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const openEditor = () => {
    setTarget(amountInputValue(availableMinor));
    setError("");
    setOpen(true);
  };

  const saveTarget = async () => {
    const targetAvailableMinor = parseAmountToMinor(target);
    if (!Number.isInteger(targetAvailableMinor) || targetAvailableMinor < 0) {
      setError("Enter a valid amount of zero or more.");
      return;
    }

    try {
      const adjustment = buildAvailableToSpendAdjustment({
        currentAvailableMinor: availableMinor,
        targetAvailableMinor,
        currency,
        date: todayIsoDate(),
        accountId: accounts[0]?.id,
      });
      if (!adjustment) {
        setOpen(false);
        return;
      }
      setSaving(true);
      await saveTransaction(adjustment);
      setOpen(false);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Unable to update the available amount.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <TouchableOpacity
        accessibilityRole="button"
        accessibilityLabel={`Available to spend: ${currency} ${(availableMinor / 100).toFixed(2)}`}
        accessibilityHint="Opens an editor to adjust the available amount with a labeled ledger entry"
        activeOpacity={0.72}
        onPress={openEditor}
        className="rounded-2xl"
      >
        <View className="flex-row items-center gap-2">
          <AnimatedMoney amountMinor={availableMinor} currency={currency} enabled={animationEnabled} style={{ color: "#302310", flexShrink: 1 }} className="text-[34px] leading-[42px] font-bold tracking-tight" />
          <View accessibilityElementsHidden importantForAccessibility="no-hide-descendants" style={{ backgroundColor: `${colors.primary}16` }} className="h-7 w-7 items-center justify-center rounded-full">
            <MaterialIcons name="edit" size={15} color={colors.primary} />
          </View>
        </View>
        <View className="mt-1 flex-row items-center">
          <Text style={{ color: colors.primary }} className="text-xs font-bold">Tap amount to adjust</Text>
        </View>
      </TouchableOpacity>

      <Modal visible={open} transparent animationType="fade" onRequestClose={() => !saving && setOpen(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} className="flex-1 justify-end bg-black/45 px-4 pb-6">
          <View className="rounded-[28px] border border-border bg-background p-5">
            <View className="flex-row items-start justify-between gap-4">
              <View className="flex-1">
                <Text className="text-xl font-bold text-foreground">Adjust available to spend</Text>
                <Text className="mt-1 text-sm leading-5 text-muted">Set the amount you want available in this salary cycle.</Text>
              </View>
              <TouchableOpacity accessibilityRole="button" accessibilityLabel="Close available amount editor" disabled={saving} onPress={() => setOpen(false)} className="h-10 w-10 items-center justify-center rounded-full bg-surface">
                <MaterialIcons name="close" size={21} color={colors.muted} />
              </TouchableOpacity>
            </View>

            <View className="mt-5 gap-2">
              <Text className="text-sm font-bold text-foreground">Available amount ({currency})</Text>
              <AppTextInput value={target} onChangeText={setTarget} placeholder="0.00" keyboardType="decimal-pad" returnKeyType="done" editable={!saving} />
              {error ? <Text className="text-xs font-medium text-error">{error}</Text> : null}
            </View>

            <View className="mt-4 rounded-2xl bg-accentSoft px-4 py-3">
              <Text className="text-sm font-bold text-foreground">Your records stay accurate</Text>
              <Text className="mt-1 text-xs leading-5 text-muted">Saving creates one clearly labeled local adjustment in your transaction history. Existing salary, bills, and expenses are not changed.</Text>
            </View>

            <View className="mt-5 flex-row gap-3">
              <TouchableOpacity accessibilityRole="button" disabled={saving} onPress={() => setOpen(false)} className="flex-1 items-center rounded-2xl border border-border bg-surface py-3">
                <Text className="text-sm font-bold text-muted">Cancel</Text>
              </TouchableOpacity>
              <View className="flex-1"><PrimaryButton label={saving ? "Saving…" : "Save adjustment"} onPress={saveTarget} disabled={saving} /></View>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </>
  );
}
