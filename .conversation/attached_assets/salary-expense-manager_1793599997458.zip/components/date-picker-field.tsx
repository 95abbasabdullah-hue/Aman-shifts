import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useMemo, useState } from "react";
import { Modal, Text, TouchableOpacity, View } from "react-native";
import { calendarMonthCells, parseCalendarDate, shiftCalendarMonth, type CalendarCell } from "@/lib/finance/calendar";
import { useColors } from "@/hooks/use-colors";

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function displayDate(value: string) {
  return parseCalendarDate(value).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

export function DatePickerField({ value, onChange, label = "Date", error }: { value: string; onChange: (value: string) => void; label?: string; error?: string }) {
  const colors = useColors();
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState(value);
  const [visibleMonth, setVisibleMonth] = useState(() => parseCalendarDate(value));
  const cells = useMemo(() => calendarMonthCells(visibleMonth), [visibleMonth]);

  const openPicker = () => {
    const current = parseCalendarDate(value);
    setDraft(value);
    setVisibleMonth(new Date(current.getFullYear(), current.getMonth(), 1, 12));
    setOpen(true);
  };

  const dismiss = () => setOpen(false);
  const confirm = () => {
    onChange(draft);
    dismiss();
  };
  const monthLabel = visibleMonth.toLocaleDateString(undefined, { month: "long", year: "numeric" });

  return (
    <View className="gap-2">
      <Text className="text-sm font-bold text-foreground">{label}</Text>
      <TouchableOpacity
        accessibilityRole="button"
        accessibilityLabel={`${label}: ${displayDate(value)}`}
        accessibilityHint="Opens a calendar to select a date"
        activeOpacity={0.75}
        onPress={openPicker}
        className={`min-h-[52px] flex-row items-center justify-between rounded-2xl border bg-surface px-4 ${error ? "border-error" : "border-border"}`}
      >
        <Text className="text-base text-foreground">{displayDate(value)}</Text>
        <MaterialIcons name="calendar-month" size={22} color={colors.primary} />
      </TouchableOpacity>

      <Modal visible={open} transparent animationType="fade" onRequestClose={dismiss}>
        <View className="flex-1 justify-end bg-black/45 px-4 pb-6">
          <View className="rounded-[28px] border border-border bg-background p-5">
            <View className="flex-row items-center justify-between">
              <Text className="text-xl font-bold text-foreground">Select {label.toLowerCase()}</Text>
              <TouchableOpacity accessibilityRole="button" accessibilityLabel="Close calendar" onPress={dismiss} className="h-10 w-10 items-center justify-center rounded-full bg-surface">
                <MaterialIcons name="close" size={21} color={colors.muted} />
              </TouchableOpacity>
            </View>

            <View className="mt-5 flex-row items-center justify-between">
              <TouchableOpacity accessibilityRole="button" accessibilityLabel="Previous month" onPress={() => setVisibleMonth((month: Date) => shiftCalendarMonth(month, -1))} className="h-10 w-10 items-center justify-center rounded-xl bg-surface">
                <MaterialIcons name="chevron-left" size={24} color={colors.primary} />
              </TouchableOpacity>
              <Text className="text-base font-bold text-foreground">{monthLabel}</Text>
              <TouchableOpacity accessibilityRole="button" accessibilityLabel="Next month" onPress={() => setVisibleMonth((month: Date) => shiftCalendarMonth(month, 1))} className="h-10 w-10 items-center justify-center rounded-xl bg-surface">
                <MaterialIcons name="chevron-right" size={24} color={colors.primary} />
              </TouchableOpacity>
            </View>

            <View className="mt-4 flex-row">
              {WEEKDAYS.map((weekday) => <Text key={weekday} className="w-[14.285%] text-center text-xs font-bold text-muted">{weekday}</Text>)}
            </View>
            <View className="mt-2 flex-row flex-wrap">
              {cells.map((cell: CalendarCell, index: number) => {
                if (!cell) return <View key={`empty-${index}`} className="w-[14.285%] aspect-square" />;
                const selected = cell.isoDate === draft;
                return (
                  <View key={cell.isoDate} className="w-[14.285%] aspect-square items-center justify-center">
                    <TouchableOpacity
                      accessibilityRole="button"
                      accessibilityLabel={displayDate(cell.isoDate)}
                      accessibilityState={{ selected }}
                      activeOpacity={0.72}
                      onPress={() => setDraft(cell.isoDate)}
                      style={{ backgroundColor: selected ? colors.primary : "transparent" }}
                      className="h-10 w-10 items-center justify-center rounded-full"
                    >
                      <Text style={{ color: selected ? "#FFFFFF" : colors.foreground }} className="text-sm font-semibold">{cell.day}</Text>
                    </TouchableOpacity>
                  </View>
                );
              })}
            </View>

            <View className="mt-5 flex-row gap-3">
              <TouchableOpacity accessibilityRole="button" onPress={dismiss} className="flex-1 items-center rounded-2xl border border-border bg-surface py-3">
                <Text className="text-sm font-bold text-muted">Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity accessibilityRole="button" accessibilityLabel="Confirm selected date" onPress={confirm} style={{ backgroundColor: colors.primary }} className="flex-1 items-center rounded-2xl py-3">
                <Text className="text-sm font-bold text-white">Confirm date</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
      {error ? <Text className="text-xs leading-4 text-error">{error}</Text> : null}
    </View>
  );
}
