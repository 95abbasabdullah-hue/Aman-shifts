import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { Modal, Text, TouchableOpacity, View } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { normalizeSalaryPaymentDay, SALARY_PAYMENT_DAYS } from "@/lib/finance/payment-day-picker";

export function DayOfMonthPicker({ value, onChange, error }: { value: number; onChange: (value: number) => void; error?: string }) {
  const colors = useColors();
  const [open, setOpen] = useState(false);
  const [draftDay, setDraftDay] = useState(normalizeSalaryPaymentDay(value));
  const openPicker = () => { setDraftDay(normalizeSalaryPaymentDay(value)); setOpen(true); };
  const confirm = () => { onChange(draftDay); setOpen(false); };

  return (
    <View className="gap-2">
      <Text className="text-sm font-bold text-foreground">Salary payment day</Text>
      <TouchableOpacity accessibilityRole="button" accessibilityLabel={`Salary payment day: ${value}`} accessibilityHint="Opens a calendar to choose the salary payment day" activeOpacity={0.75} onPress={openPicker} className={`min-h-[52px] flex-row items-center justify-between rounded-2xl border bg-surface px-4 ${error ? "border-error" : "border-border"}`}>
        <Text className="text-base text-foreground">Day {value} of each month</Text>
        <MaterialIcons name="calendar-month" size={22} color={colors.primary} />
      </TouchableOpacity>
      {error ? <Text className="text-xs text-error">{error}</Text> : null}

      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <View className="flex-1 justify-end bg-black/45 px-4 pb-6">
          <View className="rounded-[28px] border border-border bg-background p-5">
            <View className="flex-row items-start justify-between gap-4">
              <View className="flex-1"><Text className="text-xl font-bold text-foreground">Choose payment day</Text><Text className="mt-1 text-sm leading-5 text-muted">The last day is used when a month is shorter.</Text></View>
              <TouchableOpacity accessibilityRole="button" accessibilityLabel="Close payment day calendar" onPress={() => setOpen(false)} className="h-10 w-10 items-center justify-center rounded-full bg-surface"><MaterialIcons name="close" size={21} color={colors.muted} /></TouchableOpacity>
            </View>
            <View className="mt-5 flex-row"><Text className="w-[14.285%] text-center text-xs font-bold text-muted">1</Text><Text className="w-[14.285%] text-center text-xs font-bold text-muted">2</Text><Text className="w-[14.285%] text-center text-xs font-bold text-muted">3</Text><Text className="w-[14.285%] text-center text-xs font-bold text-muted">4</Text><Text className="w-[14.285%] text-center text-xs font-bold text-muted">5</Text><Text className="w-[14.285%] text-center text-xs font-bold text-muted">6</Text><Text className="w-[14.285%] text-center text-xs font-bold text-muted">7</Text></View>
            <View className="mt-2 flex-row flex-wrap">
              {SALARY_PAYMENT_DAYS.map((day) => {
                const selected = day === draftDay;
                return <View key={day} className="w-[14.285%] aspect-square items-center justify-center"><TouchableOpacity accessibilityRole="button" accessibilityLabel={`Day ${day}`} accessibilityState={{ selected }} activeOpacity={0.72} onPress={() => setDraftDay(day)} style={{ backgroundColor: selected ? colors.primary : "transparent" }} className="h-10 w-10 items-center justify-center rounded-full"><Text style={{ color: selected ? "#FFFFFF" : colors.foreground }} className="text-sm font-bold">{day}</Text></TouchableOpacity></View>;
              })}
            </View>
            <View className="mt-5 flex-row gap-3"><TouchableOpacity accessibilityRole="button" onPress={() => setOpen(false)} className="flex-1 items-center rounded-2xl border border-border bg-surface py-3"><Text className="text-sm font-bold text-muted">Cancel</Text></TouchableOpacity><TouchableOpacity accessibilityRole="button" accessibilityLabel="Confirm salary payment day" onPress={confirm} style={{ backgroundColor: colors.primary }} className="flex-1 items-center rounded-2xl py-3"><Text className="text-sm font-bold text-white">Confirm day</Text></TouchableOpacity></View>
          </View>
        </View>
      </Modal>
    </View>
  );
}
