import { Modal, Text, TouchableOpacity, View } from "react-native";

export function DeleteConfirmationSheet({
  visible,
  title,
  detail,
  error,
  deleting,
  onCancel,
  onConfirm,
}: {
  visible: boolean;
  title: string;
  detail: string;
  error?: string;
  deleting: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={() => { if (!deleting) onCancel(); }}>
      <View className="flex-1 justify-end bg-black/45 px-4 pb-6">
        <View className="rounded-[28px] border border-border bg-background p-5">
          <Text className="text-xl font-bold text-foreground">{title}</Text>
          <Text className="mt-2 text-sm leading-5 text-muted">{detail}</Text>
          {error ? <Text className="mt-3 text-sm font-medium text-error">{error}</Text> : null}
          <View className="mt-5 flex-row gap-3">
            <TouchableOpacity accessibilityRole="button" disabled={deleting} onPress={onCancel} className="flex-1 items-center rounded-2xl border border-border bg-surface py-3">
              <Text className="text-sm font-bold text-muted">Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity accessibilityRole="button" accessibilityLabel="Delete permanently" disabled={deleting} onPress={onConfirm} className="flex-1 items-center rounded-2xl bg-error py-3">
              <Text className="text-sm font-bold text-white">{deleting ? "Deleting…" : "Delete permanently"}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}
