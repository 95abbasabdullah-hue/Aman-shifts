import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { Animated, BackHandler, Modal, Text, TouchableOpacity, View } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { useFinance } from "@/lib/finance/provider";
import { exitConfirmationFadeDuration } from "@/lib/navigation/exit-confirmation-motion";

type ExitConfirmationContextValue = {
  isExitDialogOpen: () => boolean;
  requestExitConfirmation: () => void;
};

const ExitConfirmationContext = createContext<ExitConfirmationContextValue | null>(null);

export function ExitConfirmationProvider({ children }: { children: ReactNode }) {
  const colors = useColors();
  const { snapshot } = useFinance();
  const [visible, setVisible] = useState(false);
  const visibleRef = useRef(false);
  const fade = useRef(new Animated.Value(0)).current;
  const duration = exitConfirmationFadeDuration(snapshot.settings.animationEffectsEnabled);

  useEffect(() => {
    if (!visible) return;
    fade.setValue(0);
    const animation = Animated.timing(fade, { toValue: 1, duration, useNativeDriver: true });
    animation.start();
    return () => animation.stop();
  }, [duration, fade, visible]);

  const dismiss = useCallback(() => {
    visibleRef.current = false;
    setVisible(false);
  }, []);
  const requestExitConfirmation = useCallback(() => {
    if (visibleRef.current) return;
    visibleRef.current = true;
    setVisible(true);
  }, []);
  const isExitDialogOpen = useCallback(() => visibleRef.current, []);

  return (
    <ExitConfirmationContext.Provider value={{ isExitDialogOpen, requestExitConfirmation }}>
      {children}
      <Modal visible={visible} transparent animationType="none" onRequestClose={dismiss} statusBarTranslucent>
        <Animated.View style={{ opacity: fade }} className="flex-1 justify-end bg-black/45 px-4 pb-6">
          <View className="rounded-[28px] border border-border bg-background p-5">
            <View className="flex-row items-start gap-3">
              <View style={{ backgroundColor: `${colors.primary}16` }} className="h-11 w-11 items-center justify-center rounded-2xl">
                <MaterialIcons name="exit-to-app" size={22} color={colors.primary} />
              </View>
              <View className="flex-1">
                <Text className="text-xl font-bold text-foreground">Leave Salary & Expense Manager?</Text>
                <Text className="mt-1 text-sm leading-5 text-muted">Your financial data is saved on this device. Do you want to leave the app?</Text>
              </View>
            </View>
            <View className="mt-5 flex-row gap-3">
              <TouchableOpacity accessibilityRole="button" accessibilityLabel="Stay in Salary and Expense Manager" activeOpacity={0.72} onPress={dismiss} className="flex-1 items-center rounded-2xl border border-border bg-surface py-3">
                <Text className="text-sm font-bold text-muted">Stay</Text>
              </TouchableOpacity>
              <TouchableOpacity accessibilityRole="button" accessibilityLabel="Leave Salary and Expense Manager" activeOpacity={0.72} onPress={() => BackHandler.exitApp()} className="flex-1 items-center rounded-2xl bg-error py-3">
                <Text className="text-sm font-bold text-white">Leave</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Animated.View>
      </Modal>
    </ExitConfirmationContext.Provider>
  );
}

export function useExitConfirmation() {
  const context = useContext(ExitConfirmationContext);
  if (!context) throw new Error("useExitConfirmation must be used inside ExitConfirmationProvider.");
  return context;
}
