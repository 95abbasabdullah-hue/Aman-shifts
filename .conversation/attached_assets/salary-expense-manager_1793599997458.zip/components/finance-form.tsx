import { forwardRef, type ComponentProps, type ReactNode } from "react";
import { StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { resolveTextInputEditable } from "@/lib/finance/input-behavior";
import { playSelectionHaptic } from "@/lib/finance/local-haptics";
import { useFinance } from "@/lib/finance/provider";

export function FormField({ label, error, children }: { label: string; error?: string; children: ReactNode }) {
  return <View className="gap-2"><Text className="ml-1 text-sm font-bold text-foreground">{label}</Text>{children}{error ? <Text className="ml-1 text-xs text-error">{error}</Text> : null}</View>;
}

export const AppTextInput = forwardRef<TextInput, ComponentProps<typeof TextInput>>(function AppTextInput(
  { editable, placeholderTextColor, selectionColor, style, onChangeText, ...inputProps },
  ref,
) {
  const colors = useColors();
  return (
    <TextInput
      ref={ref}
      {...inputProps}
      editable={resolveTextInputEditable(editable)}
      onChangeText={(value) => {
        onChangeText?.(value);
      }}
      placeholderTextColor={placeholderTextColor ?? colors.muted}
      selectionColor={selectionColor ?? colors.primary}
      style={[styles.input, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground }, style]}
    />
  );
});

export function ChoicePills({
  options,
  selected,
  onChange,
}: {
  options: string[];
  selected: string;
  onChange: (option: string) => void;
}) {
  const colors = useColors();
  const { snapshot } = useFinance();
  return <View style={styles.pills}>{options.map((option) => <TouchableOpacity key={option} activeOpacity={0.75} onPress={() => { if (option !== selected) playSelectionHaptic(snapshot.settings.soundPreferences); onChange(option); }} style={[styles.pill, { borderColor: colors.border, backgroundColor: colors.surface }, selected === option && { borderColor: colors.primary, backgroundColor: colors.primary }]}><Text style={[styles.pillText, { color: colors.foreground }, selected === option && styles.pillTextSelected]}>{option}</Text></TouchableOpacity>)}</View>;
}

const styles = StyleSheet.create({
  input: {
    minHeight: 50,
    borderWidth: 1,
    borderRadius: 15,
    paddingHorizontal: 14,
    fontSize: 16,
  },
  pills: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  pill: { borderWidth: 1, borderRadius: 14, minHeight: 42, paddingHorizontal: 13, alignItems: "center", justifyContent: "center" },
  pillText: { fontSize: 13, fontWeight: "700" },
  pillTextSelected: { color: "#FFFFFF" },
});
