import { AccessibilityInfo, Animated, Easing, Text, View, type StyleProp, type TextStyle, type ViewStyle } from "react-native";
import { useEffect, useRef, useState, type PropsWithChildren } from "react";
import { formatMoney } from "@/lib/finance/format";
import type { PremiumFeedbackEvent } from "@/lib/finance/types";
import { useColors } from "@/hooks/use-colors";

export function useReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    void AccessibilityInfo.isReduceMotionEnabled().then(setReduced);
    const subscription = AccessibilityInfo.addEventListener("reduceMotionChanged", setReduced);
    return () => subscription.remove();
  }, []);
  return reduced;
}

export function AnimatedMoney({ amountMinor, currency, enabled, style, className }: { amountMinor: number; currency: string; enabled: boolean; style?: StyleProp<TextStyle>; className?: string }) {
  const reducedMotion = useReducedMotion(); const value = useRef(new Animated.Value(amountMinor)).current; const [display, setDisplay] = useState(amountMinor);
  useEffect(() => {
    const listener = value.addListener(({ value: next }) => setDisplay(Math.round(next)));
    if (!enabled || reducedMotion) { value.stopAnimation(); value.setValue(amountMinor); setDisplay(amountMinor); return () => value.removeListener(listener); }
    Animated.timing(value, { toValue: amountMinor, duration: 260, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
    return () => { value.stopAnimation(); value.removeListener(listener); };
  }, [amountMinor, enabled, reducedMotion, value]);
  return <Text accessibilityLabel={`Available balance ${formatMoney(display, currency)}`} style={style} className={className} numberOfLines={1} adjustsFontSizeToFit>{formatMoney(display, currency)}</Text>;
}

export function MotionEntrance({ children, enabled, delay = 0, style }: PropsWithChildren<{ enabled: boolean; delay?: number; style?: StyleProp<ViewStyle> }>) {
  const reducedMotion = useReducedMotion(); const opacity = useRef(new Animated.Value(enabled && !reducedMotion ? 0 : 1)).current; const translateY = useRef(new Animated.Value(enabled && !reducedMotion ? 8 : 0)).current;
  useEffect(() => { if (!enabled || reducedMotion) { opacity.setValue(1); translateY.setValue(0); return; } opacity.setValue(0); translateY.setValue(8); Animated.parallel([Animated.timing(opacity, { toValue: 1, duration: 180, delay, useNativeDriver: true }), Animated.timing(translateY, { toValue: 0, duration: 180, delay, easing: Easing.out(Easing.cubic), useNativeDriver: true })]).start(); }, [delay, enabled, opacity, reducedMotion, translateY]);
  return <Animated.View style={[style, { opacity, transform: [{ translateY }] }]}>{children}</Animated.View>;
}

export function AnimatedProgress({ progress, enabled, color }: { progress: number; enabled: boolean; color?: string }) {
  const colors = useColors();
  const resolvedColor = color ?? colors.primary;
  const reducedMotion = useReducedMotion(); const value = useRef(new Animated.Value(enabled && !reducedMotion ? 0 : Math.min(100, Math.max(0, progress)))).current; const safe = Math.min(100, Math.max(0, progress));
  useEffect(() => { if (!enabled || reducedMotion) { value.setValue(safe); return; } value.setValue(0); Animated.timing(value, { toValue: safe, duration: 320, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start(); }, [enabled, reducedMotion, safe, value]);
  return <View className="mt-2 h-2 overflow-hidden rounded-full bg-border"><Animated.View style={{ height: "100%", backgroundColor: resolvedColor, borderRadius: 999, width: value.interpolate({ inputRange: [0, 100], outputRange: ["0%", "100%"] }) }} /></View>;
}

export function PremiumFeedbackBanner({ event, currency, enabled, onDismiss }: { event: PremiumFeedbackEvent | null; currency: string; enabled: boolean; onDismiss: () => void }) {
  useEffect(() => { if (!event) return; const timeout = setTimeout(onDismiss, 3600); return () => clearTimeout(timeout); }, [event, onDismiss]);
  if (!event) return null;
  return <MotionEntrance enabled={enabled} style={{ marginBottom: 4 }}><View accessibilityRole="alert" className="rounded-2xl border border-success/30 bg-success/10 px-4 py-3"><Text className="text-[15px] font-bold text-success">{event.title}</Text><Text className="mt-0.5 text-sm text-foreground">{event.detail} · {formatMoney(event.amountMinor, currency)}</Text></View></MotionEntrance>;
}
