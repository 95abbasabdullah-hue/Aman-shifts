import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { ReactNode } from "react";
import { ActivityIndicator, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { formatDate, formatMoney } from "@/lib/finance/format";
import type { FinanceTransaction } from "@/lib/finance/types";

export function PrimaryButton({
  label,
  onPress,
  icon,
  disabled = false,
  secondary = false,
}: {
  label: string;
  onPress: () => void;
  icon?: React.ComponentProps<typeof MaterialIcons>["name"];
  disabled?: boolean;
  secondary?: boolean;
}) {
  const colors = useColors();
  return (
    <TouchableOpacity
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled }}
      activeOpacity={0.82}
      disabled={disabled}
      onPress={onPress}
      style={[styles.button, { backgroundColor: secondary ? colors.accentSoft : colors.primary, borderColor: secondary ? colors.border : colors.primary }, secondary && styles.secondaryButton, disabled && styles.disabled]}
    >
      {icon ? <MaterialIcons name={icon} size={19} color={secondary ? colors.primary : "#FFFFFF"} /> : null}
      <Text style={[styles.buttonText, secondary && { color: colors.primary }]}>{label}</Text>
    </TouchableOpacity>
  );
}

export function LoadingScreen() {
  const colors = useColors();
  return (
    <View className="flex-1 items-center justify-center bg-background gap-3" accessibilityRole="progressbar" accessibilityLabel="Preparing your ledger">
      <ActivityIndicator size="large" color={colors.primary} />
      <Text className="text-sm text-muted">Preparing your ledger…</Text>
    </View>
  );
}

export function ScreenTitle({ title, subtitle, right }: { title: string; subtitle?: string; right?: ReactNode }) {
  return (
    <View className="flex-row items-start justify-between gap-4 mb-5">
      <View className="flex-1 gap-1">
        <Text className="text-[30px] font-bold tracking-tight text-foreground">{title}</Text>
        {subtitle ? <Text className="text-sm leading-5 text-muted">{subtitle}</Text> : null}
      </View>
      {right}
    </View>
  );
}

export function TransactionRow({
  transaction,
  onPress,
  onLongPress,
}: {
  transaction: FinanceTransaction;
  onPress?: () => void;
  onLongPress?: () => void;
}) {
  const colors = useColors();
  const meta = transaction.type === "income"
    ? { label: "Income", icon: "south-west" as const, color: colors.success, prefix: "+" }
    : transaction.type === "fixed_expense"
      ? { label: "Fixed bill", icon: "receipt-long" as const, color: colors.warning, prefix: "−" }
      : transaction.type === "savings"
        ? { label: "Savings transfer", icon: "savings" as const, color: colors.primary, prefix: "↗" }
        : transaction.type === "savings_withdrawal"
          ? { label: "Savings withdrawal", icon: "savings" as const, color: colors.success, prefix: "↙" }
          : transaction.type === "transfer_out"
            ? { label: "Account transfer", icon: "swap-horiz" as const, color: colors.primary, prefix: "↗" }
            : transaction.type === "transfer_in"
              ? { label: "Account transfer", icon: "swap-horiz" as const, color: colors.success, prefix: "↙" }
          : { label: "Expense", icon: "shopping-bag" as const, color: colors.error, prefix: "−" };

  return (
    <TouchableOpacity accessibilityRole={onPress || onLongPress ? "button" : "text"} accessibilityLabel={`${transaction.description}, ${meta.label}, ${meta.prefix}${formatMoney(transaction.amountMinor, transaction.currency)}, ${formatDate(transaction.date)}`} accessibilityHint={onLongPress ? "Tap to edit. Long press to open the delete choice." : onPress ? "Opens transaction details" : undefined} activeOpacity={onPress || onLongPress ? 0.7 : 1} disabled={!onPress && !onLongPress} onPress={onPress} onLongPress={onLongPress} delayLongPress={450} style={styles.rowTouch}>
      <View className="flex-row items-center gap-3 rounded-2xl bg-surface border border-border px-3.5 py-3">
        <View style={[styles.transactionIcon, { backgroundColor: `${meta.color}20` }]}>
          <MaterialIcons name={meta.icon} size={20} color={meta.color} />
        </View>
        <View className="flex-1 gap-0.5">
          <Text className="text-[15px] font-semibold text-foreground" numberOfLines={1}>{transaction.description}</Text>
          <Text className="text-xs text-muted" numberOfLines={1}>{formatDate(transaction.date)} · {transaction.category}</Text>
        </View>
        <View className="items-end gap-0.5">
          <Text style={[styles.transactionAmount, { color: meta.color }]}>{meta.prefix}{formatMoney(transaction.amountMinor, transaction.currency)}</Text>
          <Text className="text-[11px] text-muted">{meta.label}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

export function EmptyState({ icon, title, description, action }: {
  icon: React.ComponentProps<typeof MaterialIcons>["name"];
  title: string;
  description: string;
  action?: ReactNode;
}) {
  const colors = useColors();
  return (
    <View className="items-center rounded-3xl border border-dashed border-border bg-surface px-7 py-9">
      <View style={[styles.emptyIcon, { backgroundColor: colors.accentSoft }]}><MaterialIcons name={icon} size={28} color={colors.primary} /></View>
      <Text className="mt-3 text-base font-bold text-foreground text-center">{title}</Text>
      <Text className="mt-1 text-sm text-muted leading-5 text-center">{description}</Text>
      {action ? <View className="mt-5">{action}</View> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  button: {
    minHeight: 48,
    paddingHorizontal: 18,
    borderRadius: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  secondaryButton: { borderWidth: 1 },
  disabled: { opacity: 0.45 },
  buttonText: { color: "#FFFFFF", fontSize: 15, lineHeight: 20, fontWeight: "700" },
  rowTouch: { width: "100%" },
  transactionIcon: { height: 40, width: 40, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  transactionAmount: { fontSize: 13, lineHeight: 18, fontWeight: "700", textAlign: "right" },
  emptyIcon: { height: 52, width: 52, borderRadius: 26, alignItems: "center", justifyContent: "center" },
});
