import * as Notifications from "expo-notifications";
import { useRouter } from "expo-router";
import { useEffect } from "react";
import { Platform } from "react-native";

/** Keeps notification taps local and routes them to the dashboard without loading remote data. */
export function LocalNotificationNavigation() {
  const router = useRouter();
  useEffect(() => {
    if (Platform.OS === "web") return;
    const handleResponse = (response: Notifications.NotificationResponse) => {
      const route = response.notification.request.content.data?.route;
      if (route === "/(tabs)") router.replace("/(tabs)" as never);
    };
    const subscription = Notifications.addNotificationResponseReceivedListener(handleResponse);
    void Notifications.getLastNotificationResponseAsync().then((response) => { if (response) handleResponse(response); });
    return () => subscription.remove();
  }, [router]);
  return null;
}
