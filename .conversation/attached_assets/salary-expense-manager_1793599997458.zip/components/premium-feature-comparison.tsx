import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { Text, View } from "react-native";
import { premiumComparisonRows, type PremiumComparisonAvailability } from "@/lib/premium/access";

function AccessMark({ value }: { value: PremiumComparisonAvailability }) {
  if (value === "included") return <View className="items-center" accessibilityLabel="Included"><View className="h-6 w-6 items-center justify-center rounded-full bg-success/15"><MaterialIcons name="check" size={16} color="#198B73" /></View></View>;
  if (value === "preview") return <View className="items-center" accessibilityLabel="Preview available"><View className="h-6 min-w-6 items-center justify-center rounded-full bg-primary/15 px-1"><MaterialIcons name="visibility" size={14} color="#956000" /></View></View>;
  if (value === "ad_supported") return <View className="items-center" accessibilityLabel="Ad-supported"><Text className="text-[10px] font-bold text-muted">Ads</Text></View>;
  return <View className="items-center" accessibilityLabel="Premium only"><MaterialIcons name="lock-outline" size={17} color="#8A8578" /></View>;
}

export function PremiumFeatureComparison({ compact = false }: { compact?: boolean }) {
  const rows = compact ? premiumComparisonRows().slice(2) : premiumComparisonRows();
  return <View accessibilityLabel="Free and Premium feature comparison" className="overflow-hidden rounded-2xl border border-border bg-background"><View className="flex-row items-center border-b border-border bg-surface px-3 py-2.5"><Text className="flex-1 text-[10px] font-bold tracking-wider text-muted">FEATURE</Text><Text className="w-12 text-center text-[10px] font-bold tracking-wider text-muted">FREE</Text><View className="w-[68px] items-center"><View className="rounded-full bg-primary px-2 py-1"><Text className="text-[9px] font-bold tracking-wide text-white">PREMIUM</Text></View></View></View>{rows.map((row) => <View key={row.label} accessibilityLabel={`${row.label}: Free ${row.free}, Premium ${row.premium}`} className="flex-row items-center border-b border-border px-3 py-3 last:border-b-0"><Text className="flex-1 text-xs font-semibold text-foreground">{row.label}</Text><View className="w-12"><AccessMark value={row.free} /></View><View className="w-[68px]"><AccessMark value={row.premium} /></View></View>)}<View className="border-t border-primary/15 bg-primary/5 px-3 py-2"><Text className="text-center text-[10px] leading-4 text-muted">Premium includes every Free feature, plus an ad-free experience and the locked tools above.</Text></View></View>;
}
