import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import { useRouter } from "expo-router";
import { PremiumFeatureComparison } from "@/components/premium-feature-comparison";
import { PremiumUnlockSheet } from "@/components/premium-unlock-sheet";
import { ScreenContainer } from "@/components/screen-container";
import { premiumFeatureLabel, type PremiumFeature } from "@/lib/premium/access";

export function PremiumFeatureLocked({ feature, onClose }: { feature: PremiumFeature; onClose?: () => void }) {
  const router = useRouter();
  const [unlockOpen, setUnlockOpen] = useState(false);
  const label = premiumFeatureLabel(feature);
  const close = onClose ?? (() => router.replace("/premium" as never));
  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5"><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1, justifyContent: "center", paddingVertical: 24 }}><View className="rounded-3xl border border-primary/20 bg-surface p-5"><View className="h-12 w-12 items-center justify-center rounded-2xl bg-primary/15"><MaterialIcons name="lock-outline" size={24} color="#956000" /></View><Text className="mt-5 text-2xl font-bold tracking-tight text-foreground">{label} is Premium</Text><Text className="mt-2 text-sm leading-6 text-muted">This feature is reserved for Premium. Checkout is not connected in this local build, so no payment, account, or financial information is requested.</Text><Text className="mb-2 mt-5 text-[11px] font-bold tracking-wider text-muted">COMPARE PLANS</Text><PremiumFeatureComparison /><TouchableOpacity accessibilityRole="button" accessibilityLabel={`View Premium options for ${label}`} activeOpacity={0.78} onPress={() => setUnlockOpen(true)} className="mt-5 items-center rounded-2xl bg-primary py-3.5"><Text className="text-sm font-bold text-white">View Premium options</Text></TouchableOpacity><TouchableOpacity accessibilityRole="button" accessibilityLabel="Return to Premium preview" activeOpacity={0.72} onPress={close} className="mt-3 items-center py-2"><Text className="text-sm font-semibold text-muted">Back to Premium preview</Text></TouchableOpacity></View></ScrollView><PremiumUnlockSheet visible={unlockOpen} feature={feature} onClose={() => setUnlockOpen(false)} /></ScreenContainer>;
}
