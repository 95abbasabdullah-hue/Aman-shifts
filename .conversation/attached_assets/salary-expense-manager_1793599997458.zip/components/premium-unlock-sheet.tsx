import { useEffect, useState } from "react";
import { ActivityIndicator, Linking, Modal, ScrollView, Text, TouchableOpacity, View } from "react-native";
import { premiumFeatureLabel, type PremiumFeature } from "@/lib/premium/access";
import { REVENUECAT_ANNUAL_PACKAGE_ID } from "@/lib/premium/revenuecat";
import { PremiumFeatureComparison } from "@/components/premium-feature-comparison";
import { usePremiumAccess } from "@/lib/premium/premium-access-provider";

export function PremiumUnlockSheet({ visible, feature, onClose }: { visible: boolean; feature: PremiumFeature | null; onClose: () => void }) {
  const featureLabel = feature ? premiumFeatureLabel(feature) : "Premium";
  const { isReady, isPremium, isSupported, offers, isPurchasing, isRefreshing, error, message, purchase, restore, refresh } = usePremiumAccess();
  const [linkError, setLinkError] = useState<string | null>(null);
  const busy = isPurchasing || isRefreshing || !isReady;

  useEffect(() => {
    if (visible) {
      setLinkError(null);
      void refresh();
    }
  }, [visible, refresh]);

  const manageSubscription = async () => {
    setLinkError(null);
    try {
      await Linking.openURL("https://play.google.com/store/account/subscriptions");
    } catch {
      setLinkError("Open Google Play, then Payments & subscriptions → Subscriptions.");
    }
  };

  return (
    <Modal animationType="fade" transparent visible={visible} onRequestClose={onClose}>
      <View className="flex-1 justify-end bg-black/45 px-5 pb-6 pt-12">
        <ScrollView style={{ maxHeight: "100%" }} contentContainerStyle={{ padding: 20 }} className="rounded-3xl border border-border bg-background">
          <View className="h-10 w-10 items-center justify-center rounded-2xl bg-primary/15"><Text className="text-lg">✦</Text></View>
          <Text className="mt-4 text-xl font-bold text-foreground">{isPremium ? "Premium active" : `Unlock ${featureLabel}`}</Text>
          <Text className="mt-2 text-sm leading-6 text-muted">{isSupported ? "Secure checkout with Google Play. Prices are shown in your store currency." : "Subscriptions and purchase restoration are available in the Android app installed from Google Play. They are unavailable in Expo Go, web, and iOS previews."}</Text>
          <View className="mt-4 rounded-2xl bg-surface p-3"><Text accessibilityLiveRegion="polite" className="text-xs leading-5 text-muted">{isPremium ? "Your Premium features are unlocked." : busy ? "Connecting to Google Play…" : offers.length ? "Choose a plan to continue." : "Subscription plans are currently unavailable."}</Text></View>
          <View className="mt-4"><PremiumFeatureComparison compact /></View>
          {error || linkError ? <Text accessibilityRole="alert" className="mt-4 text-xs leading-5 text-error">{linkError ?? error}</Text> : null}
          {message ? <Text accessibilityLiveRegion="polite" className="mt-4 text-sm leading-5 text-foreground">{message}</Text> : null}
          {busy ? <ActivityIndicator accessibilityLabel="Loading subscription information" className="mt-4" color="#956000" /> : null}
          {!isPremium && isSupported ? offers.map((offer) => {
            const annual = offer.identifier === REVENUECAT_ANNUAL_PACKAGE_ID;
            return <TouchableOpacity key={offer.identifier} accessibilityRole="button" accessibilityLabel={`Subscribe ${annual ? "annually" : "monthly"} to Premium for ${offer.priceString}`} accessibilityState={{ disabled: busy }} activeOpacity={0.78} disabled={busy} onPress={() => void purchase(offer.identifier)} className="mt-3 items-center rounded-2xl bg-primary px-3 py-3.5" style={{ opacity: busy ? 0.5 : 1 }}><Text className="text-sm font-bold text-white">{annual ? "Annual" : "Monthly"} · {offer.priceString}/{annual ? "year" : "month"}</Text></TouchableOpacity>;
          }) : null}
          {!isPremium && offers.length > 0 ? <Text className="mt-3 text-xs leading-5 text-muted">Payment is charged to your Google Play account. Subscriptions renew automatically unless cancelled in Google Play. You can manage or cancel your subscription there.</Text> : null}
          {isSupported ? <>
            <TouchableOpacity accessibilityRole="button" accessibilityLabel="Restore Premium purchases" disabled={busy} onPress={() => void restore()} className="mt-3 items-center rounded-2xl border border-border py-3.5"><Text className="text-sm font-bold text-primary">Restore purchases</Text></TouchableOpacity>
            {isPremium ? <TouchableOpacity accessibilityRole="button" onPress={() => void manageSubscription()} className="mt-3 items-center py-2"><Text className="text-sm font-bold text-primary">Manage subscription</Text></TouchableOpacity> : null}
            <TouchableOpacity accessibilityRole="button" disabled={busy} onPress={() => void refresh()} className="mt-3 items-center py-2"><Text className="text-sm font-semibold text-primary">Refresh subscription & prices</Text></TouchableOpacity>
          </> : null}
          <TouchableOpacity accessibilityRole="button" accessibilityLabel="Close Premium options" activeOpacity={0.72} onPress={onClose} className="mt-3 items-center py-2"><Text className="text-sm font-semibold text-muted">{isPremium ? "Done" : "Not now"}</Text></TouchableOpacity>
        </ScrollView>
      </View>
    </Modal>
  );
}
