import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { FlatList, Text, TouchableOpacity, View } from "react-native";
import { formatMoney } from "@/lib/finance/format";
import { quickExpenseAppearance } from "@/lib/finance/quick-expense-appearance";
import type { QuickExpenseTemplate } from "@/lib/finance/types";

const LOCKED_TEMPLATE_PREVIEW = [
  { id: "preview-coffee", name: "Coffee", icon: "local-cafe" as const, color: "#B45309" },
  { id: "preview-fuel", name: "Fuel", icon: "local-gas-station" as const, color: "#2563B8" },
  { id: "preview-lunch", name: "Lunch", icon: "restaurant" as const, color: "#198B73" },
];

export function QuickExpenseSection({
  templates,
  currency,
  isPremium,
  onManage,
  onUseTemplate,
  onExplorePremium,
}: {
  templates: QuickExpenseTemplate[];
  currency: string;
  isPremium: boolean;
  onManage: () => void;
  onUseTemplate: (templateId: string) => void;
  onExplorePremium: () => void;
}) {
  if (!isPremium) {
    return <TouchableOpacity accessibilityRole="button" accessibilityLabel="Explore Premium quick expense templates" activeOpacity={0.78} onPress={onExplorePremium} className="overflow-hidden rounded-3xl border border-primary/30 bg-primary/5">
      <View className="flex-row items-center justify-between px-4 pb-2 pt-4"><View className="flex-row items-center"><View className="mr-2 h-8 w-8 items-center justify-center rounded-xl bg-primary/15"><MaterialIcons name="workspace-premium" size={17} color="#956000" /></View><View><Text className="text-sm font-bold text-foreground">Quick expenses</Text><Text className="mt-0.5 text-[11px] text-muted">Premium shortcut templates</Text></View></View><View className="flex-row items-center rounded-full bg-primary px-2.5 py-1"><MaterialIcons name="lock-outline" size={13} color="#FFFFFF" /><Text className="ml-1 text-[10px] font-bold text-white">PREMIUM</Text></View></View><FlatList horizontal pointerEvents="none" data={LOCKED_TEMPLATE_PREVIEW} keyExtractor={(item) => item.id} showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10, paddingHorizontal: 16, paddingVertical: 10 }} renderItem={({ item }) => <View className="w-[94px] overflow-hidden rounded-2xl border border-border bg-surface px-3 py-3 opacity-75"><View style={{ backgroundColor: `${item.color}1F` }} className="relative mb-2 h-8 w-8 items-center justify-center rounded-xl"><MaterialIcons name={item.icon} size={17} color={item.color} /><View className="absolute -right-2 -top-2 h-5 w-5 items-center justify-center rounded-full border border-surface bg-foreground"><MaterialIcons name="lock" size={11} color="#FFFFFF" /></View></View><Text numberOfLines={1} className="text-xs font-bold text-foreground">{item.name}</Text><Text className="mt-1 text-[10px] font-semibold text-muted">One-tap setup</Text></View>} /><View className="flex-row items-center justify-between border-t border-primary/15 bg-primary/10 px-4 py-3"><Text className="flex-1 pr-3 text-xs font-semibold leading-5 text-foreground">Save common purchases and review them before adding to your ledger.</Text><View className="flex-row items-center"><Text className="text-xs font-bold text-primary">Explore</Text><MaterialIcons name="chevron-right" size={18} color="#956000" /></View></View></TouchableOpacity>;
  }

  if (!templates.length) {
    return <TouchableOpacity accessibilityRole="button" accessibilityLabel="Create a quick expense template" activeOpacity={0.72} onPress={onManage} className="flex-row items-center rounded-2xl border border-dashed border-primary/35 bg-primary/5 px-4 py-3"><View className="mr-3 h-9 w-9 items-center justify-center rounded-xl bg-primary/12"><MaterialIcons name="bolt" size={18} color="#956000" /></View><View className="flex-1"><Text className="text-sm font-bold text-foreground">Add quick expenses</Text><Text className="mt-0.5 text-xs text-muted">Save coffee, fuel, or any common expense.</Text></View><MaterialIcons name="chevron-right" size={20} color="#956000" /></TouchableOpacity>;
  }

  return <View><View className="mb-2 flex-row items-center justify-between"><Text className="ml-1 text-xs font-bold tracking-wider text-muted">QUICK EXPENSE</Text><TouchableOpacity accessibilityRole="button" accessibilityLabel="Manage quick expense templates" activeOpacity={0.7} onPress={onManage}><Text className="text-xs font-bold text-primary">Manage</Text></TouchableOpacity></View><FlatList horizontal data={templates.slice(0, 6)} keyExtractor={(template) => template.id} showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10, paddingHorizontal: 1 }} renderItem={({ item }) => { const appearance = quickExpenseAppearance(item); return <TouchableOpacity accessibilityRole="button" accessibilityLabel={`Use ${item.name} quick expense template`} activeOpacity={0.72} onPress={() => onUseTemplate(item.id)} className="w-32 rounded-2xl border border-border bg-surface px-3 py-3"><View style={{ backgroundColor: `${appearance.color}1F` }} className="mb-2 h-8 w-8 items-center justify-center rounded-xl"><MaterialIcons name={appearance.icon} size={17} color={appearance.color} /></View><Text numberOfLines={1} className="text-sm font-bold text-foreground">{item.name}</Text><Text numberOfLines={1} style={{ color: appearance.color }} className="mt-1 text-xs font-semibold">{formatMoney(item.amountMinor, currency)}</Text></TouchableOpacity>; }} /></View>;
}
