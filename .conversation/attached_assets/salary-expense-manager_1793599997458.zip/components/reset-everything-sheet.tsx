import { Modal, Text, TouchableOpacity, View } from "react-native";

export type ResetConfirmationStep = "review" | "final";

export function ResetEverythingSheet({
  step,
  resetting,
  error,
  onCancel,
  onContinue,
  onReset,
}: {
  step: ResetConfirmationStep | null;
  resetting: boolean;
  error?: string;
  onCancel: () => void;
  onContinue: () => void;
  onReset: () => void;
}) {
  const finalStep = step === "final";
  return (
    <Modal visible={step !== null} transparent animationType="fade" onRequestClose={() => { if (!resetting) onCancel(); }}>
      <View className="flex-1 justify-end bg-black/45 px-4 pb-6">
        <View className="rounded-[28px] border border-border bg-background p-5">
          <Text className="text-xl font-bold text-foreground">{finalStep ? "Reset everything permanently?" : "Reset all financial data?"}</Text>
          <Text className="mt-2 text-sm leading-5 text-muted">
            {finalStep
              ? "All local financial records and scheduled finance reminders will be removed from this device. This cannot be undone."
              : "This removes local salary settings, accounts, transactions, bills, recurring expenses, budgets, savings goals, and currency settings."}
          </Text>
          {error ? <Text className="mt-3 text-sm font-medium text-error">{error}</Text> : null}
          <View className="mt-5 flex-row gap-3">
            <TouchableOpacity accessibilityRole="button" disabled={resetting} onPress={onCancel} className="flex-1 items-center rounded-2xl border border-border bg-surface py-3">
              <Text className="text-sm font-bold text-muted">Cancel</Text>
            </TouchableOpacity>
            {finalStep ? (
              <TouchableOpacity accessibilityRole="button" accessibilityLabel="Reset everything permanently" disabled={resetting} onPress={onReset} className="flex-1 items-center rounded-2xl bg-error py-3">
                <Text className="text-sm font-bold text-white">{resetting ? "Resetting…" : "Reset Everything"}</Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity accessibilityRole="button" accessibilityLabel="Continue to final reset confirmation" onPress={onContinue} className="flex-1 items-center rounded-2xl bg-error py-3">
                <Text className="text-sm font-bold text-white">Continue</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
}
