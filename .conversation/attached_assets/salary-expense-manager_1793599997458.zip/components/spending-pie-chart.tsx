import { Text, View } from "react-native";
import Svg, { Circle, Path, Text as SvgText } from "react-native-svg";
import { formatMoney } from "@/lib/finance/format";
import { pieSliceAngles, spendingPieSlices, spendingPieTotal, type SpendingPieSlice } from "@/lib/finance/statistics-pie";

const SLICE_COLORS = ["#4B82B4", "#F1096E", "#91BD32", "#FFC600", "#F28C13", "#6FA0A1", "#8A73BE", "#D76458"];
const CENTER = 80;
const RADIUS = 72;

function pointAt(angle: number, radius: number) {
  const radians = (angle * Math.PI) / 180;
  return { x: CENTER + radius * Math.cos(radians), y: CENTER + radius * Math.sin(radians) };
}

function slicePath(slice: SpendingPieSlice) {
  if (slice.chartPercentage >= 99.999) return null;
  const { start, end } = pieSliceAngles(slice);
  const from = pointAt(start, RADIUS);
  const to = pointAt(end, RADIUS);
  return `M ${CENTER} ${CENTER} L ${from.x} ${from.y} A ${RADIUS} ${RADIUS} 0 ${slice.chartPercentage > 50 ? 1 : 0} 1 ${to.x} ${to.y} Z`;
}

export function SpendingPieChart({ spending, currency, salaryMinor }: { spending: Record<string, number>; currency: string; salaryMinor: number }) {
  const slices = spendingPieSlices(spending, salaryMinor);
  const totalMinor = spendingPieTotal(spending);
  if (!salaryMinor || !slices.length) return <View className="items-center rounded-3xl border border-border bg-surface px-5 py-9"><Text className="text-base font-bold text-foreground">No salary allocation to chart</Text><Text className="mt-2 text-center text-sm leading-5 text-muted">Add salary and dated spending in the selected period to see each item as a share of salary.</Text></View>;

  return <View className="rounded-3xl border border-border bg-surface p-5"><View className="flex-row items-start justify-between gap-3"><View className="flex-1"><Text className="text-base font-bold text-foreground">Salary allocation breakdown</Text><Text className="mt-1 text-sm text-muted">Each item is measured against your salary. Salary income is not a chart item.</Text></View><View className="rounded-lg bg-accentSoft px-2.5 py-1"><Text className="text-[11px] font-bold text-primary">OF SALARY</Text></View></View><View accessible={false} className="mt-4 items-center justify-center"><Svg accessibilityRole="image" accessibilityLabel={`Salary allocation pie chart based on ${formatMoney(salaryMinor, currency)} salary. Items total ${formatMoney(totalMinor, currency)}: ${slices.map((slice) => `${slice.category} ${slice.percentage.toFixed(1)} percent`).join(", ")}`} width={220} height={220} viewBox="0 0 160 160"><Circle cx={CENTER} cy={CENTER} r={RADIUS} fill="#E8E2D4" stroke="#FFFDF6" strokeWidth="1" />{slices.map((slice, index) => slice.chartPercentage >= 99.999 ? <Circle key={slice.category} cx={CENTER} cy={CENTER} r={RADIUS} fill={SLICE_COLORS[index % SLICE_COLORS.length]} stroke="#FFFDF6" strokeWidth="1" /> : slice.chartPercentage > 0 ? <Path key={slice.category} d={slicePath(slice) ?? ""} fill={SLICE_COLORS[index % SLICE_COLORS.length]} stroke="#FFFDF6" strokeWidth="1" /> : null)}{slices.map((slice) => { if (slice.chartPercentage < 7) return null; const { middle } = pieSliceAngles(slice); const label = pointAt(middle, slice.chartPercentage < 12 ? 49 : 45); return <SvgText key={`${slice.category}-label`} x={label.x} y={label.y + 4} fill="#1E261F" fontSize="10" fontWeight="700" textAnchor="middle">{slice.percentage.toFixed(1)}%</SvgText>; })}<Circle cx={CENTER} cy={CENTER} r="24" fill="#FFFDF6" opacity="0.94" pointerEvents="none" /><SvgText x={CENTER} y="76" fill="#756B56" fontSize="7" fontWeight="700" textAnchor="middle">SALARY</SvgText><SvgText x={CENTER} y="87" fill="#302310" fontSize="9" fontWeight="700" textAnchor="middle">{formatMoney(salaryMinor, currency)}</SvgText></Svg></View><View className="mt-3 gap-2.5">{slices.map((slice, index) => <View key={slice.category} accessible accessibilityLabel={`${slice.category}, ${formatMoney(slice.amountMinor, currency)}, ${slice.percentage.toFixed(1)} percent of salary`} className="flex-row items-center gap-2.5 rounded-xl px-1 py-1"><View style={{ backgroundColor: SLICE_COLORS[index % SLICE_COLORS.length] }} className="h-3 w-3 rounded-sm" /><Text className="flex-1 text-sm font-semibold text-foreground">{slice.category}</Text><Text className="text-sm text-muted">{formatMoney(slice.amountMinor, currency)}</Text><Text className="w-12 text-right text-sm font-bold text-foreground">{slice.percentage.toFixed(1)}%</Text></View>)}</View></View>;
}
