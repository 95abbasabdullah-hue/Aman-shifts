import { useEffect } from "react";
import { useFinance } from "@/lib/finance/provider";
import { permittedColorScheme } from "@/lib/premium/access";
import { useThemeContext } from "@/lib/theme-provider";

export function ThemePreferenceSync() {
  const { isReady, snapshot } = useFinance();
  const { setColorScheme } = useThemeContext();

  useEffect(() => {
    if (!isReady) return;
    setColorScheme(permittedColorScheme(snapshot.settings.themePreference));
  }, [isReady, setColorScheme, snapshot.settings.themePreference]);

  return null;
}
