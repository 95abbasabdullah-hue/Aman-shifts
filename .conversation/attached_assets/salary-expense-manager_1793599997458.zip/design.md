# Salary & Expense Manager — Mobile Interface Plan

## Product Intent

Salary & Expense Manager is an offline-first personal-finance companion designed around one primary question: **how much money is available to spend in the current salary cycle?** The app is optimized for portrait mobile use and short, one-handed actions. Financial information is kept on the device, with no account, network dependency, or cloud workflow in Phase 1.

## Screen List

| Screen | Primary content and functionality | Layout and interaction notes |
|---|---|---|
| Welcome setup | Monthly salary, currency, salary payment day, and a skip action | A focused three-step setup with a top progress indicator, numeric keypad-friendly salary field, and a clear “Set up later” text action. |
| Home dashboard | Salary, fixed bills, variable expenses, available balance, salary-cycle date range, and recent activity | A large available-balance hero occupies the upper third of the screen. Summary values use a readable two-column card, followed by an activity list and one elevated “Add expense” action. |
| Add / edit transaction | Transaction type, amount, currency, category, date, description, and optional note | A bottom-sheet-style form or modal with the amount field first, segmented type picker, category grid, and a persistent save button within thumb reach. |
| Transaction history | Filterable chronological list of income, fixed expenses, and variable expenses | Each row uses a semantic icon, description, date, category label, and signed amount. Long-press or overflow actions expose edit and delete with confirmation. |
| Fixed bills | Active and inactive recurring bills, monthly/yearly frequency, upcoming due dates | A concise list with bill amount on the right and an active status cue. A floating add action opens the bill form. |
| Add / edit bill | Name, amount, currency, due date, frequency, category, note, and active state | A grouped form using selectable rows for date and frequency; the form presents validation beneath the relevant field. |
| Salary & income | Salary amount, currency, payment day, automatic salary toggle, and salary transactions | A configuration card explains the active cycle in plain language and makes manual salary adjustments easy. |
| More | Appearance, currency, setup status, local data information, and reset actions | A native settings-style grouped list. Destructive data actions are separated and always require confirmation. |

## Primary User Flows

| User goal | Flow |
|---|---|
| Complete initial setup | Open app → Enter salary → Select currency → Select payment day → Confirm → View current dashboard. |
| Record an expense | Tap “Add expense” on Home or the add action in Transactions → Enter amount → Choose category and date → Add optional description → Save → Dashboard balance and history update immediately. |
| Add a recurring bill | Open Bills → Tap add → Fill name, amount, due date, and frequency → Keep active → Save → The bill is applied once in the matching salary cycle. |
| Adjust salary settings | Open More → Tap Salary & income → Edit amount, currency, payment day, or automatic addition → Save → The salary cycle and dashboard refresh. |
| Correct or remove an entry | Open Transactions → Tap a transaction → Edit and save, or select delete → Confirm permanent deletion → Balances recalculate. |
| Skip and return to setup | Tap “Set up later” during onboarding → View empty dashboard guidance → Open More → Tap Salary & income → Complete configuration. |

## Color Choices

The visual language uses a composed financial palette rather than generic banking blue. **Deep Harbor** `#123A4A` establishes trust and anchors primary actions. **Mint Ledger** `#198B73` communicates positive available balance and income. **Coral Alert** `#D45B5B` identifies expenses and destructive actions. **Sand Surface** `#F6F4EF` gives light-mode cards warmth, while **Ink** `#172027` keeps text crisp. Dark mode shifts surfaces to **Night Ledger** `#111A20`, with softer borders and retained mint/coral contrast for clear scanning.

## Interaction and Accessibility Principles

The tab bar remains limited to Home, Transactions, Bills, and More, placing each destination within easy thumb reach. Numeric financial values use tabular, high-contrast text, and the available balance is never communicated by color alone. The application provides explicit inline validation, compact success feedback after saving, and confirmation before any irreversible deletion. Light and dark appearances use the same information hierarchy, with clear labels and at least 44-point touch targets for interactive elements.

## Local-First Data Approach

Phase 1 uses local on-device persistence in the initialized mobile project. Finance records, configuration, and processed recurring-cycle markers reside locally, so the main accounting workflow continues without connectivity. The domain layer is isolated from screens to permit later migration or additional synchronization features without rewriting the user interface.

## Phase 2 Extension Plan

Phase 2 extends, rather than replaces, the existing local ledger. Existing salary, bill, and expense records remain valid, while the local snapshot receives optional savings goals, category budgets, and spending-alert preferences. The migration normalizes absent Phase 2 fields to safe empty collections and default thresholds; it does not alter Phase 1 transactions or remove any stored value.

| Extension | Data and accounting behavior | Mobile placement |
|---|---|---|
| Savings goals | Each goal has a target, current balance, optional monthly target, and optional per-cycle automatic allocation. Deposits and withdrawals are recorded as dedicated transfer-like transaction types; deposits reduce spending availability while withdrawals restore it. | A dedicated Savings tab presents goal cards, progress, and a compact add action. |
| Category budgets | Limits are scoped to the current salary cycle, compare variable spending against a selected category, and use customizable warning/exceeded percentages. | The More area links to a Budget screen with category rows and remaining amounts. |
| Safe daily spending | Available spending after fixed bills, variable spending, and savings deposits is divided by the inclusive days left before the next salary-cycle start. A zero-day divisor is never used. | The Home dashboard adds one compact daily-safe-spend card beneath the balance hero. |
| Financial summary | The current cycle aggregates income, fixed expenses, variable expenses, savings deposits, available spending, average daily spending, and the highest variable-spend category. | The More area links to a Financial Summary screen, keeping the primary dashboard uncluttered. |

The Phase 2 tab bar adds **Savings** as the fifth primary destination. Budgets and financial summaries remain secondary screens, preserving one-handed access to the current balance while avoiding overcrowding the dashboard.

## Phase 3 Extension Plan

Phase 3 continues the existing local snapshot migration strategy. Existing Phase 1 and Phase 2 records retain their identifiers and values. The migration supplies a local Cash account for legacy entries, then annotates existing ledger rows with that account identifier. New accounts, recurring rules, manual currency rates, notification preferences, and backup metadata are additive fields in the same on-device data store.

| Extension | Accounting rule | Mobile placement |
|---|---|---|
| Accounts and transfers | Accounts hold an opening balance plus account-aware ledger movements. A transfer creates paired out/in records linked by one transfer ID and is excluded from income, expense, budget, and net-spending totals. | Accounts is a new primary tab. A transfer action sits in the account overview. |
| Recurring expenses | A local rule produces one variable-expense transaction per matching weekly, monthly, yearly, or custom occurrence. Stable recurrence keys prevent double application. | Recurring expenses is a secondary settings screen. |
| Statistics and search | Statistics use local transactions only and offer salary-cycle, prior-cycle, month, year, and category slices. Transaction history provides text, category, account, type, date, amount, and sort controls. | Statistics is a primary tab; search remains in Transactions. |
| Currency | Every supported currency uses a user-maintained offline rate relative to the selected main currency. Ledger totals use the stored base amount at the time of entry, so past reports remain stable after later rate changes. | Currency setup is a secondary settings screen. |
| Backup and privacy | Backups are a versioned local JSON payload shared directly from the device. Restore validates the payload before a user confirms replacement or a safe ID-based merge. No network endpoint, login, or remote storage is introduced. | Backup, restore, notifications, and privacy remain in More. |
