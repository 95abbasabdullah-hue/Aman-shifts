# دمج وتشغيل إعلانات AdMob في Salary Manager

> **تنبيه مختصر:** الإعلانات تضيف جمعاً/معالجةً محتملة لبيانات إعلانية خارجية. راجع سياسة الخصوصية ومتطلبات Google Play وAdMob للبلدان التي تستهدفها قبل الإطلاق.

## السياسة الموصى بها لهذا التطبيق

لأن Salary Manager تطبيق مالي شخصي، ابدأ بإعلان واحد **Banner** صغير لمستخدمي النسخة المجانية فقط. لا تستخدم إعلانات ملء الشاشة عند فتح التطبيق أو عند إدخال مصروف أو قبل/بعد حفظ معاملة، لأنها تقطع تدفقاً حساساً وتضعف الثقة.

| الموضع | القرار | السبب |
| --- | --- | --- |
| أسفل قائمة المعاملات، بعد المحتوى | **مناسب كبداية** | موضع غير حرج وبعيد عن أزرار الحفظ |
| شاشة More، بين أقسام ثانوية | مناسب لاحقاً | أقل إزعاجاً من لوحة التحكم |
| لوحة التحكم/الرصيد المتاح | **لا** | شاشة مالية أساسية يجب أن تبقى مركزة |
| نماذج إضافة/تعديل المعاملة | **لا** | يمنع الضغط أو الخطأ أثناء إدخال الأموال |
| الإحصاءات والتقارير وPremium | **لا** | تحافظ على تجربة تحليل وشراء واضحة |
| مستخدم Premium | **لا إعلانات نهائياً** | قيمة واضحة للاستحقاق المدفوع |
| Interstitial أو Rewarded | لا تبدأ بهما | ليسا مناسبين مبدئياً لتطبيق إدارة مالية |

## المتطلبات التقنية

استخدم [`react-native-google-mobile-ads`](https://docs.page/invertase/react-native-google-mobile-ads) في Expo. تحتاج الوحدة إلى كود أصلي، ولذلك لا تعمل داخل Expo Go؛ استخدم **Development Build** ثم ابنِ APK/AAB جديداً بعد كل تغيير في إعدادها [1](https://docs.page/invertase/react-native-google-mobile-ads). أنشئ تطبيق Android في AdMob للحصول على **AdMob App ID**، وأنشئ بعده Ad Unit مستقل من نوع Banner [2](https://developers.google.com/admob/android/quick-start).

| القيمة | مثال | الاستخدام |
| --- | --- | --- |
| AdMob App ID | `ca-app-pub-xxxxxxxx~yyyyyyyyyy` | إعداد أصلي لمرة واحدة في `app.config.ts` |
| Banner Ad Unit ID | `ca-app-pub-xxxxxxxx/yyyyyyyyyy` | طلب الإعلان في واجهة التطبيق |
| Test Banner ID | `TestIds.BANNER` | التطوير والاختبار فقط |

> لا تخلط **App ID** مع **Ad Unit ID**: وضع App ID مكان Ad Unit ID لن يعرض إعلاناً صحيحاً، وغياب App ID من الإعداد الأصلي قد يؤدي إلى فشل البناء أو تعطل التطبيق [1](https://docs.page/invertase/react-native-google-mobile-ads).

## 1. التثبيت وإعداد التطبيق

عند البدء الفعلي، ثبّت المكتبة ثم أضف Expo config plugin. لا تضع قيمة حقيقية في الكود المصدري العام؛ أضفها عبر إعدادات المشروع الآمنة عند وقت التنفيذ.

```bash
npx expo install react-native-google-mobile-ads
```

```ts
// app.config.ts — مثال هيكلي فقط
plugins: [
  "expo-router",
  [
    "react-native-google-mobile-ads",
    {
      androidAppId: "ca-app-pub-xxxxxxxx~yyyyyyyyyy",
      // أضف iosAppId عند دعم iOS لاحقاً
    },
  ],
];
```

بعد إضافة plugin أو تغيير App ID، أنشئ Development Build/نسخة Android جديدة؛ لا يكفي تحديث JavaScript فقط [1](https://docs.page/invertase/react-native-google-mobile-ads).

## 2. موفر الإعلانات المركزي

لا تضع `mobileAds().initialize()` في كل شاشة. أنشئ موفراً واحداً يتحقق من الموافقة أولاً، ثم يهيئ SDK مرة واحدة. لا تمرر مطلقاً راتب المستخدم أو المصروفات أو اسماء المعاملات إلى AdMob.

```tsx
// lib/ads/ads-provider.tsx — مخطط مبسط
import mobileAds from "react-native-google-mobile-ads";

export function AdsProvider({ children }: PropsWithChildren) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let active = true;
    void (async () => {
      // 1) اطلب موافقة UMP حيث تكون مطلوبة.
      // 2) طبّق إعدادات الطلب قبل التهيئة إذا اقتضى الأمر.
      await mobileAds().initialize();
      if (active) setReady(true);
    })();
    return () => { active = false; };
  }, []);

  return <AdsContext.Provider value={{ ready }}>{children}</AdsContext.Provider>;
}
```

ينبغي الحصول على الموافقة وإعداد أعلام الطلب المناسبة قبل تهيئة SDK/تحميل الإعلانات، لأن SDK قد يحمّل إعلانات مبكراً [1](https://docs.page/invertase/react-native-google-mobile-ads). للمستخدمين في المنطقة الاقتصادية الأوروبية والمملكة المتحدة وسويسرا، تتطلب Google CMP معتمدة لإعلانات مخصصة، وتتوفر مسارات للإعلانات غير المخصصة أو المحدودة حسب الموافقة [3](https://support.google.com/admob/answer/13554116?hl=en).

## 3. مكوّن إعلان واحد يخفي نفسه لـ Premium

استخدم مكوّناً موحداً يسمى `AdBannerSlot`. وظيفته: لا يعرض شيئاً على الويب أو قبل الموافقة/التهيئة أو لمستخدم Premium. بذلك لن تضطر إلى تكرار شروط الاستحقاق في كل شاشة.

```tsx
// components/ad-banner-slot.tsx — مخطط مبسط
import { Platform, View } from "react-native";
import { BannerAd, BannerAdSize, TestIds } from "react-native-google-mobile-ads";
import { usePremiumAccess } from "@/lib/premium/premium-access-provider";
import { useAds } from "@/lib/ads/ads-provider";

const PROD_BANNER_UNIT_ID = "ca-app-pub-xxxxxxxx/yyyyyyyyyy";

export function AdBannerSlot() {
  const { isPremium } = usePremiumAccess();
  const { ready, mayRequestAds } = useAds();

  if (Platform.OS === "web" || isPremium || !ready || !mayRequestAds) return null;

  const unitId = __DEV__ ? TestIds.BANNER : PROD_BANNER_UNIT_ID;
  return (
    <View accessibilityLabel="Advertisement" className="items-center py-3">
      <BannerAd unitId={unitId} size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER} />
    </View>
  );
}
```

ثم أضف المكوّن **مرة واحدة فقط** في `ListFooterComponent` لشاشة Transactions أو في موضع ثانوي في More. يجب ألا يكون الإعلان قريباً من زر حذف أو حفظ أو فتح Premium.

```tsx
// مثال: app/(tabs)/transactions.tsx
<FlatList
  data={transactions}
  renderItem={renderTransaction}
  ListFooterComponent={<AdBannerSlot />}
/>
```

## 4. التمييز بين Free وPremium

سيكون الاستثناء بسيطاً لأن المشروع يملك `usePremiumAccess()` بالفعل:

| حالة الصلاحية | سلوك `AdBannerSlot` |
| --- | --- |
| Free | يعرض Banner بعد الموافقة والتهيئة |
| Premium Test Mode في Development | يخفي الإعلان |
| Premium متحقق من Google Play في Production | يخفي الإعلان |
| Web Preview أو Expo Go | لا يحاول تحميل إعلان أصلي |
| لا موافقة/لا اتصال/خطأ SDK | لا يعرض شيئاً دون تعطيل بقية التطبيق |

لا تجعل مشاهدة إعلان طريقة لفتح ميزة Premium دائمة. إن أردت إعلانات مكافأة لاحقاً، اجعل المكافأة غير مالية ومؤقتة—مثل فتح تقرير معاينة لمرة واحدة—مع موافقة صريحة من المستخدم، لكن لا تبدأ بهذه الآلية.

## 5. الاختبار الآمن

أثناء التطوير استخدم `TestIds.BANNER`، وليس Ad Unit ID الحقيقي. تنص Google على أن النقر على إعلانات إنتاجية أثناء التطوير قد يؤدي إلى تصنيف نشاط غير صالح، بينما معرفات الاختبار آمنة للاختبار [4](https://developers.google.com/admob/android/test-ads). لا تنشر أبداً معرفات الاختبار في النسخة النهائية.

اختبر الحالات التالية:

| الاختبار | النتيجة المطلوبة |
| --- | --- |
| مستخدم Free + موافقة صالحة | يظهر Banner في الموضع المحدد فقط |
| مستخدم Premium | لا يظهر أي إعلان في أي شاشة |
| Premium Test Mode | لا يظهر الإعلان في Development Build |
| رفض الموافقة أو عدم توفرها | لا يتعطل التطبيق ولا يظهر إعلان قبل السياسة المناسبة |
| إضافة/تعديل/حذف معاملة | لا يظهر إعلان فوق أزرار التأكيد ولا تتغير الحسابات |
| Web Preview وExpo Go | لا يحدث crash ولا تظهر محاولة تحميل وحدة إعلانية أصلية |
| Development Build | يظهر إعلان يحمل تسمية Test Ad عند استخدام معرف الاختبار |

قبل النشر، أعلن في Google Play Console أن التطبيق يحتوي إعلانات، وحدّث سياسة الخصوصية ونموذج Data safety بما يتوافق مع إعداد AdMob والموافقة. مكتبة React Native توثّق أيضاً ضرورة الإقرار بوجود الإعلانات في Play Console قبل الإصدار [1](https://docs.page/invertase/react-native-google-mobile-ads).

## خطة تنفيذ من خمس مراحل

1. أنشئ حساب AdMob والتطبيق وBanner Ad Unit، وحدد البلدان وسياسة الموافقة.
2. أضف مكتبة الإعلانات وconfig plugin وAdMob App ID، ثم أنشئ Development Build.
3. نفّذ `AdsProvider` وواجهة موافقة UMP، ثم `AdBannerSlot` مع TestIds.
4. ضع الإعلان في قائمة Transactions فقط واربطه بـ `usePremiumAccess()` لإخفائه عن Premium.
5. اختبر بمعرفات الاختبار، راجع الخصوصية وData safety، ثم استبدل معرف Banner في Production فقط.

## المراجع

1. [React Native Google Mobile Ads — Getting Started](https://docs.page/invertase/react-native-google-mobile-ads)
2. [Google AdMob — Set up Google Mobile Ads SDK for Android](https://developers.google.com/admob/android/quick-start)
3. [Google AdMob Help — Consent management requirements for EEA, UK, and Switzerland](https://support.google.com/admob/answer/13554116?hl=en)
4. [Google AdMob — Enable test ads](https://developers.google.com/admob/android/test-ads)
