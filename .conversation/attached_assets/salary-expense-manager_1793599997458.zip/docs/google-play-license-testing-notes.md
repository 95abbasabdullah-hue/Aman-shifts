> ملاحظة تحديث 2026-11-02: هذه وثيقة تخطيط سابقة. لإعداد الاشتراكات الحالي عبر RevenueCat، راجع [REVENUECAT_SETUP_AR.md](../REVENUECAT_SETUP_AR.md). لا تطبّق اقتراحات شراء مدى الحياة أو التفعيل المحلي القديمة على هذا الربط.

# Google Play License Testing Notes

These implementation notes support a future Google Play Billing integration; they do not indicate that billing is connected in the app today.

- Add license testers in Play Console under **Settings → License testing**, using email lists or Google Groups.
- For test-track validation, publish the app and its purchasable products to an internal, closed, open, or production track; Google recommends internal testing for early validation.
- A licensed tester can use Google Play’s test payment methods without a real charge. The device account that installed/downloaded the app determines the purchase account.
- Test purchases use the ordinary purchase flow. Acknowledge eligible purchases; Google notes that unacknowledged license-tester purchases can be refunded after three minutes.
- Current Android guidance states that new apps and updates must use Google Play Billing Library 8 or later by 31 August 2026, subject to Google’s published extension process.

Sources:

1. [Play Console Help: Test in-app billing with application licensing](https://support.google.com/googleplay/android-developer/answer/6062777?hl=en)
2. [Android Developers: Test your Google Play Billing Library integration](https://developer.android.com/google/play/billing/test)
