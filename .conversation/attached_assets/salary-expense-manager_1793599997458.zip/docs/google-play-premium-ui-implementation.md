> ملاحظة تحديث 2026-11-02: هذه وثيقة تخطيط سابقة. لإعداد الاشتراكات الحالي عبر RevenueCat، راجع [REVENUECAT_SETUP_AR.md](../REVENUECAT_SETUP_AR.md). لا تطبّق اقتراحات شراء مدى الحياة أو التفعيل المحلي القديمة على هذا الربط.

# تنفيذ واجهة الدفع وPremium برمجياً داخل Salary Manager

> **تنبيه:** هذا دليل تقني وتجاري، وليس ضماناً للإيرادات أو المشكلات القانونية/الضريبية. راجع متطلبات Google Play وسياسة الخصوصية وشروط الاستخدام قبل الإطلاق.

## الفكرة الصحيحة

واجهة Premium لا يجب أن تمنح الميزات من زر محلي. استخدم ثلاث طبقات منفصلة:

```text
واجهة Premium
  ↓
طبقة شراء أصلية على Android (Google Play Billing)
  ↓
خادم تحقق آمن من رمز الشراء
  ↓
PremiumAccessProvider الموجود
  ↓
إحصاءات · الوضع الداكن · التوقعات · التقارير · القوالب السريعة
```

Google تصف دورة الشراء بالترتيب التالي: عرض المنتج، فتح واجهة الشراء، التحقق، منح المحتوى/الاستحقاق، ثم تأكيد معالجة الشراء [1](https://developer.android.com/google/play/billing/integrate). لذلك **لا تجعل `storeEntitled` دائماً `true`**، ولا تعتمد على `AsyncStorage` لإثبات الشراء في Production.

## 1. اختيار طبقة الشراء الأصلية

في مشروع Expo الحالي، استخدم **Development Build** أو نسخة Android أصلية، وليس Expo Go. تؤكد وثائق Expo أن مكتبات الشراء داخل التطبيق تحتاج كوداً أصلياً مخصصاً، وهو غير قابل للتهيئة داخل Expo Go [2](https://docs.expo.dev/guides/in-app-purchases/).

| الخيار | مناسب عندما | الملاحظة |
| --- | --- | --- |
| `expo-iap` أو `react-native-iap` | تريد Google Play مباشرة وتحكم كامل | يتطلب Development Build وطبقة تحقق خاصة بك |
| RevenueCat | تريد تقليل عبء التحقق وإدارة الاشتراكات لاحقاً | خدمة طرف ثالث مع خادم استحقاقات خاص بها |

لأن التطبيق محلي أولاً ويستهدف Google Play حالياً، ابدأ بـ `expo-iap` أو `react-native-iap` مع منتج شراء مدى الحياة `premium_lifetime`. لا تربط Google Play قبل إنشاء هذا المنتج وتفعيله في Play Console.

## 2. طبقة بيانات الفوترة

أنشئ مجلداً جديداً عند بدء التنفيذ الفعلي:

```text
lib/billing/
  billing-types.ts
  billing-provider.tsx
  google-play-adapter.ts
  billing-errors.ts
components/
  premium-checkout-sheet.tsx
  premium-purchase-status.tsx
```

```ts
// lib/billing/billing-types.ts
export type BillingStatus =
  | "loading"
  | "available"
  | "purchase_pending"
  | "verifying"
  | "active"
  | "unavailable"
  | "error";

export type StoreProduct = {
  id: "premium_lifetime";
  title: string;
  description: string;
  displayPrice: string; // يأتي مباشرة من Google Play، مثل QAR 39.99
};

export type BillingEntitlement = {
  status: BillingStatus;
  isPremium: boolean;
  product?: StoreProduct;
  message?: string;
};
```

لا تضع السعر النهائي كنص ثابت في التطبيق. استعلم عن `ProductDetails` من Google Play واعرض `displayPrice` الذي يعيده المتجر، حتى يظهر السعر والعملة المحليان الصحيحان. Google تنصح بالاستعلام عن تفاصيل المنتج قبل عرضه، وتحذر من الاحتفاظ بتفاصيل قديمة يمكن أن تسبب فشل بدء الشراء [1](https://developer.android.com/google/play/billing/integrate).

## 3. ربط الاستحقاق الحالي

استبدل الدالة المؤقتة التالية في `lib/premium/premium-access-provider.tsx`:

```ts
function useProductionStoreEntitlement() {
  return false;
}
```

بربط حقيقي مع موفر الفوترة:

```tsx
function PremiumAccessProvider({ children }: PropsWithChildren) {
  const billing = useBilling();
  const isDevelopment = __DEV__;

  const isPremium = resolvePremiumEntitlement({
    isDevelopment,
    testModeEnabled: premiumTestModeEnabled,
    storeEntitled: billing.entitlement.isPremium,
  });

  // بقية الموفر الحالية كما هي
}
```

بهذا يبقى **Premium Test Mode** للتطوير فقط، بينما تتحدد النسخ المنشورة من استحقاق Google Play الذي تم التحقق منه. تُستعمل نفس القيمة الموجودة بالفعل لحماية Statistics وDark Mode والتوقعات والتقارير وقوالب الإدخال السريع.

## 4. واجهة الشراء داخل صفحة Premium

استبدل ورقة "checkout not connected" الحالية بمكوّن `PremiumCheckoutSheet`. يجب أن تعرض الواجهة حالة واضحة في كل مرحلة، بدلاً من زر دفع يعمل بلا تغذية راجعة.

| الحالة | ما يظهر للمستخدم | الزر |
| --- | --- | --- |
| `loading` | «جارٍ تحميل خيارات Premium…» | معطل مع مؤشر تحميل |
| `available` | قائمة الفوائد + السعر المحلي من Google Play | «فتح Premium مقابل {displayPrice}» |
| `purchase_pending` | «أكمل الشراء في Google Play» | معطل |
| `verifying` | «جارٍ تأكيد استحقاقك…» | معطل |
| `active` | «Premium مفعل» + زر إدارة/استعادة | لا زر شراء |
| `error` | رسالة مفهومة + «حاول مجدداً» | إعادة المحاولة |

```tsx
// components/premium-checkout-sheet.tsx — مخطط مبسط
export function PremiumCheckoutSheet() {
  const { entitlement, buyPremium, restorePurchases } = useBilling();

  if (entitlement.status === "loading") {
    return <LoadingState label="Loading Premium options…" />;
  }

  if (entitlement.isPremium) {
    return <PremiumActiveCard onRestore={restorePurchases} />;
  }

  return (
    <View>
      <PremiumFeatureComparison />
      <Text>{entitlement.product?.displayPrice ?? "Price unavailable"}</Text>
      <PrimaryButton
        label={`Unlock Premium · ${entitlement.product?.displayPrice ?? ""}`}
        disabled={entitlement.status !== "available"}
        onPress={buyPremium}
      />
      <TouchableOpacity onPress={restorePurchases}>
        <Text>Restore purchases</Text>
      </TouchableOpacity>
    </View>
  );
}
```

لمنتج **Lifetime**، اكتب «دفعة واحدة، لا يتجدد تلقائياً». للاشتراك، اكتب بوضوح «يتجدد تلقائياً» والفترة والسعر والتجربة إن وجدت، وأضف طريقة سهلة لإدارة أو إلغاء الاشتراك. Google توصي بربط صفحة الإعدادات بمركز اشتراكات Google Play أو صفحة إدارة اشتراك محددة [3](https://developer.android.com/google/play/billing/subscriptions).

## 5. شراء واستعادة: لا تضع المنطق داخل الزر

زر الشراء يستدعي دالة في الموفر فقط. لا تمنح Premium عند عودة `requestPurchase` مباشرة؛ انتظر النتيجة المؤكدة والتحقق.

```ts
// lib/billing/billing-provider.tsx — pseudocode
async function buyPremium() {
  setEntitlement({ status: "purchase_pending", isPremium: false });
  const purchase = await requestGooglePlayPurchase("premium_lifetime");

  if (purchase.state === "pending") {
    setEntitlement({ status: "purchase_pending", isPremium: false });
    return;
  }

  setEntitlement({ status: "verifying", isPremium: false });
  const verified = await verifyPurchaseOnServer({
    productId: purchase.productId,
    purchaseToken: purchase.purchaseToken,
    packageName: purchase.packageName,
  });

  if (!verified.premium) throw new Error("Purchase could not be verified");
  await finishOrAcknowledgePurchase(purchase);
  setEntitlement({ status: "active", isPremium: true });
}

async function restorePurchases() {
  setEntitlement({ status: "verifying", isPremium: false });
  const purchases = await queryActiveGooglePlayPurchases();
  const verified = await verifyEligiblePurchasesOnServer(purchases);
  setEntitlement({ status: verified.premium ? "active" : "available", isPremium: verified.premium });
}
```

تعرض Google النتيجة عبر listener للمشتريات، ويجب معالجة النجاح والإلغاء والأخطاء، وعدم منح محتوى في حالة الشراء المعلّق [1](https://developer.android.com/google/play/billing/integrate). لمنتج Lifetime غير القابل للاستهلاك، استخدم `queryPurchasesAsync`/المكافئ في مكتبتك عند بدء التطبيق وعند الضغط على **Restore purchases**.

## 6. خادم التحقق الصغير

لا ترفع البيانات المالية المحلية. الخادم يحتاج فقط إلى رمز الشراء، معرّف المنتج، واسم الحزمة ليستخدم Google Play Developer API للتحقق من حالة الشراء. احتفظ بمفتاح حساب الخدمة في أسرار الخادم وليس داخل APK.

```text
POST /billing/google-play/verify
request:  { productId, purchaseToken, packageName }
response: { premium: boolean, state: "active" | "inactive" | "pending" }
```

الخادم مسؤول عن:

1. التحقق من المنتج `premium_lifetime` واسم الحزمة.
2. سؤال Google Play عن حالة رمز الشراء.
3. إعادة استحقاق محدود وواضح؛ لا يعيد سجلات المستخدم المالية.
4. تسجيل الحد الأدنى من بيانات التدقيق، دون معلومات المصروفات أو الراتب.
5. تأكيد/إقرار الشراء فقط بعد التحقق الناجح.

توصي Google بالتحقق من رمز الشراء في خادم آمن لحماية أفضل من الاحتيال [1](https://developer.android.com/google/play/billing/integrate). إذا أضفت اشتراكاً لاحقاً، استخدم Real-time Developer Notifications لتحديث الاستحقاق عند التجديد أو الإلغاء أو انتهاء الصلاحية.

## 7. الاختبار قبل الإطلاق

1. أنشئ المنتج في Play Console وأضف حسابات الاختبار من **Settings → License testing**.
2. أنشئ Development/Release build حقيقياً باسم الحزمة نفسه؛ لا تختبر الشراء في Expo Go.
3. اختبر شراء ناجحاً، إلغاء، رفض، شراء معلّق، إعادة تشغيل، Restore purchases، واسترداداً.
4. انشر إلى Internal testing واختبر بحساب License Tester وحساب عادي منفصل.
5. اختبر أن Premium Test Mode لا يظهر ولا يمنح وصولاً في Production.

حسابات License Tester تستطيع استخدام وسائل دفع اختبارية، بينما يجب ألا تمنح حالة شراء معلّقة استحقاقاً [4](https://developer.android.com/google/play/billing/test). تحتاج كل نسخة/تحديث جديد بعد 31 أغسطس 2026 إلى Play Billing Library 8 أو أحدث [1](https://developer.android.com/google/play/billing/integrate).

## ترتيب التنفيذ المقترح

| المرحلة | النتيجة | شرط الانتقال |
| --- | --- | --- |
| 1 | اختيار `premium_lifetime` وتفعيل المنتج في Play Console | Product ID نهائي وسعر/بلدان محددة |
| 2 | `BillingProvider` مع تحميل المنتج وواجهة Checkout حقيقية | Development Build يعمل |
| 3 | شراء + تأكيد + Restore purchases | اختبار License Tester ناجح |
| 4 | خادم تحقق صغير + أمان رموز الشراء | تحقق ناجح من رمز شراء حقيقي |
| 5 | Internal test ثم Production | اجتياز حالات الإلغاء والمعلّق والاسترداد |

## المراجع

1. [Android Developers — Integrate the Google Play Billing Library into your app](https://developer.android.com/google/play/billing/integrate)
2. [Expo — Using in-app purchases](https://docs.expo.dev/guides/in-app-purchases/)
3. [Android Developers — About subscriptions](https://developer.android.com/google/play/billing/subscriptions)
4. [Android Developers — Test your Google Play Billing Library integration](https://developer.android.com/google/play/billing/test)
