> ملاحظة تحديث 2026-11-02: هذه وثيقة تخطيط سابقة. لإعداد الاشتراكات الحالي عبر RevenueCat، راجع [REVENUECAT_SETUP_AR.md](../REVENUECAT_SETUP_AR.md). لا تطبّق اقتراحات شراء مدى الحياة أو التفعيل المحلي القديمة على هذا الربط.

# خطة تشغيل Premium وتسعيره في Salary Manager

> **تنبيه مالي قصير:** أنا لست مستشاراً مالياً مرخصاً. هذه توصية تسعير وتشغيل عملية وليست ضماناً للإيرادات؛ القرار النهائي والتكاليف والمخاطر التجارية تقع على عاتقك.

## التوصية المختصرة

ابدأ بمنتج **شراء لمرة واحدة** باسم **Salary Manager Premium — Lifetime** بسعر افتتاحي مقترح قدره **39.99 ر.ق**، ثم اختبر لاحقاً سعراً عادياً بين **49.99 و59.99 ر.ق**. هذا النموذج يتناسب مع التطبيق المحلي أولاً: الميزات الحالية—الإحصاءات، الوضع الداكن، التوقعات، التصدير، وقوالب المصروفات—تعمل على الجهاز ولا تفرض خدمة سحابية متكررة.

لا تبدأ باشتراك شهري إلا عند تقديم قيمة تشغيلية مستمرة مثل مزامنة مشفرة بين الأجهزة، نسخ احتياطي سحابي، أو تنبيهات/تحليلات خادمية. إذا تقرر الاشتراك لاحقاً، استخدم منتج اشتراك واحداً مع خطة شهرية سنوية: **10.99 ر.ق شهرياً** و**79.99 ر.ق سنوياً**، مع عرض السعر المنسق الذي يعيده Google Play بدلاً من كتابة سعر ثابت داخل التطبيق.

| الخيار | أنسب وقت لاستخدامه | المنتجات المقترحة | التسعير المبدئي |
| --- | --- | --- | --- |
| **شراء مدى الحياة — الموصى به الآن** | الميزات كلها محلية ولا توجد كلفة خادم متكررة | `premium_lifetime` من نوع شراء غير قابل للاستهلاك | 39.99 ر.ق عند الإطلاق؛ اختبر 49.99–59.99 ر.ق لاحقاً |
| اشتراك شهري وسنوي | بعد إضافة مزامنة أو خدمة مستمرة ذات تكلفة | `salary_manager_premium`، مع خطتي أساس شهري/سنوي | 10.99 ر.ق شهرياً أو 79.99 ر.ق سنوياً |

## ما الذي سيتم فتحه

استخدم استحقاقاً واحداً باسم `premium` لفتح الميزات التالية، بدلاً من ربط كل ميزة بمعرّف دفع مستقل:

| الاستحقاق | الميزات التي يفتحها |
| --- | --- |
| `premium` | Statistics، Dark Mode، Advanced forecasts، Custom reports & export، Quick expense templates |

التطبيق يحتوي حالياً على مصدر صلاحيات مركزي و**Premium Test Mode** للتطوير. استبدل قيمة الإنتاج الثابتة `storeEntitled: false` بحالة موثوقة تعيدها طبقة فوترة Google Play. احتفظ بوضع الاختبار مشروطاً بـ `__DEV__` فقط، بحيث لا يمنح وصولاً في النسخ المنشورة.

## إعداد Google Play Console

لخيار الشراء مدى الحياة، أنشئ منتجاً واحداً من نوع **In-app product** في Play Console:

| الحقل | القيمة المقترحة |
| --- | --- |
| Product ID | `premium_lifetime` |
| الاسم المعروض | Salary Manager Premium |
| الوصف | Unlock advanced forecasts, reports, statistics, dark mode, and quick expense templates. |
| نوع المنتج | شراء غير قابل للاستهلاك؛ لا يُستهلك بعد الشراء |
| السعر الأساسي | 39.99 ر.ق |
| التوفر | ابدأ ببلدانك المستهدفة فقط، ثم راجع الأداء قبل التوسع |

لخيار الاشتراك، أنشئ اشتراكاً واحداً باسم `salary_manager_premium`، ثم أضف خطتي أساس تلقائيتَي التجديد: شهرية وسنوية. في Google Play، يحدد **Base plan** فترة الفوترة ونوع التجديد والسعر، بينما يمكن أن تضيف **Offers** تجربة أو سعراً تمهيدياً للمستخدمين المؤهلين فقط [1](https://support.google.com/googleplay/android-developer/answer/12154973?hl=en). لا تقدّم تجربة مجانية في البداية إلا إذا كان لديك سبب واضح للاحتفاظ بالمستخدم بعد نهايتها؛ في الاختبار تنتهي تجربة الاشتراك سريعاً وقد لا تمثل سلوك العميل الفعلي [2](https://developer.android.com/google/play/billing/test).

## التنفيذ الفعلي داخل التطبيق

لا تضع سعراً أو زر شراء حقيقياً قبل تفعيل المنتج في Play Console. بعد ذلك نفّذ هذا التسلسل:

1. أضف طبقة فوترة Android متوافقة مع **Google Play Billing Library 8 أو أحدث**؛ تُظهر وثائق Google أن التطبيقات والتحديثات يجب أن تستخدم الإصدار 8+ بعد 31 أغسطس 2026 [3](https://developer.android.com/google/play/billing/integrate).
2. استخدم مكتبة شراء تدعم Expo عبر **Development Build** أو تطبيق أصلي مبني؛ لا يختبر Expo Go عادة وحدات الفوترة الأصلية. لا تستخدم وضع اختبار Premium الداخلي بديلاً عن اختبار المتجر.
3. عند فتح صفحة Premium، اتصل بـ Google Play واستعلم عن `ProductDetails`. اعرض الاسم والسعر المحليين اللذين يعيدهما المتجر، ولا تخزن كائنات تفاصيل المنتج لفترة طويلة لأن التفاصيل القديمة قد تؤدي إلى فشل بدء الشراء [3](https://developer.android.com/google/play/billing/integrate).
4. عند ضغط شراء، شغّل نافذة Google Play عبر `launchBillingFlow`. تعامل مع النجاح والإلغاء والأخطاء، ولا تمنح الاستحقاق عند حالة شراء معلّقة [3](https://developer.android.com/google/play/billing/integrate).
5. تحقّق من رمز الشراء في خادم آمن، ثم امنح `premium` واعترف بالشراء. توصي Google بالتحقق من رمز الشراء على خادم لحماية أفضل من الاحتيال [3](https://developer.android.com/google/play/billing/integrate). الخادم يحتاج فقط بيانات الاستحقاق ورمز الشراء؛ لا يحتاج إلى رفع سجل الراتب أو المصروفات المحلية.
6. في كل تشغيل/عودة للتطبيق، استعلم عن المشتريات الحالية من Google Play واستعد الاستحقاق. أضف زر **Restore purchases** يكرر هذا الاستعلام ويشرح النتيجة بوضوح.
7. للاشتراكات، أضف صفحة لإدارة الاشتراك ورابطاً إلى Google Play Subscriptions Center؛ توصي Google بإتاحة إدارة الاشتراك داخل الإعدادات أو ما يعادلها [4](https://developer.android.com/google/play/billing/subscriptions).

```text
Google Play purchase / subscription state
          ↓
secure verification service (purchase token only)
          ↓
Premium entitlement: active / inactive / pending
          ↓
PremiumAccessProvider
          ↓
Statistics · Dark Mode · Forecasts · Reports · Quick templates
```

## الاختبار قبل الإطلاق

أضف حسابات الاختبار من **Play Console → Settings → License testing**. يمكن لحسابات الاختبار استخدام وسائل دفع تجريبية واختبار تطبيقات غير منشورة مع تطابق اسم الحزمة وحساب Google المختبِر [5](https://support.google.com/googleplay/android-developer/answer/6062777?hl=en). بعدها انشر AAB إلى **Internal testing**، وافتح رابط الانضمام بالحساب المختبِر، وثبّت النسخة من Google Play.

| حالة يجب اختبارها | النتيجة المطلوبة |
| --- | --- |
| شراء ناجح | تتحول جميع الميزات المقفلة إلى Premium فور التحقق والتأكيد |
| إلغاء نافذة الشراء | تبقى الميزات مقفلة ولا يُحفظ استحقاق جديد |
| شراء معلّق أو مرفوض | لا يتم فتح Premium قبل أن تصبح حالة الشراء `PURCHASED` |
| إعادة تشغيل التطبيق | يعود الاستحقاق من `queryPurchasesAsync` أو خادم التحقق |
| Restore purchases | يعيد Premium للحساب المؤهل ويعطي رسالة واضحة إن لم توجد مشتريات |
| استرداد/انتهاء اشتراك | تزال الصلاحية عند تأكيد الحالة من المتجر/الخادم |

تتجدد اشتراكات الشهر في اختبار License Tester تقريباً كل خمس دقائق، وبحد أقصى ست تجديدات؛ استخدم Play Billing Lab لتسريع حالات التجديد وفترة السماح والتعليق واختبار تغيّر السعر [2](https://developer.android.com/google/play/billing/test).

## متطلبات الإطلاق

قبل الإطلاق، أضف سياسة خصوصية، شروط استخدام، ورابطاً واضحاً لإدارة أو إلغاء الاشتراك إن استخدمت اشتراكاً. راجع سياسة الاشتراكات في Google Play لكل بلد مستهدف، ولا تستخدم استحقاقاً محلياً فقط كحقيقة الدفع في نسخة الإنتاج. حافظ على نسخة تطوير منفصلة لاختبار Premium Test Mode، ونسخة Production موقّعة ومرفوعة إلى Play Console لاختبار الشراء الفعلي.

## قرار مطلوب منك قبل البدء بالبرمجة

اختر واحداً فقط كبداية:

1. **شراء مدى الحياة بسعر 39.99 ر.ق** — أوصي به للنسخة الحالية.
2. **اشتراك شهري/سنوي** — مناسب فقط إذا ستلتزم بإضافة قيمة مستمرة وخدمة متكررة.

بعد اختيارك، يمكن تنفيذ طبقة Google Play Billing، واجهة سعر حية من المتجر، شراء، تأكيد، Restore purchases، واختبارات License Tester.

## المراجع

1. [Google Play Console Help — Understanding subscriptions](https://support.google.com/googleplay/android-developer/answer/12154973?hl=en)
2. [Android Developers — Test your Google Play Billing Library integration](https://developer.android.com/google/play/billing/test)
3. [Android Developers — Integrate the Google Play Billing Library into your app](https://developer.android.com/google/play/billing/integrate)
4. [Android Developers — About subscriptions](https://developer.android.com/google/play/billing/subscriptions)
5. [Google Play Console Help — Test in-app billing with application licensing](https://support.google.com/googleplay/android-developer/answer/6062777?hl=en)
