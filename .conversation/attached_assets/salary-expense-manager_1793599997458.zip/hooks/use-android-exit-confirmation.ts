import { useCallback } from "react";
import { BackHandler, Platform } from "react-native";
import { useFocusEffect } from "expo-router";
import { useExitConfirmation } from "@/components/exit-confirmation-provider";
import { resolveRootBackAction } from "@/lib/navigation/root-back";

/** Intercepts Android Back on focused root tabs and opens the shared animated exit confirmation. */
export function useAndroidExitConfirmation() {
  const { isExitDialogOpen, requestExitConfirmation } = useExitConfirmation();
  useFocusEffect(useCallback(() => {
    if (Platform.OS !== "android") return undefined;
    const subscription = BackHandler.addEventListener("hardwareBackPress", () => {
      const action = resolveRootBackAction(Platform.OS, isExitDialogOpen());
      if (action === "delegate") return false;
      if (action === "consume") return true;
      requestExitConfirmation();
      return true;
    });
    return () => subscription.remove();
  }, [isExitDialogOpen, requestExitConfirmation]));
}
