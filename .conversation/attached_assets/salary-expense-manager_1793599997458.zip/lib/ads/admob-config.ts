/**
 * AdMob identifiers are public placement identifiers, not credentials. Keeping
 * them here prevents ad configuration from being scattered throughout screens.
 */
export const ADMOB_ANDROID_APP_ID = "ca-app-pub-2707556796843955~3786835750";
export const ADMOB_PRODUCTION_BANNER_UNIT_ID = "ca-app-pub-2707556796843955/3459532691";
export const ADMOB_TEST_ADAPTIVE_BANNER_UNIT_ID = "ca-app-pub-3940256099942544/9214589741";

export type AdMobBannerEligibilityInput = {
  isAndroid: boolean;
  isPremium: boolean;
  isSdkReady: boolean;
};

/**
 * Development builds must never request the live unit. Release builds use the
 * production unit, while a test-specific build can call this helper with true.
 */
export function resolveBannerAdUnitId(isTestBuild: boolean) {
  return isTestBuild ? ADMOB_TEST_ADAPTIVE_BANNER_UNIT_ID : ADMOB_PRODUCTION_BANNER_UNIT_ID;
}

/** Premium is the source of truth for the no-ads benefit. */
export function canShowHomeBanner({ isAndroid, isPremium, isSdkReady }: AdMobBannerEligibilityInput) {
  return isAndroid && !isPremium && isSdkReady;
}

