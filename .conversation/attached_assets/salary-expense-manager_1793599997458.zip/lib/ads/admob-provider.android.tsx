import { createContext, useContext, useEffect, useMemo, useState, type PropsWithChildren } from "react";
import { AdsConsent, default as mobileAds } from "react-native-google-mobile-ads";

type AdMobContextValue = {
  /** True only after consent processing and Android SDK initialization succeed. */
  isSdkReady: boolean;
};

const AdMobContext = createContext<AdMobContextValue | undefined>(undefined);
let mobileAdsInitialization: Promise<void> | undefined;

async function initializeAndroidMobileAds() {
  if (mobileAdsInitialization) return mobileAdsInitialization;

  mobileAdsInitialization = (async () => {
    // Google UMP refreshes consent information and presents a configured form only
    // when it is required. Do not persist consent status in local finance storage.
    try {
      await AdsConsent.gatherConsent();
    } catch {
      // A later check still respects any valid consent decision from a prior session.
    }

    const consentInfo = await AdsConsent.getConsentInfo();
    if (!consentInfo.canRequestAds) {
      throw new Error("Ad requests are not permitted until consent processing is complete.");
    }

    await mobileAds().initialize();
  })().catch((error) => {
    // Allow a future application mount to retry while keeping the current UI ad-free.
    mobileAdsInitialization = undefined;
    throw error;
  });

  return mobileAdsInitialization;
}

export function AdMobProvider({ children }: PropsWithChildren) {
  const [isSdkReady, setIsSdkReady] = useState(false);

  useEffect(() => {
    let isMounted = true;
    void initializeAndroidMobileAds()
      .then(() => {
        if (isMounted) setIsSdkReady(true);
      })
      .catch(() => {
        // Banner rendering remains disabled when consent or SDK initialization fails.
      });

    return () => {
      isMounted = false;
    };
  }, []);

  const value = useMemo(() => ({ isSdkReady }), [isSdkReady]);
  return <AdMobContext.Provider value={value}>{children}</AdMobContext.Provider>;
}

export function useAdMob() {
  const context = useContext(AdMobContext);
  if (!context) throw new Error("useAdMob must be used within AdMobProvider");
  return context;
}

