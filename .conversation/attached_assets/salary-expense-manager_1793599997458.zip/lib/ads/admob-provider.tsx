import { createContext, useContext, type PropsWithChildren } from "react";

type AdMobContextValue = { isSdkReady: boolean };
const AdMobContext = createContext<AdMobContextValue | undefined>(undefined);

/** Native Google Mobile Ads is intentionally omitted from the web preview. */
export function AdMobProvider({ children }: PropsWithChildren) {
  return <AdMobContext.Provider value={{ isSdkReady: false }}>{children}</AdMobContext.Provider>;
}

export function useAdMob() {
  const context = useContext(AdMobContext);
  if (!context) throw new Error("useAdMob must be used within AdMobProvider");
  return context;
}
