import { cycleTransactions, getSalaryCycle, todayIsoDate } from "./cycle";
import { dailySpendingSummary, financialSummary } from "./insights";
import type { FinanceSnapshot } from "./types";

export interface ForecastTimelineItem {
  id: string;
  date: string;
  label: string;
  amountMinor: number;
  kind: "bill" | "savings";
}

export interface AdvancedForecast {
  cycleStart: string;
  cycleEnd: string;
  daysRemaining: number;
  projectedEndBalanceMinor: number;
  safeDailySpendingMinor: number;
  plannedBillsMinor: number;
  plannedSavingsMinor: number;
  variableSpendingMinor: number;
  timeline: ForecastTimelineItem[];
}

export interface ForecastScenario {
  extraIncomeMinor: number;
  plannedExpenseMinor: number;
}

export const EMPTY_FORECAST_SCENARIO: ForecastScenario = {
  extraIncomeMinor: 0,
  plannedExpenseMinor: 0,
};

/**
 * Applies an in-memory scenario to an existing local forecast. Scenario
 * amounts are intentionally not persisted or turned into transactions.
 */
export function applyForecastScenario(forecast: AdvancedForecast, scenario: ForecastScenario): AdvancedForecast & ForecastScenario {
  const extraIncomeMinor = Math.max(0, Math.trunc(scenario.extraIncomeMinor));
  const plannedExpenseMinor = Math.max(0, Math.trunc(scenario.plannedExpenseMinor));
  const projectedEndBalanceMinor = forecast.projectedEndBalanceMinor + extraIncomeMinor - plannedExpenseMinor;
  const safeDailySpendingMinor = forecast.daysRemaining > 0 ? Math.max(0, Math.floor(projectedEndBalanceMinor / forecast.daysRemaining)) : 0;
  return { ...forecast, extraIncomeMinor, plannedExpenseMinor, projectedEndBalanceMinor, safeDailySpendingMinor };
}

/**
 * Transparent local projection: it reflects the current salary-cycle ledger,
 * including bills and automatic savings already scheduled for that cycle.
 */
export function buildAdvancedForecast(snapshot: FinanceSnapshot, referenceDate = todayIsoDate()): AdvancedForecast {
  const cycle = getSalaryCycle(referenceDate, snapshot.settings.salaryPaymentDay);
  const currentSummary = financialSummary(snapshot, referenceDate);
  const projectedSummary = financialSummary(snapshot, cycle.end);
  const daily = dailySpendingSummary(snapshot, currentSummary.availableSpendingMinor, referenceDate);
  const cycleLedger = cycleTransactions(snapshot, cycle);
  const timeline = cycleLedger
    .filter((transaction) => transaction.date >= referenceDate && (transaction.type === "fixed_expense" || transaction.type === "savings"))
    .sort((first, second) => first.date.localeCompare(second.date) || first.createdAt.localeCompare(second.createdAt))
    .map((transaction) => ({
      id: transaction.id,
      date: transaction.date,
      label: transaction.description?.trim() || (transaction.type === "fixed_expense" ? "Fixed bill" : "Savings deposit"),
      amountMinor: transaction.amountMinor,
      kind: transaction.type === "fixed_expense" ? "bill" as const : "savings" as const,
    }));

  return {
    cycleStart: cycle.start,
    cycleEnd: cycle.end,
    daysRemaining: daily.daysRemaining,
    projectedEndBalanceMinor: projectedSummary.availableSpendingMinor,
    safeDailySpendingMinor: daily.safeDailySpendingMinor,
    plannedBillsMinor: projectedSummary.totalFixedExpensesMinor,
    plannedSavingsMinor: Math.max(0, projectedSummary.totalSavingsMinor),
    variableSpendingMinor: projectedSummary.totalVariableExpensesMinor,
    timeline,
  };
}
