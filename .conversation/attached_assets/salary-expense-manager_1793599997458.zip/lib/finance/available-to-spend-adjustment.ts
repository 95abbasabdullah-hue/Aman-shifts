import type { FinanceTransaction } from "./types";

export type AvailableToSpendAdjustmentInput = {
  currentAvailableMinor: number;
  targetAvailableMinor: number;
  currency: string;
  date: string;
  accountId?: string;
};

/** Converts a dashboard target into a transparent ledger entry; past records are never changed. */
export function buildAvailableToSpendAdjustment({
  currentAvailableMinor,
  targetAvailableMinor,
  currency,
  date,
  accountId,
}: AvailableToSpendAdjustmentInput): Omit<FinanceTransaction, "id" | "createdAt" | "updatedAt"> | null {
  if (!Number.isInteger(targetAvailableMinor) || targetAvailableMinor < 0) {
    throw new Error("Enter a valid available-to-spend amount.");
  }
  const differenceMinor = targetAvailableMinor - currentAvailableMinor;
  if (differenceMinor === 0) return null;
  const isIncrease = differenceMinor > 0;
  return {
    type: isIncrease ? "income" : "variable_expense",
    amountMinor: Math.abs(differenceMinor),
    currency,
    category: "Other",
    date,
    description: "Available to spend adjustment",
    note: `Dashboard target updated to ${(targetAvailableMinor / 100).toFixed(2)} ${currency}.`,
    accountId,
  };
}
