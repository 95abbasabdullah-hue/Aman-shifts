export type BudgetThresholdValues = { warning: number; exceeded: number };

export function parseBudgetThresholds(warningValue: string, exceededValue: string): BudgetThresholdValues | { error: string } {
  const warning = Number(warningValue.trim());
  const exceeded = Number(exceededValue.trim());
  if (!Number.isFinite(warning) || !Number.isFinite(exceeded)) return { error: "Enter a number for both thresholds." };
  if (warning < 1 || warning > 100 || exceeded < 1 || exceeded > 100) return { error: "Use percentages between 1 and 100." };
  if (exceeded < warning) return { error: "The exceeded threshold must be at or above the warning threshold." };
  return { warning, exceeded };
}
