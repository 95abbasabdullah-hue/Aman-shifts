export type CalendarCell = { day: number; isoDate: string } | null;

export function parseCalendarDate(value: string): Date {
  const matched = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!matched) return new Date();
  const date = new Date(Number(matched[1]), Number(matched[2]) - 1, Number(matched[3]), 12);
  return date.getFullYear() === Number(matched[1]) && date.getMonth() === Number(matched[2]) - 1 && date.getDate() === Number(matched[3])
    ? date
    : new Date();
}

export function toCalendarIsoDate(value: Date): string {
  const year = value.getFullYear();
  const month = String(value.getMonth() + 1).padStart(2, "0");
  const day = String(value.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function shiftCalendarMonth(value: Date, offset: number): Date {
  return new Date(value.getFullYear(), value.getMonth() + offset, 1, 12);
}

export function calendarMonthCells(month: Date): CalendarCell[] {
  const year = month.getFullYear();
  const monthIndex = month.getMonth();
  const leadingEmptyCells = new Date(year, monthIndex, 1, 12).getDay();
  const totalDays = new Date(year, monthIndex + 1, 0, 12).getDate();
  const cells: CalendarCell[] = Array.from({ length: leadingEmptyCells }, () => null);
  for (let day = 1; day <= totalDays; day += 1) {
    cells.push({ day, isoDate: toCalendarIsoDate(new Date(year, monthIndex, day, 12)) });
  }
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}
