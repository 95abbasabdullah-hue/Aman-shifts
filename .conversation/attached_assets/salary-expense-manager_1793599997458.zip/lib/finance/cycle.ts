import type { FinanceSnapshot, FinanceTransaction, SalaryCycle } from "./types";

const MS_PER_DAY = 24 * 60 * 60 * 1000;

function toUtcDate(isoDate: string) {
  const [year, month, day] = isoDate.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, day));
}

function formatUtcDate(date: Date) {
  return date.toISOString().slice(0, 10);
}

function dateFromParts(year: number, monthIndex: number, preferredDay: number) {
  const finalDay = Math.min(Math.max(preferredDay, 1), daysInMonth(year, monthIndex));
  return new Date(Date.UTC(year, monthIndex, finalDay));
}

export function daysInMonth(year: number, monthIndex: number) {
  return new Date(Date.UTC(year, monthIndex + 1, 0)).getUTCDate();
}

export function todayIsoDate(date = new Date()) {
  return formatUtcDate(new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate())));
}

export function addDays(isoDate: string, count: number) {
  const value = toUtcDate(isoDate);
  value.setUTCDate(value.getUTCDate() + count);
  return formatUtcDate(value);
}

export function isDateWithin(isoDate: string, start: string, end: string) {
  return isoDate >= start && isoDate <= end;
}

/**
 * Returns the inclusive salary cycle that contains the reference date. A requested
 * day that is absent in a month is consistently represented by that month's final day.
 */
export function getSalaryCycle(referenceDate: string, salaryPaymentDay: number): SalaryCycle {
  const reference = toUtcDate(referenceDate);
  const year = reference.getUTCFullYear();
  const month = reference.getUTCMonth();
  const thisMonthPayday = dateFromParts(year, month, salaryPaymentDay);
  const startDate = reference >= thisMonthPayday
    ? thisMonthPayday
    : dateFromParts(year, month - 1, salaryPaymentDay);
  const nextStartDate = dateFromParts(
    startDate.getUTCFullYear(),
    startDate.getUTCMonth() + 1,
    salaryPaymentDay,
  );
  const endDate = new Date(nextStartDate.getTime() - MS_PER_DAY);
  const start = formatUtcDate(startDate);

  return { id: `cycle:${start}`, start, end: formatUtcDate(endDate) };
}

function parseDueDate(dueDate: string) {
  const [year, month, day] = dueDate.split("-").map(Number);
  return { year, monthIndex: month - 1, day };
}

/** Creates date occurrences that fall inside an inclusive date range. */
export function dueOccurrences(
  dueDate: string,
  frequency: "monthly" | "yearly",
  start: string,
  end: string,
) {
  const { monthIndex, day } = parseDueDate(dueDate);
  const startDate = toUtcDate(start);
  const endDate = toUtcDate(end);
  const occurrences: string[] = [];

  if (frequency === "monthly") {
    const cursor = new Date(Date.UTC(startDate.getUTCFullYear(), startDate.getUTCMonth(), 1));
    const lastMonth = new Date(Date.UTC(endDate.getUTCFullYear(), endDate.getUTCMonth(), 1));
    while (cursor <= lastMonth) {
      const candidate = dateFromParts(cursor.getUTCFullYear(), cursor.getUTCMonth(), day);
      const iso = formatUtcDate(candidate);
      if (isDateWithin(iso, start, end)) occurrences.push(iso);
      cursor.setUTCMonth(cursor.getUTCMonth() + 1);
    }
  } else {
    for (let year = startDate.getUTCFullYear(); year <= endDate.getUTCFullYear(); year += 1) {
      const candidate = dateFromParts(year, monthIndex, day);
      const iso = formatUtcDate(candidate);
      if (isDateWithin(iso, start, end)) occurrences.push(iso);
    }
  }

  return occurrences;
}

export function cycleTransactions(snapshot: FinanceSnapshot, cycle: SalaryCycle) {
  return snapshot.transactions.filter((transaction) =>
    isDateWithin(transaction.date, cycle.start, cycle.end),
  );
}

/**
 * Returns ledger entries whose stated date has arrived. Future-dated entries
 * remain scheduled and visible elsewhere, but cannot change today's balance.
 */
export function effectiveTransactionsThrough(transactions: FinanceTransaction[], referenceDate: string) {
  return transactions.filter((transaction) => transaction.date <= referenceDate);
}

export function totalByType(transactions: FinanceTransaction[], type: FinanceTransaction["type"]) {
  return transactions
    .filter((transaction) => transaction.type === type)
    .reduce((total, transaction) => total + transaction.amountMinor, 0);
}
