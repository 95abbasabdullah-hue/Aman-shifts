import type { BillCategory } from "./types";

export function isHomeFixedBillFlow(source: string | undefined, type: string) {
  return source === "home" && type === "fixed_expense";
}

export function homeFixedBillInput({
  name,
  amountMinor,
  currency,
  category,
  dueDate,
  note,
  active,
}: {
  name: string;
  amountMinor: number;
  currency: string;
  category: BillCategory;
  dueDate: string;
  note?: string;
  active: boolean;
}) {
  return { name, amountMinor, currency, category, dueDate, note, active, frequency: "monthly" as const };
}
