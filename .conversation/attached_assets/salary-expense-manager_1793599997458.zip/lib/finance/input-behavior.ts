/** Keeps standard finance fields editable unless a caller deliberately disables one. */
export function resolveTextInputEditable(editable: boolean | undefined): boolean {
  return editable !== false;
}
