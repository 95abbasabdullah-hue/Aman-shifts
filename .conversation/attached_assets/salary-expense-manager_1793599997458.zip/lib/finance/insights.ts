import { addDays, cycleTransactions, effectiveTransactionsThrough, getSalaryCycle, todayIsoDate, totalByType } from "./cycle";
import type {
  BudgetStatus,
  CategoryBudget,
  DailySpendingSummary,
  FinanceSnapshot,
  FinancialSummary,
  SavingsGoalSummary,
} from "./types";

function daysBetween(start: string, end: string) {
  const startUtc = Date.parse(`${start}T00:00:00Z`);
  const endUtc = Date.parse(`${end}T00:00:00Z`);
  return Math.round((endUtc - startUtc) / (24 * 60 * 60 * 1000));
}

function isDateInCurrentMonth(isoDate: string, referenceDate: string) {
  return isoDate.slice(0, 7) === referenceDate.slice(0, 7);
}

export function savingsGoalSummaries(snapshot: FinanceSnapshot): SavingsGoalSummary[] {
  return snapshot.savingsGoals
    .map((goal) => {
      const deposits = snapshot.transactions
        .filter((transaction) => transaction.type === "savings" && transaction.savingsGoalId === goal.id)
        .reduce((sum, transaction) => sum + transaction.amountMinor, 0);
      const withdrawals = snapshot.transactions
        .filter((transaction) => transaction.type === "savings_withdrawal" && transaction.savingsGoalId === goal.id)
        .reduce((sum, transaction) => sum + transaction.amountMinor, 0);
      const savedMinor = deposits - withdrawals;
      const remainingMinor = Math.max(0, goal.targetMinor - savedMinor);
      const progressPercent = goal.targetMinor > 0 ? Math.min(100, Math.max(0, (savedMinor / goal.targetMinor) * 100)) : 0;
      return { ...goal, savedMinor, remainingMinor, progressPercent };
    })
    .sort((first, second) => Number(second.active) - Number(first.active) || first.name.localeCompare(second.name));
}

export function budgetStatuses(snapshot: FinanceSnapshot, referenceDate = todayIsoDate()): BudgetStatus[] {
  const warningAt = snapshot.settings.budgetWarningThresholdPercent;
  const exceededAt = snapshot.settings.budgetExceededThresholdPercent;
  return snapshot.budgets
    .map((budget) => {
      const spentMinor = snapshot.transactions
        .filter((transaction) => transaction.type === "variable_expense" && transaction.category === budget.category && isDateInCurrentMonth(transaction.date, referenceDate) && transaction.date <= referenceDate)
        .reduce((sum, transaction) => sum + transaction.amountMinor, 0);
      const usedPercent = budget.limitMinor > 0 ? (spentMinor / budget.limitMinor) * 100 : 0;
      const state: BudgetStatus["state"] = usedPercent >= exceededAt ? "exceeded" : usedPercent >= warningAt ? "warning" : "normal";
      return { budget, spentMinor, remainingMinor: budget.limitMinor - spentMinor, usedPercent, state };
    })
    .sort((first, second) => second.usedPercent - first.usedPercent || first.budget.category.localeCompare(second.budget.category));
}

export function dailySpendingSummary(snapshot: FinanceSnapshot, availableMinor: number, referenceDate = todayIsoDate()): DailySpendingSummary {
  const cycle = getSalaryCycle(referenceDate, snapshot.settings.salaryPaymentDay);
  const nextSalaryDate = addDays(cycle.end, 1);
  const daysRemaining = Math.max(1, daysBetween(referenceDate, nextSalaryDate));
  return { daysRemaining, safeDailySpendingMinor: Math.max(0, Math.floor(availableMinor / daysRemaining)) };
}

export function financialSummary(snapshot: FinanceSnapshot, referenceDate = todayIsoDate()): FinancialSummary {
  const cycle = getSalaryCycle(referenceDate, snapshot.settings.salaryPaymentDay);
  const transactions = effectiveTransactionsThrough(cycleTransactions(snapshot, cycle), referenceDate);
  const totalIncomeMinor = totalByType(transactions, "income");
  const totalFixedExpensesMinor = totalByType(transactions, "fixed_expense");
  const totalVariableExpensesMinor = totalByType(transactions, "variable_expense");
  const savingsDeposits = totalByType(transactions, "savings");
  const savingsWithdrawals = totalByType(transactions, "savings_withdrawal");
  const totalSavingsMinor = savingsDeposits - savingsWithdrawals;
  const availableSpendingMinor = totalIncomeMinor - totalFixedExpensesMinor - totalVariableExpensesMinor - totalSavingsMinor;
  const elapsedDays = Math.max(1, daysBetween(cycle.start, referenceDate) + 1);
  const categories = transactions
    .filter((transaction) => transaction.type === "variable_expense")
    .reduce<Record<string, number>>((totals, transaction) => ({ ...totals, [transaction.category]: (totals[transaction.category] ?? 0) + transaction.amountMinor }), {});
  const highest = Object.entries(categories).sort((first, second) => second[1] - first[1])[0];

  return {
    totalIncomeMinor,
    totalFixedExpensesMinor,
    totalVariableExpensesMinor,
    totalSavingsMinor,
    availableSpendingMinor,
    averageDailySpendingMinor: Math.floor(totalVariableExpensesMinor / elapsedDays),
    highestSpendingCategory: highest?.[0] ?? null,
    highestSpendingCategoryMinor: highest?.[1] ?? 0,
  };
}

export function validateSavingsGoalAmount(amountMinor: number, label: string) {
  return Number.isInteger(amountMinor) && amountMinor >= 0
    ? undefined
    : `Enter a valid ${label.toLowerCase()} amount.`;
}

export function budgetForCategory(budgets: CategoryBudget[], category: string) {
  return budgets.find((budget) => budget.category === category);
}
