import type { SoundPreferences } from "./types";

export function areSelectionHapticsEnabled(preferences: SoundPreferences) {
  return preferences.hapticsEnabled && preferences.selectionHaptics;
}
