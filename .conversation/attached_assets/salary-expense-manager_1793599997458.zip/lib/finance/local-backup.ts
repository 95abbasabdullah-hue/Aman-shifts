import * as DocumentPicker from "expo-document-picker";
import { File, Paths } from "expo-file-system";
import * as Sharing from "expo-sharing";
import { Platform } from "react-native";
import { createBackupPayload, validateBackupPayload } from "./repository";
import type { BackupPayload, FinanceSnapshot } from "./types";

export function backupJson(snapshot: FinanceSnapshot) { return JSON.stringify(createBackupPayload(snapshot), null, 2); }

export function parseBackupJson(content: string): BackupPayload {
  const parsed: unknown = JSON.parse(content);
  if (!validateBackupPayload(parsed)) throw new Error("This file is not a valid Salary & Expense Manager backup.");
  return parsed;
}

export async function exportLocalBackup(snapshot: FinanceSnapshot) {
  const content = backupJson(snapshot);
  if (Platform.OS === "web") return content;
  const file = new File(Paths.cache, `salary-expense-manager-backup-${new Date().toISOString().slice(0, 10)}.json`);
  file.create({ overwrite: true, intermediates: true });
  file.write(content);
  if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(file.uri, { mimeType: "application/json", dialogTitle: "Export local finance backup" });
  return file.uri;
}

export async function selectLocalBackup(): Promise<BackupPayload | null> {
  const result = await DocumentPicker.getDocumentAsync({ type: ["application/json", "text/json", "text/plain"], copyToCacheDirectory: true, multiple: false });
  if (result.canceled || !result.assets?.[0]) return null;
  const file = new File(result.assets[0].uri);
  return parseBackupJson(await file.text());
}
