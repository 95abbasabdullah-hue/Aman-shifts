import * as Haptics from "expo-haptics";
import { Platform } from "react-native";
import { areSelectionHapticsEnabled } from "./interaction-haptics";
import type { SoundPreferences } from "./types";

export { areSelectionHapticsEnabled } from "./interaction-haptics";

/** Optional native feedback only. It never blocks a form interaction or finance update. */
export function playSelectionHaptic(preferences: SoundPreferences) {
  if (Platform.OS === "web" || !areSelectionHapticsEnabled(preferences)) return;
  void Haptics.selectionAsync().catch(() => undefined);
}
