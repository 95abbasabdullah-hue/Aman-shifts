import * as Notifications from "expo-notifications";
import { Linking, Platform } from "react-native";
import { todayIsoDate } from "./cycle";
import { buildLocalReminderPlan, type LocalReminderPlanItem } from "./reminder-plan";
import type { FinanceSnapshot, NotificationPreferences } from "./types";

const CHANNELS = {
  salary: "finance-salary",
  bills: "finance-bills",
  budgets: "finance-budgets",
  savings: "finance-savings",
} as const;

export type LocalReminder = LocalReminderPlanItem;

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: false, shouldSetBadge: false }),
});

async function configureChannels(preferences: NotificationPreferences) {
  if (Platform.OS !== "android") return;
  const sound = preferences.notificationSound ? "default" : undefined;
  const vibrationPattern = preferences.vibration ? [0, 160, 70, 120] : undefined;
  await Promise.all([
    Notifications.setNotificationChannelAsync(CHANNELS.salary, { name: "Salary notifications", description: "Salary-day and salary-cycle reminders", importance: Notifications.AndroidImportance.DEFAULT, sound, enableVibrate: preferences.vibration, vibrationPattern, lightColor: "#198B73" }),
    Notifications.setNotificationChannelAsync(CHANNELS.bills, { name: "Bill notifications", description: "Upcoming bill reminders", importance: Notifications.AndroidImportance.DEFAULT, sound, enableVibrate: preferences.vibration, vibrationPattern, lightColor: "#D69A2D" }),
    Notifications.setNotificationChannelAsync(CHANNELS.budgets, { name: "Budget notifications", description: "Budget threshold warnings", importance: Notifications.AndroidImportance.DEFAULT, sound, enableVibrate: preferences.vibration, vibrationPattern, lightColor: "#D45B5B" }),
    Notifications.setNotificationChannelAsync(CHANNELS.savings, { name: "Savings notifications", description: "Savings milestones and goal completion", importance: Notifications.AndroidImportance.LOW, sound, enableVibrate: preferences.vibration, vibrationPattern, lightColor: "#198B73" }),
  ]);
}

export async function enableLocalNotifications(preferences?: NotificationPreferences) {
  if (Platform.OS === "web") return false;
  const existing = await Notifications.getPermissionsAsync();
  if (existing.status === "granted") { if (preferences) await configureChannels(preferences); return true; }
  if (!existing.canAskAgain) return false;
  const requested = await Notifications.requestPermissionsAsync();
  if (requested.status === "granted" && preferences) await configureChannels(preferences);
  return requested.status === "granted";
}

export async function openSystemNotificationSettings() {
  if (Platform.OS === "web") return false;
  return Linking.openSettings();
}

/** Cancels only this application's locally scheduled finance reminders. */
export async function clearLocalNotifications() {
  if (Platform.OS === "web") return;
  await Notifications.cancelAllScheduledNotificationsAsync();
}

function triggerForDate(isoDate: string) {
  const date = new Date(`${isoDate}T09:00:00`);
  return { type: Notifications.SchedulableTriggerInputTypes.DATE, date } as const;
}

/** Replaces this app's scheduled local reminders; no network token or remote service is involved. */
export async function syncLocalNotifications(snapshot: FinanceSnapshot) {
  if (Platform.OS === "web") return;
  await Notifications.cancelAllScheduledNotificationsAsync();
  const preferences = snapshot.settings.notificationPreferences;
  if (!preferences.enabled) return;
  const allowed = await enableLocalNotifications(preferences);
  if (!allowed) return;
  for (const reminder of buildLocalReminderPlan(snapshot)) {
    await Notifications.scheduleNotificationAsync({
      identifier: reminder.id,
      content: { title: reminder.title, body: reminder.body, sound: preferences.notificationSound ? "default" : undefined, data: { localOnly: true, route: reminder.route, kind: reminder.channelId } },
      trigger: Platform.OS === "android" ? { ...triggerForDate(reminder.date), channelId: reminder.channelId } : triggerForDate(reminder.date),
    });
  }
}

export async function showLocalMilestoneNotification(kind: "budget" | "savings", title: string, body: string, preferences: NotificationPreferences) {
  if (Platform.OS === "web" || !preferences.enabled) return;
  const allowed = await enableLocalNotifications(preferences);
  if (!allowed) return;
  const channelId = kind === "budget" ? CHANNELS.budgets : CHANNELS.savings;
  await Notifications.scheduleNotificationAsync({ content: { title, body, sound: preferences.notificationSound ? "default" : undefined, data: { localOnly: true, route: "/(tabs)", kind } }, trigger: Platform.OS === "android" ? { channelId } : null });
}
