import { File, Paths } from "expo-file-system";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { Platform } from "react-native";
import { localReportCsv, localReportHtml, type LocalFinanceReport, type ReportExportFormat, type ReportPeriod } from "./report-content";

export { buildLocalFinanceReport, localReportCsv, localReportHtml, type LocalFinanceReport, type ReportExportFormat, type ReportPeriod } from "./report-content";

function exportName(period: ReportPeriod, extension: ReportExportFormat) {
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  return `salary-manager-${period}-report-${timestamp}.${extension}`;
}

function downloadFromBrowser(content: string, fileName: string, mimeType: string) {
  const url = URL.createObjectURL(new Blob([content], { type: mimeType }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

export async function exportLocalReport(report: LocalFinanceReport, format: ReportExportFormat) {
  const fileName = exportName(report.period, format);
  const content = format === "csv" ? localReportCsv(report) : localReportHtml(report);
  if (Platform.OS === "web") {
    if (format === "csv") {
      downloadFromBrowser(content, fileName, "text/csv;charset=utf-8");
      return { mode: "download" as const, fileName };
    }
    const printWindow = window.open("", "_blank");
    if (!printWindow) throw new Error("Your browser blocked the PDF window. Allow pop-ups and try again.");
    printWindow.document.write(content);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    return { mode: "print" as const, fileName };
  }
  if (format === "csv") {
    const file = new File(Paths.document, fileName);
    file.create({ overwrite: true, intermediates: true });
    file.write(content);
    if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(file.uri, { mimeType: "text/csv", dialogTitle: "Export CSV financial report" });
    return { mode: "file" as const, fileName, uri: file.uri };
  }
  const generated = await Print.printToFileAsync({ html: content, margins: { top: 24, bottom: 24, left: 24, right: 24 } });
  const file = new File(Paths.document, fileName);
  file.create({ overwrite: true, intermediates: true });
  new File(generated.uri).copy(file);
  if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(file.uri, { mimeType: "application/pdf", UTI: "com.adobe.pdf", dialogTitle: "Export PDF financial report" });
  return { mode: "file" as const, fileName, uri: file.uri };
}
