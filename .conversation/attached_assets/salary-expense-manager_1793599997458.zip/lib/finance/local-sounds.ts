import { createAudioPlayer, type AudioPlayer } from "expo-audio";
import { Platform } from "react-native";
import { shouldPlayFinanceSound, type FinanceSound } from "./sound-policy";
import type { SoundPreferences } from "./types";

export type { FinanceSound } from "./sound-policy";

const sources = {
  transactionAdded: require("@/assets/sounds/transaction-added.mp3"),
  salaryReceived: require("@/assets/sounds/salary-received.mp3"),
  goalCompleted: require("@/assets/sounds/goal-completed.mp3"),
} as const;

const players = new Map<FinanceSound, AudioPlayer>();

/** Plays bundled short feedback only. Errors, mute state, and system interruption never affect finance mutations. */
export function playLocalSound(sound: FinanceSound, preferences: SoundPreferences) {
  if (Platform.OS === "web" || !shouldPlayFinanceSound(sound, preferences)) return;
  try {
    let player = players.get(sound);
    if (!player) {
      player = createAudioPlayer(sources[sound]);
      players.set(sound, player);
    }
    player.seekTo(0);
    player.play();
  } catch {
    // Sound feedback is optional and intentionally non-blocking.
  }
}

export function releaseLocalSoundPlayers() {
  for (const player of players.values()) player.remove();
  players.clear();
}
