export const LOCKED_QUICK_EXPENSE_PREVIEW_NAMES = ["Coffee", "Fuel", "Lunch"] as const;

/** Locked previews are static product examples and must never expose saved template data. */
export function usesLockedTemplatePreview(savedTemplateCount: number, isPremium: boolean) {
  return !isPremium && savedTemplateCount >= 0;
}
