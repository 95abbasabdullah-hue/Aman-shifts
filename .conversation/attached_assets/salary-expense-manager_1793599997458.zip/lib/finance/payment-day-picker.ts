/** All valid salary payment days; shorter months are handled by the existing cycle calculation. */
export const SALARY_PAYMENT_DAYS = Array.from({ length: 31 }, (_, index) => index + 1);

export function normalizeSalaryPaymentDay(day: number): number {
  return Number.isInteger(day) && day >= 1 && day <= 31 ? day : 1;
}
