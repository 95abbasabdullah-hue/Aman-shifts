import { addDays, cycleTransactions, dueOccurrences, effectiveTransactionsThrough, getSalaryCycle, isDateWithin, todayIsoDate } from "./cycle";
import type { AccountSummary, FinanceSnapshot, FinanceTransaction, RecurrenceFrequency, SalaryCycle } from "./types";

export interface TransactionSearchFilters {
  query?: string;
  category?: string;
  accountId?: string;
  type?: FinanceTransaction["type"] | "all";
  startDate?: string;
  endDate?: string;
  minAmountMinor?: number;
  maxAmountMinor?: number;
  sort?: "newest" | "oldest" | "highest" | "lowest";
}

export function convertToMainMinor(snapshot: FinanceSnapshot, amountMinor: number, currency: string) {
  const rate = snapshot.currencyRates.find((item) => item.currency === currency)?.rateToMain ?? (currency === snapshot.settings.currency ? 1 : 1);
  return Math.round(amountMinor * rate);
}

function transactionEffect(transaction: FinanceTransaction) {
  const amount = transaction.baseAmountMinor ?? transaction.amountMinor;
  if (transaction.type === "income" || transaction.type === "savings_withdrawal" || transaction.type === "transfer_in") return amount;
  return -amount;
}

export function accountSummaries(snapshot: FinanceSnapshot, referenceDate = todayIsoDate()): AccountSummary[] {
  return snapshot.accounts
    .map((account) => {
      const movements = effectiveTransactionsThrough(snapshot.transactions, referenceDate)
        .filter((transaction) => transaction.accountId === account.id)
        .reduce((total, transaction) => total + transactionEffect(transaction), 0);
      const balanceBaseMinor = account.openingBalanceBaseMinor + movements;
      const rate = snapshot.currencyRates.find((item) => item.currency === account.currency)?.rateToMain ?? (account.currency === snapshot.settings.currency ? 1 : 1);
      return { ...account, balanceBaseMinor, balanceMinor: Math.round(balanceBaseMinor / rate) };
    })
    .sort((first, second) => first.name.localeCompare(second.name));
}

export function recurringExpenseOccurrences(rule: { startDate: string; frequency: RecurrenceFrequency; customIntervalDays?: number }, cycle: SalaryCycle) {
  if (rule.frequency === "monthly") return dueOccurrences(rule.startDate, "monthly", cycle.start, cycle.end);
  if (rule.frequency === "yearly") return dueOccurrences(rule.startDate, "yearly", cycle.start, cycle.end);
  const interval = rule.frequency === "weekly" ? 7 : rule.customIntervalDays ?? 0;
  if (!Number.isInteger(interval) || interval <= 0) return [];
  const values: string[] = [];
  let cursor = rule.startDate;
  while (cursor < cycle.start) cursor = addDays(cursor, interval);
  while (cursor <= cycle.end) {
    if (isDateWithin(cursor, cycle.start, cycle.end)) values.push(cursor);
    cursor = addDays(cursor, interval);
  }
  return values;
}

export function selectedPeriodTransactions(snapshot: FinanceSnapshot, period: "current_cycle" | "previous_cycle" | "month" | "year", referenceDate = todayIsoDate()) {
  const currentCycle = getSalaryCycle(referenceDate, snapshot.settings.salaryPaymentDay);
  if (period === "current_cycle") return cycleTransactions(snapshot, currentCycle);
  if (period === "previous_cycle") {
    const previousCycle = getSalaryCycle(addDays(currentCycle.start, -1), snapshot.settings.salaryPaymentDay);
    return cycleTransactions(snapshot, previousCycle);
  }
  if (period === "month") return snapshot.transactions.filter((item) => item.date.slice(0, 7) === referenceDate.slice(0, 7));
  return snapshot.transactions.filter((item) => item.date.slice(0, 4) === referenceDate.slice(0, 4));
}

export function filterTransactions(transactions: FinanceTransaction[], filters: TransactionSearchFilters) {
  const query = filters.query?.trim().toLowerCase() ?? "";
  return transactions
    .filter((item) => !query || [item.description, item.category, item.note ?? ""].some((field) => field.toLowerCase().includes(query)))
    .filter((item) => !filters.category || item.category === filters.category)
    .filter((item) => !filters.accountId || item.accountId === filters.accountId)
    .filter((item) => !filters.type || filters.type === "all" || item.type === filters.type)
    .filter((item) => !filters.startDate || item.date >= filters.startDate)
    .filter((item) => !filters.endDate || item.date <= filters.endDate)
    .filter((item) => filters.minAmountMinor === undefined || item.amountMinor >= filters.minAmountMinor)
    .filter((item) => filters.maxAmountMinor === undefined || item.amountMinor <= filters.maxAmountMinor)
    .sort((first, second) => {
      if (filters.sort === "oldest") return first.date.localeCompare(second.date);
      if (filters.sort === "highest") return second.amountMinor - first.amountMinor;
      if (filters.sort === "lowest") return first.amountMinor - second.amountMinor;
      return second.date.localeCompare(first.date);
    });
}

export function categorySpend(transactions: FinanceTransaction[]) {
  return transactions
    .filter((item) => item.type === "variable_expense")
    .reduce<Record<string, number>>((totals, item) => ({ ...totals, [item.category]: (totals[item.category] ?? 0) + (item.baseAmountMinor ?? item.amountMinor) }), {});
}
