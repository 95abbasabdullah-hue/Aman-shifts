import { budgetStatuses, savingsGoalSummaries } from "./insights";
import type { FinanceSnapshot, PremiumFeedbackEvent } from "./types";

export type FeedbackTransition = { snapshot: FinanceSnapshot; feedback: PremiumFeedbackEvent | null; notifications: Array<{ kind: "budget" | "savings"; title: string; body: string }> };

/** Detects real local threshold crossings and records stable keys so feedback never repeats after rehydration. */
export function processPremiumFeedback(previous: FinanceSnapshot, candidate: FinanceSnapshot, referenceDate: string): FeedbackTransition {
  const keys = new Set(candidate.processedExperienceKeys);
  const notifications: FeedbackTransition["notifications"] = [];
  let feedback: PremiumFeedbackEvent | null = null;
  const newlyCreated = candidate.transactions.filter((item) => !previous.transactions.some((prior) => prior.id === item.id));
  const salary = newlyCreated.find((item) => item.type === "income" && item.recurringKey?.startsWith("salary:"));
  if (salary) {
    const key = `salary-feedback:${salary.recurringKey}`;
    if (!keys.has(key)) { keys.add(key); feedback = { key, kind: "salary", title: "Salary received", detail: "Your new salary cycle has been added locally.", amountMinor: salary.amountMinor }; }
  }
  const previousGoals = new Map(savingsGoalSummaries(previous).map((goal) => [goal.id, goal]));
  for (const goal of savingsGoalSummaries(candidate)) {
    const before = previousGoals.get(goal.id)?.progressPercent ?? 0;
    for (const threshold of [50, 75, 100]) {
      const key = `savings:${goal.id}:${threshold}`;
      if (before < threshold && goal.progressPercent >= threshold && !keys.has(key)) {
        keys.add(key);
        if (candidate.settings.notificationPreferences.savingsGoal) notifications.push({ kind: "savings", title: threshold === 100 ? "Savings goal complete" : "Savings milestone", body: threshold === 100 ? `${goal.name} is fully funded.` : `${goal.name} is ${threshold}% complete.` });
        if (threshold === 100 && !feedback) feedback = { key, kind: "goal", title: "Goal completed", detail: goal.name, amountMinor: goal.savedMinor };
      }
    }
  }
  const priorBudgets = new Map(budgetStatuses(previous, referenceDate).map((status) => [status.budget.id, status]));
  for (const status of budgetStatuses(candidate, referenceDate)) {
    const before = priorBudgets.get(status.budget.id)?.usedPercent ?? 0;
    for (const threshold of [80, 90, 100]) {
      const key = `budget:${status.budget.id}:${referenceDate}:${threshold}`;
      if (before < threshold && status.usedPercent >= threshold && !keys.has(key)) {
        keys.add(key);
        if (candidate.settings.notificationPreferences.budgetWarning) notifications.push({ kind: "budget", title: threshold === 100 ? "Budget reached" : "Budget warning", body: `${status.budget.category} is now ${threshold}% used.` });
      }
    }
  }
  return { snapshot: { ...candidate, processedExperienceKeys: [...keys].slice(-500) }, feedback, notifications };
}
