import { createContext, useCallback, useContext, useEffect, useMemo, useState, type PropsWithChildren } from "react";
import { cycleTransactions, effectiveTransactionsThrough, getSalaryCycle, todayIsoDate, totalByType } from "./cycle";
import { budgetStatuses, dailySpendingSummary, financialSummary, savingsGoalSummaries } from "./insights";
import { clearLocalNotifications, showLocalMilestoneNotification, syncLocalNotifications } from "./local-notifications";
import { playLocalSound } from "./local-sounds";
import { accountSummaries, convertToMainMinor } from "./phase3";
import { processPremiumFeedback } from "./premium-events";
import { deleteTransactionFromSnapshot } from "./transaction-delete";
import { applyRecurringEntries, ensureCurrentSalary, reconcileCurrentCycleBillEntries, removeCurrentCycleGeneratedEntries } from "./recurrence";
import { clearFinanceSnapshot, loadFinanceSnapshot, mergeFinanceSnapshots, migrateFinanceSnapshot, saveFinanceSnapshot } from "./repository";
import {
  EMPTY_FINANCE_SNAPSHOT,
  type AccountSummary,
  type AppSettings,
  type BackupPayload,
  type BudgetStatus,
  type CategoryBudget,
  type CycleSummary,
  type DailySpendingSummary,
  type FinancialAccount,
  type FinancialSummary,
  type FinanceSnapshot,
  type FinanceTransaction,
  type FixedBill,
  type ManualCurrencyRate,
  type PremiumFeedbackEvent,
  type QuickExpenseTemplate,
  type RecurringExpense,
  type SavingsGoal,
  type SavingsGoalSummary,
} from "./types";

type TransactionInput = Omit<FinanceTransaction, "id" | "createdAt" | "updatedAt">;
type BillInput = Omit<FixedBill, "id" | "createdAt" | "updatedAt">;
type SavingsGoalInput = Omit<SavingsGoal, "id" | "createdAt" | "updatedAt">;
type BudgetInput = Omit<CategoryBudget, "id" | "createdAt" | "updatedAt">;
type AccountInput = Omit<FinancialAccount, "id" | "createdAt" | "updatedAt" | "openingBalanceBaseMinor">;
type RecurringExpenseInput = Omit<RecurringExpense, "id" | "createdAt" | "updatedAt">;
type CurrencyRateInput = Omit<ManualCurrencyRate, "id" | "updatedAt">;
type QuickExpenseTemplateInput = Omit<QuickExpenseTemplate, "id" | "createdAt" | "updatedAt">;

export interface TransferInput { fromAccountId: string; toAccountId: string; amountMinor: number; date: string; note?: string; }

interface FinanceContextValue {
  snapshot: FinanceSnapshot;
  isReady: boolean;
  cycleSummary: CycleSummary;
  currentCycleTransactions: FinanceTransaction[];
  recentTransactions: FinanceTransaction[];
  savingsGoals: SavingsGoalSummary[];
  budgetStatuses: BudgetStatus[];
  dailySpending: DailySpendingSummary;
  financialSummary: FinancialSummary;
  accounts: AccountSummary[];
  premiumFeedback: PremiumFeedbackEvent | null;
  dismissPremiumFeedback: () => void;
  updateSettings: (settings: Partial<AppSettings>) => Promise<void>;
  saveTransaction: (input: TransactionInput, id?: string) => Promise<void>;
  deleteTransaction: (id: string) => Promise<void>;
  saveBill: (input: BillInput, id?: string) => Promise<void>;
  deleteBill: (id: string) => Promise<void>;
  saveSavingsGoal: (input: SavingsGoalInput, id?: string) => Promise<void>;
  deleteSavingsGoal: (id: string) => Promise<void>;
  saveBudget: (input: BudgetInput, id?: string) => Promise<void>;
  deleteBudget: (id: string) => Promise<void>;
  saveAccount: (input: AccountInput, id?: string) => Promise<void>;
  deleteAccount: (id: string) => Promise<void>;
  createTransfer: (input: TransferInput) => Promise<void>;
  saveRecurringExpense: (input: RecurringExpenseInput, id?: string) => Promise<void>;
  deleteRecurringExpense: (id: string) => Promise<void>;
  saveCurrencyRate: (input: CurrencyRateInput) => Promise<void>;
  deleteCurrencyRate: (currency: string) => Promise<void>;
  saveQuickExpenseTemplate: (input: QuickExpenseTemplateInput, id?: string) => Promise<void>;
  deleteQuickExpenseTemplate: (id: string) => Promise<void>;
  restoreSnapshot: (payload: BackupPayload, mode: "replace" | "merge") => Promise<void>;
  resetData: () => Promise<void>;
}

const FinanceContext = createContext<FinanceContextValue | undefined>(undefined);
const createId = (prefix: string) => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
const equalSnapshot = (first: FinanceSnapshot, second: FinanceSnapshot) => JSON.stringify(first) === JSON.stringify(second);

export function FinanceProvider({ children }: PropsWithChildren) {
  const [snapshot, setSnapshot] = useState<FinanceSnapshot>(EMPTY_FINANCE_SNAPSHOT);
  const [isReady, setIsReady] = useState(false);
  const [referenceDate, setReferenceDate] = useState(todayIsoDate());
  const [premiumFeedback, setPremiumFeedback] = useState<PremiumFeedbackEvent | null>(null);
  const persist = useCallback(async (next: FinanceSnapshot) => { setSnapshot(next); await saveFinanceSnapshot(next); }, []);
  const persistWithFeedback = useCallback(async (previous: FinanceSnapshot, candidate: FinanceSnapshot) => {
    const outcome = processPremiumFeedback(previous, candidate, referenceDate);
    await persist(outcome.snapshot);
    if (outcome.feedback) {
      setPremiumFeedback(outcome.feedback);
      playLocalSound(outcome.feedback.kind === "salary" ? "salaryReceived" : "goalCompleted", outcome.snapshot.settings.soundPreferences);
    }
    for (const notification of outcome.notifications) void showLocalMilestoneNotification(notification.kind, notification.title, notification.body, outcome.snapshot.settings.notificationPreferences);
  }, [persist, referenceDate]);

  useEffect(() => {
    let active = true;
    const hydrate = async () => {
      const stored = await loadFinanceSnapshot();
      const updated = applyRecurringEntries(stored);
      const outcome = processPremiumFeedback(stored, updated, todayIsoDate());
      if (!active) return;
      setSnapshot(outcome.snapshot); setIsReady(true);
      if (outcome.feedback) { setPremiumFeedback(outcome.feedback); playLocalSound(outcome.feedback.kind === "salary" ? "salaryReceived" : "goalCompleted", outcome.snapshot.settings.soundPreferences); }
      for (const notification of outcome.notifications) void showLocalMilestoneNotification(notification.kind, notification.title, notification.body, outcome.snapshot.settings.notificationPreferences);
      if (!equalSnapshot(stored, outcome.snapshot)) await saveFinanceSnapshot(outcome.snapshot);
    };
    void hydrate();
    return () => { active = false; };
  }, []);
  useEffect(() => { const timer = setInterval(() => setReferenceDate(todayIsoDate()), 60_000); return () => clearInterval(timer); }, []);
  useEffect(() => { if (!isReady) return; const updated = applyRecurringEntries(snapshot, referenceDate); if (!equalSnapshot(snapshot, updated)) void persistWithFeedback(snapshot, updated); }, [isReady, persistWithFeedback, referenceDate, snapshot]);
  useEffect(() => { if (isReady) void syncLocalNotifications(snapshot); }, [isReady, snapshot]);

  const updateSettings = useCallback(async (settings: Partial<AppSettings>) => {
    const updatedSettings = { ...snapshot.settings, ...settings, notificationPreferences: { ...snapshot.settings.notificationPreferences, ...settings.notificationPreferences }, soundPreferences: { ...snapshot.settings.soundPreferences, ...settings.soundPreferences } };
    let next = { ...snapshot, settings: updatedSettings };
    if (updatedSettings.monthlySalaryMinor > 0) next = ensureCurrentSalary(next);
    await persistWithFeedback(snapshot, applyRecurringEntries(next, referenceDate));
  }, [persistWithFeedback, referenceDate, snapshot]);

  const normalizeTransaction = useCallback((input: TransactionInput) => ({
    ...input,
    accountId: input.accountId ?? snapshot.accounts[0]?.id,
    baseAmountMinor: input.baseAmountMinor ?? convertToMainMinor(snapshot, input.amountMinor, input.currency),
  }), [snapshot]);

  const saveTransaction = useCallback(async (input: TransactionInput, id?: string) => {
    const now = new Date().toISOString(); const normalized = normalizeTransaction(input);
    const next = id
      ? { ...snapshot, transactions: snapshot.transactions.map((item) => item.id === id ? { ...item, ...normalized, id, updatedAt: now } : item) }
      : { ...snapshot, transactions: [{ ...normalized, id: createId("txn"), createdAt: now, updatedAt: now }, ...snapshot.transactions] };
    await persistWithFeedback(snapshot, input.type === "income" ? applyRecurringEntries(next, referenceDate) : next);
    if (!id && input.type !== "fixed_expense" && input.type !== "savings") playLocalSound("transactionAdded", snapshot.settings.soundPreferences);
  }, [normalizeTransaction, persistWithFeedback, referenceDate, snapshot]);

  const deleteTransaction = useCallback(async (id: string) => {
    await persist(deleteTransactionFromSnapshot(snapshot, id));
  }, [persist, snapshot]);

  const saveBill = useCallback(async (input: BillInput, id?: string) => {
    const now = new Date().toISOString();
    const next = id ? { ...snapshot, bills: snapshot.bills.map((item) => item.id === id ? { ...item, ...input, id, updatedAt: now } : item) } : { ...snapshot, bills: [{ ...input, id: createId("bill"), createdAt: now, updatedAt: now }, ...snapshot.bills] };
    const updated = id
      ? reconcileCurrentCycleBillEntries(next, id, referenceDate)
      : applyRecurringEntries(next, referenceDate);
    await persistWithFeedback(snapshot, updated);
  }, [persistWithFeedback, referenceDate, snapshot]);
  const deleteBill = useCallback(async (id: string) => {
    const next = { ...snapshot, bills: snapshot.bills.filter((item) => item.id !== id) };
    await persist(removeCurrentCycleGeneratedEntries(next, { billId: id }, referenceDate));
  }, [persist, referenceDate, snapshot]);

  const saveSavingsGoal = useCallback(async (input: SavingsGoalInput, id?: string) => {
    const now = new Date().toISOString();
    const next = id ? { ...snapshot, savingsGoals: snapshot.savingsGoals.map((item) => item.id === id ? { ...item, ...input, id, updatedAt: now } : item) } : { ...snapshot, savingsGoals: [{ ...input, id: createId("goal"), createdAt: now, updatedAt: now }, ...snapshot.savingsGoals] };
    await persist(applyRecurringEntries(next, referenceDate));
  }, [persist, referenceDate, snapshot]);
  const deleteSavingsGoal = useCallback(async (id: string) => { await persist({ ...snapshot, savingsGoals: snapshot.savingsGoals.filter((item) => item.id !== id) }); }, [persist, snapshot]);
  const saveQuickExpenseTemplate = useCallback(async (input: QuickExpenseTemplateInput, id?: string) => {
    const now = new Date().toISOString();
    const next = id
      ? { ...snapshot, quickExpenseTemplates: snapshot.quickExpenseTemplates.map((item) => item.id === id ? { ...item, ...input, id, updatedAt: now } : item) }
      : { ...snapshot, quickExpenseTemplates: [{ ...input, id: createId("quick"), createdAt: now, updatedAt: now }, ...snapshot.quickExpenseTemplates] };
    await persist(next);
  }, [persist, snapshot]);
  const deleteQuickExpenseTemplate = useCallback(async (id: string) => { await persist({ ...snapshot, quickExpenseTemplates: snapshot.quickExpenseTemplates.filter((item) => item.id !== id) }); }, [persist, snapshot]);

  const saveBudget = useCallback(async (input: BudgetInput, id?: string) => {
    const now = new Date().toISOString(); const duplicate = snapshot.budgets.find((item) => item.category === input.category && item.id !== id); const targetId = id ?? duplicate?.id;
    const next = targetId ? { ...snapshot, budgets: snapshot.budgets.map((item) => item.id === targetId ? { ...item, ...input, id: targetId, updatedAt: now } : item) } : { ...snapshot, budgets: [{ ...input, id: createId("budget"), createdAt: now, updatedAt: now }, ...snapshot.budgets] };
    await persist(next);
  }, [persist, snapshot]);
  const deleteBudget = useCallback(async (id: string) => { await persist({ ...snapshot, budgets: snapshot.budgets.filter((item) => item.id !== id) }); }, [persist, snapshot]);

  const saveAccount = useCallback(async (input: AccountInput, id?: string) => {
    const now = new Date().toISOString(); const openingBalanceBaseMinor = convertToMainMinor(snapshot, input.openingBalanceMinor, input.currency);
    const next = id ? { ...snapshot, accounts: snapshot.accounts.map((item) => item.id === id ? { ...item, ...input, id, openingBalanceBaseMinor, updatedAt: now } : item) } : { ...snapshot, accounts: [{ ...input, id: createId("account"), openingBalanceBaseMinor, createdAt: now, updatedAt: now }, ...snapshot.accounts] };
    await persist(next);
  }, [persist, snapshot]);
  const deleteAccount = useCallback(async (id: string) => {
    if (snapshot.transactions.some((item) => item.accountId === id)) throw new Error("Move or delete account transactions before deleting this account.");
    if (snapshot.accounts.length <= 1) throw new Error("Keep at least one account for your financial data.");
    await persist({ ...snapshot, accounts: snapshot.accounts.filter((item) => item.id !== id) });
  }, [persist, snapshot]);

  const createTransfer = useCallback(async ({ fromAccountId, toAccountId, amountMinor, date, note }: TransferInput) => {
    const from = snapshot.accounts.find((item) => item.id === fromAccountId); const to = snapshot.accounts.find((item) => item.id === toAccountId);
    if (!from || !to || from.id === to.id || amountMinor <= 0) throw new Error("Choose two different accounts and a valid amount.");
    const now = new Date().toISOString(); const transferId = createId("transfer"); const baseAmountMinor = convertToMainMinor(snapshot, amountMinor, from.currency);
    const targetRate = snapshot.currencyRates.find((item) => item.currency === to.currency)?.rateToMain ?? (to.currency === snapshot.settings.currency ? 1 : 1);
    const targetAmountMinor = Math.round(baseAmountMinor / targetRate);
    const out: FinanceTransaction = { id: createId("txn"), type: "transfer_out", amountMinor, baseAmountMinor, currency: from.currency, category: "Transfer", date, description: `Transfer to ${to.name}`, note, accountId: from.id, counterpartAccountId: to.id, transferId, createdAt: now, updatedAt: now };
    const incoming: FinanceTransaction = { id: createId("txn"), type: "transfer_in", amountMinor: targetAmountMinor, baseAmountMinor, currency: to.currency, category: "Transfer", date, description: `Transfer from ${from.name}`, note, accountId: to.id, counterpartAccountId: from.id, transferId, createdAt: now, updatedAt: now };
    await persist({ ...snapshot, transactions: [out, incoming, ...snapshot.transactions] });
  }, [persist, snapshot]);

  const saveRecurringExpense = useCallback(async (input: RecurringExpenseInput, id?: string) => {
    const now = new Date().toISOString();
    const next = id ? { ...snapshot, recurringExpenses: snapshot.recurringExpenses.map((item) => item.id === id ? { ...item, ...input, id, updatedAt: now } : item) } : { ...snapshot, recurringExpenses: [{ ...input, id: createId("recurring"), createdAt: now, updatedAt: now }, ...snapshot.recurringExpenses] };
    const updated = !input.active && id
      ? removeCurrentCycleGeneratedEntries(next, { recurringExpenseId: id }, referenceDate)
      : applyRecurringEntries(next, referenceDate);
    await persist(updated);
  }, [persist, referenceDate, snapshot]);
  const deleteRecurringExpense = useCallback(async (id: string) => { await persist({ ...snapshot, recurringExpenses: snapshot.recurringExpenses.filter((item) => item.id !== id) }); }, [persist, snapshot]);

  const saveCurrencyRate = useCallback(async (input: CurrencyRateInput) => {
    const now = new Date().toISOString(); const existing = snapshot.currencyRates.find((item) => item.currency === input.currency);
    const next = existing ? { ...snapshot, currencyRates: snapshot.currencyRates.map((item) => item.currency === input.currency ? { ...item, ...input, updatedAt: now } : item) } : { ...snapshot, currencyRates: [...snapshot.currencyRates, { ...input, id: createId("rate"), updatedAt: now }] };
    await persist(next);
  }, [persist, snapshot]);
  const deleteCurrencyRate = useCallback(async (currency: string) => { if (currency === snapshot.settings.currency) return; await persist({ ...snapshot, currencyRates: snapshot.currencyRates.filter((item) => item.currency !== currency) }); }, [persist, snapshot]);

  const restoreSnapshot = useCallback(async (payload: BackupPayload, mode: "replace" | "merge") => {
    const imported = migrateFinanceSnapshot(payload.snapshot);
    const next = mode === "replace" ? imported : mergeFinanceSnapshots(snapshot, imported);
    await persist(applyRecurringEntries(next, referenceDate));
  }, [persist, referenceDate, snapshot]);
  const resetData = useCallback(async () => {
    await clearLocalNotifications();
    await clearFinanceSnapshot();
    setPremiumFeedback(null);
    setSnapshot(EMPTY_FINANCE_SNAPSHOT);
  }, []);

  const cycleSummary = useMemo<CycleSummary>(() => {
    const cycle = getSalaryCycle(referenceDate, snapshot.settings.salaryPaymentDay); const transactions = effectiveTransactionsThrough(cycleTransactions(snapshot, cycle), referenceDate);
    const salaryMinor = totalByType(transactions, "income"); const fixedBillsMinor = totalByType(transactions, "fixed_expense"); const variableExpensesMinor = totalByType(transactions, "variable_expense"); const deposits = totalByType(transactions, "savings"); const savingsWithdrawalsMinor = totalByType(transactions, "savings_withdrawal"); const savingsMinor = deposits - savingsWithdrawalsMinor;
    return { cycle, salaryMinor, fixedBillsMinor, variableExpensesMinor, savingsMinor, savingsWithdrawalsMinor, availableMinor: salaryMinor - fixedBillsMinor - variableExpensesMinor - savingsMinor };
  }, [referenceDate, snapshot]);
  const currentCycleTransactions = useMemo(() => cycleTransactions(snapshot, cycleSummary.cycle).sort((first, second) => second.date.localeCompare(first.date)), [cycleSummary.cycle, snapshot]);
  const recentTransactions = useMemo(() => [...snapshot.transactions].sort((first, second) => second.date.localeCompare(first.date)), [snapshot.transactions]);
  const savingsGoals = useMemo(() => savingsGoalSummaries(snapshot), [snapshot]);
  const currentBudgetStatuses = useMemo(() => budgetStatuses(snapshot, referenceDate), [referenceDate, snapshot]);
  const dailySpending = useMemo(() => dailySpendingSummary(snapshot, cycleSummary.availableMinor, referenceDate), [cycleSummary.availableMinor, referenceDate, snapshot]);
  const currentFinancialSummary = useMemo(() => financialSummary(snapshot, referenceDate), [referenceDate, snapshot]);
  const accounts = useMemo(() => accountSummaries(snapshot, referenceDate), [referenceDate, snapshot]);

  const dismissPremiumFeedback = useCallback(() => setPremiumFeedback(null), []);
  const value = useMemo<FinanceContextValue>(() => ({ snapshot, isReady, cycleSummary, currentCycleTransactions, recentTransactions, savingsGoals, budgetStatuses: currentBudgetStatuses, dailySpending, financialSummary: currentFinancialSummary, accounts, premiumFeedback, dismissPremiumFeedback, updateSettings, saveTransaction, deleteTransaction, saveBill, deleteBill, saveSavingsGoal, deleteSavingsGoal, saveQuickExpenseTemplate, deleteQuickExpenseTemplate, saveBudget, deleteBudget, saveAccount, deleteAccount, createTransfer, saveRecurringExpense, deleteRecurringExpense, saveCurrencyRate, deleteCurrencyRate, restoreSnapshot, resetData }), [accounts, createTransfer, currentBudgetStatuses, currentCycleTransactions, currentFinancialSummary, cycleSummary, dailySpending, deleteAccount, deleteBill, deleteBudget, deleteCurrencyRate, deleteQuickExpenseTemplate, deleteRecurringExpense, deleteSavingsGoal, deleteTransaction, dismissPremiumFeedback, isReady, premiumFeedback, recentTransactions, resetData, restoreSnapshot, saveAccount, saveBill, saveBudget, saveCurrencyRate, saveQuickExpenseTemplate, saveRecurringExpense, saveSavingsGoal, saveTransaction, savingsGoals, snapshot, updateSettings]);
  return <FinanceContext.Provider value={value}>{children}</FinanceContext.Provider>;
}

export function useFinance() { const context = useContext(FinanceContext); if (!context) throw new Error("useFinance must be used within FinanceProvider"); return context; }
