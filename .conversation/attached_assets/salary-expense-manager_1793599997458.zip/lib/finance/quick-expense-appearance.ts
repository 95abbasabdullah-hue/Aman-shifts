import type { QuickExpenseColor, QuickExpenseIcon, QuickExpenseTemplate } from "./types";

export const QUICK_EXPENSE_ICONS: { value: QuickExpenseIcon; label: string }[] = [
  { value: "bolt", label: "Quick" },
  { value: "local-cafe", label: "Coffee" },
  { value: "local-gas-station", label: "Fuel" },
  { value: "restaurant", label: "Dining" },
  { value: "shopping-bag", label: "Shopping" },
  { value: "directions-car", label: "Car" },
  { value: "local-grocery-store", label: "Groceries" },
  { value: "medical-services", label: "Health" },
];

export const QUICK_EXPENSE_COLORS: QuickExpenseColor[] = ["#956000", "#198B73", "#2563B8", "#B45309", "#B84E80", "#6D5AB8"];

export const DEFAULT_QUICK_EXPENSE_APPEARANCE = { icon: "bolt" as QuickExpenseIcon, color: "#956000" as QuickExpenseColor };

export function quickExpenseAppearance(template: Pick<QuickExpenseTemplate, "icon" | "color">) {
  return { icon: template.icon ?? DEFAULT_QUICK_EXPENSE_APPEARANCE.icon, color: template.color ?? DEFAULT_QUICK_EXPENSE_APPEARANCE.color };
}
