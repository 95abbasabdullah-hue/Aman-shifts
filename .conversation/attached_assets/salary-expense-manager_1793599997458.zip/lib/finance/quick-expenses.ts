export function quickExpenseTemplateRoute(templateId: string) {
  return `/transaction-form?type=variable_expense&quickTemplateId=${encodeURIComponent(templateId)}`;
}
