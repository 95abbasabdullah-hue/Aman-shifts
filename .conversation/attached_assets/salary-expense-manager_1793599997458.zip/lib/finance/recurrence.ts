import { cycleTransactions, dueOccurrences, getSalaryCycle, isDateWithin, todayIsoDate } from "./cycle";
import { convertToMainMinor, recurringExpenseOccurrences } from "./phase3";
import type { FinanceSnapshot, FinanceTransaction } from "./types";

function createId(prefix: string) {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

function createRecurringTransaction(
  input: Omit<FinanceTransaction, "id" | "createdAt" | "updatedAt">,
): FinanceTransaction {
  const now = new Date().toISOString();
  return { ...input, id: createId("txn"), createdAt: now, updatedAt: now };
}

function currentSalaryKey(cycleId: string) {
  return `salary:${cycleId}`;
}

function automaticSavingsKey(goalId: string, cycleId: string) {
  return `savings:${goalId}:${cycleId}`;
}

/**
 * Ensures the current configured salary is recorded exactly once. It is used at
 * setup and after salary edits, while automatic processing handles subsequent cycles.
 */
export function ensureCurrentSalary(snapshot: FinanceSnapshot, asOf = todayIsoDate()): FinanceSnapshot {
  const { settings } = snapshot;
  if (settings.monthlySalaryMinor <= 0) return snapshot;

  const cycle = getSalaryCycle(asOf, settings.salaryPaymentDay);
  const recurringKey = currentSalaryKey(cycle.id);
  const existing = snapshot.transactions.find((transaction) => transaction.recurringKey === recurringKey);
  const now = new Date().toISOString();

  if (existing) {
    const transactions = snapshot.transactions.map((transaction) =>
      transaction.id === existing.id
        ? {
            ...transaction,
            amountMinor: settings.monthlySalaryMinor,
            currency: settings.currency,
            date: cycle.start,
            description: "Monthly salary",
            category: "Salary",
            updatedAt: now,
          }
        : transaction,
    );
    return { ...snapshot, transactions };
  }

  return {
    ...snapshot,
    transactions: [
      createRecurringTransaction({
        type: "income",
        amountMinor: settings.monthlySalaryMinor,
        currency: settings.currency,
        category: "Salary",
        date: cycle.start,
        description: "Monthly salary",
        recurringKey,
      }),
      ...snapshot.transactions,
    ],
  };
}

/**
 * Adds missing recurring entries for the salary cycle that contains `asOf`. Existing
 * recurrence keys make this operation safe to run repeatedly at launch or after edits.
 */
export function applyRecurringEntries(snapshot: FinanceSnapshot, asOf = todayIsoDate()): FinanceSnapshot {
  const cycle = getSalaryCycle(asOf, snapshot.settings.salaryPaymentDay);
  const existingKeys = new Set(
    snapshot.transactions.map((transaction) => transaction.recurringKey).filter(Boolean),
  );
  const ignoredKeys = new Set(snapshot.ignoredRecurringKeys);
  const additions: FinanceTransaction[] = [];

  if (snapshot.settings.automaticSalaryEnabled && snapshot.settings.monthlySalaryMinor > 0) {
    const recurringKey = currentSalaryKey(cycle.id);
    if (!existingKeys.has(recurringKey) && !ignoredKeys.has(recurringKey)) {
      additions.push(createRecurringTransaction({
        type: "income",
        amountMinor: snapshot.settings.monthlySalaryMinor,
        currency: snapshot.settings.currency,
        category: "Salary",
        date: cycle.start,
        description: "Monthly salary",
        recurringKey,
      }));
      existingKeys.add(recurringKey);
    }
  }

  const salaryReceived = snapshot.settings.automaticSalaryEnabled && snapshot.settings.monthlySalaryMinor > 0
    ? !ignoredKeys.has(currentSalaryKey(cycle.id))
    : cycleTransactions(snapshot, cycle).some((transaction) => transaction.type === "income");

  if (salaryReceived) {
    for (const goal of snapshot.savingsGoals) {
      if (!goal.active || goal.automaticAllocationMinor <= 0) continue;
      const recurringKey = automaticSavingsKey(goal.id, cycle.id);
      if (existingKeys.has(recurringKey) || ignoredKeys.has(recurringKey)) continue;
      additions.push(createRecurringTransaction({
        type: "savings",
        amountMinor: goal.automaticAllocationMinor,
        currency: snapshot.settings.currency,
        category: "Savings",
        date: cycle.start,
        description: `Automatic savings · ${goal.name}`,
        recurringKey,
        savingsGoalId: goal.id,
      }));
      existingKeys.add(recurringKey);
    }
  }

  for (const bill of snapshot.bills) {
    if (!bill.active) continue;
    const occurrences = dueOccurrences(bill.dueDate, bill.frequency, cycle.start, cycle.end);
    for (const occurrenceDate of occurrences) {
      const recurringKey = `bill:${bill.id}:${occurrenceDate}`;
      if (existingKeys.has(recurringKey) || ignoredKeys.has(recurringKey)) continue;
      additions.push(createRecurringTransaction({
        type: "fixed_expense",
        amountMinor: bill.amountMinor,
        currency: bill.currency,
        category: bill.category,
        date: occurrenceDate,
        description: bill.name,
        note: bill.note,
        recurringKey,
        sourceBillId: bill.id,
      }));
      existingKeys.add(recurringKey);
    }
  }

  for (const expense of snapshot.recurringExpenses) {
    if (!expense.active) continue;
    const occurrences = recurringExpenseOccurrences(expense, cycle);
    for (const occurrenceDate of occurrences) {
      const recurringKey = `recurring-expense:${expense.id}:${occurrenceDate}`;
      if (existingKeys.has(recurringKey) || ignoredKeys.has(recurringKey)) continue;
      additions.push(createRecurringTransaction({
        type: "variable_expense",
        amountMinor: expense.amountMinor,
        baseAmountMinor: convertToMainMinor(snapshot, expense.amountMinor, expense.currency),
        currency: expense.currency,
        category: expense.category,
        date: occurrenceDate,
        description: expense.name,
        note: expense.note,
        recurringKey,
        accountId: expense.accountId,
        sourceRecurringExpenseId: expense.id,
      }));
      existingKeys.add(recurringKey);
    }
  }

  return additions.length > 0
    ? { ...snapshot, transactions: [...additions, ...snapshot.transactions] }
    : snapshot;
}

/**
 * Cancels automatically generated entries for one rule in the active salary
 * cycle. It leaves prior cycles untouched, while restoring this cycle's
 * available balance when the rule is switched off.
 */
export function removeCurrentCycleGeneratedEntries(
  snapshot: FinanceSnapshot,
  source: { billId?: string; recurringExpenseId?: string },
  asOf = todayIsoDate(),
): FinanceSnapshot {
  const cycle = getSalaryCycle(asOf, snapshot.settings.salaryPaymentDay);
  const transactions = snapshot.transactions.filter((transaction) => {
    const matchesBill = Boolean(source.billId) && transaction.sourceBillId === source.billId;
    const matchesRecurringExpense = Boolean(source.recurringExpenseId) && transaction.sourceRecurringExpenseId === source.recurringExpenseId;
    return !(isDateWithin(transaction.date, cycle.start, cycle.end) && (matchesBill || matchesRecurringExpense));
  });
  return transactions.length === snapshot.transactions.length ? snapshot : { ...snapshot, transactions };
}

/**
 * Reconciles one bill's generated entries in the active salary cycle after an
 * edit. The old occurrence is removed before the updated rule is applied so
 * changing a due date, frequency, amount, or other bill field cannot leave a
 * stale charge or create a duplicate charge.
 */
export function reconcileCurrentCycleBillEntries(
  snapshot: FinanceSnapshot,
  billId: string,
  asOf = todayIsoDate(),
): FinanceSnapshot {
  return applyRecurringEntries(
    removeCurrentCycleGeneratedEntries(snapshot, { billId }, asOf),
    asOf,
  );
}
