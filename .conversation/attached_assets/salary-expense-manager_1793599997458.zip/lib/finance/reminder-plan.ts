import { addDays, dueOccurrences, getSalaryCycle, todayIsoDate } from "./cycle";
import type { FinanceSnapshot } from "./types";

export type ReminderChannel = "finance-salary" | "finance-bills" | "finance-budgets" | "finance-savings";
export type LocalReminderPlanItem = { id: string; channelId: ReminderChannel; title: string; body: string; date: string; route: "/(tabs)" };

/** Produces local reminder metadata only; it never creates, edits, or deletes financial records. */
export function buildLocalReminderPlan(snapshot: FinanceSnapshot, today = todayIsoDate()): LocalReminderPlanItem[] {
  const preferences = snapshot.settings.notificationPreferences;
  if (!preferences.enabled) return [];
  const plan: LocalReminderPlanItem[] = [];
  const cycle = getSalaryCycle(today, snapshot.settings.salaryPaymentDay);
  const nextSalary = addDays(cycle.end, 1);
  if (preferences.salaryReceived && (preferences.salaryReminderTiming === "day_of" || preferences.salaryReminderTiming === "both") && nextSalary >= today) plan.push({ id: `salary-day:${nextSalary}`, channelId: "finance-salary", title: "Salary day", body: "Open Salary & Expense Manager to safely refresh your new salary cycle.", date: nextSalary, route: "/(tabs)" });
  const salaryEve = addDays(nextSalary, -1);
  if (preferences.salaryCycleReminder && (preferences.salaryReminderTiming === "day_before" || preferences.salaryReminderTiming === "both") && salaryEve >= today) plan.push({ id: `salary-eve:${nextSalary}`, channelId: "finance-salary", title: "Salary expected tomorrow", body: `Your salary cycle begins on ${nextSalary}.`, date: salaryEve, route: "/(tabs)" });
  if (preferences.upcomingBill && preferences.billReminderDays > 0) {
    const horizon = addDays(today, 62);
    for (const bill of snapshot.bills.filter((item) => item.active)) for (const dueDate of dueOccurrences(bill.dueDate, bill.frequency, today, horizon)) {
      const reminderDate = addDays(dueDate, -preferences.billReminderDays);
      if (reminderDate >= today) plan.push({ id: `bill:${bill.id}:${dueDate}`, channelId: "finance-bills", title: "Upcoming bill", body: `${bill.name} is due in ${preferences.billReminderDays} day${preferences.billReminderDays === 1 ? "" : "s"}.`, date: reminderDate, route: "/(tabs)" });
    }
  }
  return plan.sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id));
}
