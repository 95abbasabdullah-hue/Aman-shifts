import { addDays, getSalaryCycle } from "./cycle";
import { formatCycleRange, formatMoney } from "./format";
import { selectedPeriodTransactions } from "./phase3";
import type { FinanceSnapshot, FinanceTransaction } from "./types";

export type ReportPeriod = "current_cycle" | "previous_cycle" | "month" | "year";
export type ReportExportFormat = "csv" | "pdf";

export interface LocalFinanceReport {
  period: ReportPeriod;
  periodLabel: string;
  generatedAt: string;
  currency: string;
  transactions: FinanceTransaction[];
  activeBills: FinanceSnapshot["bills"];
  totals: { incomeMinor: number; fixedExpensesMinor: number; variableExpensesMinor: number; netSavingsMinor: number; transferInMinor: number; transferOutMinor: number; availableSpendingMinor: number; };
}

function amountInMainCurrency(transaction: FinanceTransaction) { return transaction.baseAmountMinor ?? transaction.amountMinor; }

function reportPeriodLabel(snapshot: FinanceSnapshot, period: ReportPeriod, referenceDate: string) {
  if (period === "month") return new Intl.DateTimeFormat(undefined, { month: "long", year: "numeric" }).format(new Date(`${referenceDate.slice(0, 7)}-01T12:00:00`));
  if (period === "year") return referenceDate.slice(0, 4);
  const currentCycle = getSalaryCycle(referenceDate, snapshot.settings.salaryPaymentDay);
  const cycle = period === "current_cycle" ? currentCycle : getSalaryCycle(addDays(currentCycle.start, -1), snapshot.settings.salaryPaymentDay);
  return formatCycleRange(cycle.start, cycle.end);
}

export function buildLocalFinanceReport(snapshot: FinanceSnapshot, period: ReportPeriod, referenceDate: string): LocalFinanceReport {
  const transactions = selectedPeriodTransactions(snapshot, period, referenceDate).slice().sort((first, second) => first.date.localeCompare(second.date) || first.createdAt.localeCompare(second.createdAt));
  const totals = transactions.reduce<LocalFinanceReport["totals"]>((current, transaction) => {
    const amount = amountInMainCurrency(transaction);
    if (transaction.type === "income") current.incomeMinor += amount;
    if (transaction.type === "fixed_expense") current.fixedExpensesMinor += amount;
    if (transaction.type === "variable_expense") current.variableExpensesMinor += amount;
    if (transaction.type === "savings") current.netSavingsMinor += amount;
    if (transaction.type === "savings_withdrawal") current.netSavingsMinor -= amount;
    if (transaction.type === "transfer_in") current.transferInMinor += amount;
    if (transaction.type === "transfer_out") current.transferOutMinor += amount;
    return current;
  }, { incomeMinor: 0, fixedExpensesMinor: 0, variableExpensesMinor: 0, netSavingsMinor: 0, transferInMinor: 0, transferOutMinor: 0, availableSpendingMinor: 0 });
  totals.availableSpendingMinor = totals.incomeMinor - totals.fixedExpensesMinor - totals.variableExpensesMinor - totals.netSavingsMinor;
  return { period, periodLabel: reportPeriodLabel(snapshot, period, referenceDate), generatedAt: new Date().toISOString(), currency: snapshot.settings.currency, transactions, activeBills: snapshot.bills.filter((bill) => bill.active).sort((first, second) => first.dueDate.localeCompare(second.dueDate)), totals };
}

function csvCell(value: string | number | undefined) {
  const text = String(value ?? "");
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function moneyValue(amountMinor: number) { return (amountMinor / 100).toFixed(2); }

export function localReportCsv(report: LocalFinanceReport) {
  const rows: (string | number | undefined)[][] = [
    ["Salary Manager financial report"], ["Period", report.periodLabel], ["Generated", report.generatedAt], ["Main currency", report.currency], [],
    ["Summary", "Amount", "Currency"], ["Income", moneyValue(report.totals.incomeMinor), report.currency], ["Fixed expenses", moneyValue(report.totals.fixedExpensesMinor), report.currency], ["Variable expenses", moneyValue(report.totals.variableExpensesMinor), report.currency], ["Net savings", moneyValue(report.totals.netSavingsMinor), report.currency], ["Available to spend", moneyValue(report.totals.availableSpendingMinor), report.currency], ["Transfers in", moneyValue(report.totals.transferInMinor), report.currency], ["Transfers out", moneyValue(report.totals.transferOutMinor), report.currency], [],
    ["Transactions"], ["Date", "Type", "Description", "Category", "Amount", "Currency", `Amount in ${report.currency}`], ...report.transactions.map((transaction) => [transaction.date, transaction.type, transaction.description, transaction.category, moneyValue(transaction.amountMinor), transaction.currency, moneyValue(amountInMainCurrency(transaction))]), [],
    ["Active bills"], ["Name", "Category", "Amount", "Currency", "Due date", "Frequency", "Notes"], ...report.activeBills.map((bill) => [bill.name, bill.category, moneyValue(bill.amountMinor), bill.currency, bill.dueDate, bill.frequency, bill.note]),
  ];
  return rows.map((row) => row.map(csvCell).join(",")).join("\n");
}

function escapeHtml(value: string | number | undefined) {
  const htmlEscapes: Record<string, string> = { "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", "\"": "&quot;" };
  return String(value ?? "").replace(/[&<>'"]/g, (character) => htmlEscapes[character] ?? character);
}

export function localReportHtml(report: LocalFinanceReport) {
  const summaryRows = [["Income", report.totals.incomeMinor], ["Fixed expenses", report.totals.fixedExpensesMinor], ["Variable expenses", report.totals.variableExpensesMinor], ["Net savings", report.totals.netSavingsMinor], ["Available to spend", report.totals.availableSpendingMinor], ["Transfers in", report.totals.transferInMinor], ["Transfers out", report.totals.transferOutMinor]].map(([label, amount]) => `<tr><td>${escapeHtml(label)}</td><td>${escapeHtml(formatMoney(Number(amount), report.currency))}</td></tr>`).join("");
  const transactionRows = report.transactions.length ? report.transactions.map((transaction) => `<tr><td>${escapeHtml(transaction.date)}</td><td>${escapeHtml(transaction.type.replace(/_/g, " "))}</td><td>${escapeHtml(transaction.description || transaction.category)}</td><td>${escapeHtml(transaction.category)}</td><td>${escapeHtml(formatMoney(transaction.amountMinor, transaction.currency))}</td></tr>`).join("") : "<tr><td colspan=\"5\">No transactions were recorded for this period.</td></tr>";
  const billRows = report.activeBills.length ? report.activeBills.map((bill) => `<tr><td>${escapeHtml(bill.name)}</td><td>${escapeHtml(bill.category)}</td><td>${escapeHtml(formatMoney(bill.amountMinor, bill.currency))}</td><td>${escapeHtml(bill.dueDate)}</td><td>${escapeHtml(bill.frequency)}</td></tr>`).join("") : "<tr><td colspan=\"5\">No active bills.</td></tr>";
  return `<!DOCTYPE html><html><head><meta charset="utf-8" /><style>@page{margin:24px}*{box-sizing:border-box}body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#1b1e1c;font-size:11px;line-height:1.45}h1{font-size:24px;margin:0 0 3px;color:#0c7d64}h2{font-size:14px;margin:24px 0 8px;color:#1b1e1c}.sub{color:#616b65;margin:0}.chip{display:inline-block;margin-top:12px;background:#e8f6ee;color:#0c7d64;border-radius:20px;padding:5px 9px;font-weight:700}table{width:100%;border-collapse:collapse}th{text-align:left;background:#edf4ef;color:#52615a;font-size:9px;letter-spacing:.06em;text-transform:uppercase}th,td{padding:8px;border-bottom:1px solid #dbe4de;vertical-align:top}td:last-child,th:last-child{text-align:right}.footer{margin-top:24px;color:#748078;font-size:9px}</style></head><body><h1>Salary Manager</h1><p class="sub">Financial report · ${escapeHtml(report.periodLabel)}</p><span class="chip">Local-only report</span><h2>Summary (${escapeHtml(report.currency)})</h2><table><tbody>${summaryRows}</tbody></table><h2>Transactions</h2><table><thead><tr><th>Date</th><th>Type</th><th>Description</th><th>Category</th><th>Amount</th></tr></thead><tbody>${transactionRows}</tbody></table><h2>Active bills</h2><table><thead><tr><th>Name</th><th>Category</th><th>Amount</th><th>Due date</th><th>Frequency</th></tr></thead><tbody>${billRows}</tbody></table><p class="footer">Generated locally on ${escapeHtml(report.generatedAt)}. This report was not uploaded or synced.</p></body></html>`;
}
