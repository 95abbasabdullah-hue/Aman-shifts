import AsyncStorage from "@react-native-async-storage/async-storage";
import { DEFAULT_NOTIFICATION_PREFERENCES, DEFAULT_SOUND_PREFERENCES, EMPTY_FINANCE_SNAPSHOT, type BackupPayload, type FinanceSnapshot } from "./types";

const FINANCE_STORAGE_KEY = "salary-expense-manager:finance:v1";
const LEGACY_CASH_ACCOUNT_ID = "account-legacy-cash";

function isSnapshot(value: unknown): value is Partial<FinanceSnapshot> {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<FinanceSnapshot>;
  return Boolean(candidate.settings && Array.isArray(candidate.transactions) && Array.isArray(candidate.bills));
}

/** Adds every later schema field without touching the values held by an earlier snapshot. */
export function migrateFinanceSnapshot(value: unknown): FinanceSnapshot {
  if (!isSnapshot(value)) return EMPTY_FINANCE_SNAPSHOT;
  const source = value as Partial<FinanceSnapshot>;
  const currency = source.settings?.currency ?? EMPTY_FINANCE_SNAPSHOT.settings.currency;
  const legacyAccount = { id: LEGACY_CASH_ACCOUNT_ID, name: "Cash", type: "cash" as const, currency, openingBalanceMinor: 0, openingBalanceBaseMinor: 0, createdAt: "1970-01-01T00:00:00.000Z", updatedAt: "1970-01-01T00:00:00.000Z" };
  const accounts = source.accounts?.length ? source.accounts : [legacyAccount];
  const fallbackAccountId = accounts[0]?.id ?? LEGACY_CASH_ACCOUNT_ID;
  return {
    settings: {
      ...EMPTY_FINANCE_SNAPSHOT.settings,
      ...source.settings,
      budgetWarningThresholdPercent: source.settings?.budgetWarningThresholdPercent ?? 80,
      budgetExceededThresholdPercent: source.settings?.budgetExceededThresholdPercent ?? 100,
      notificationPreferences: { ...DEFAULT_NOTIFICATION_PREFERENCES, ...source.settings?.notificationPreferences },
      soundPreferences: { ...DEFAULT_SOUND_PREFERENCES, ...source.settings?.soundPreferences },
      animationEffectsEnabled: source.settings?.animationEffectsEnabled ?? true,
      exitConfirmationEnabled: source.settings?.exitConfirmationEnabled ?? true,
    },
    transactions: (source.transactions ?? []).map((transaction) => ({
      ...transaction,
      accountId: transaction.accountId ?? fallbackAccountId,
      baseAmountMinor: transaction.baseAmountMinor ?? transaction.amountMinor,
    })),
    bills: source.bills ?? [],
    quickExpenseTemplates: (source.quickExpenseTemplates ?? []).map((template) => ({
      ...template,
      icon: template.icon ?? "bolt",
      color: template.color ?? "#956000",
    })),
    ignoredRecurringKeys: source.ignoredRecurringKeys ?? [],
    savingsGoals: source.savingsGoals ?? [],
    budgets: source.budgets ?? [],
    accounts,
    recurringExpenses: source.recurringExpenses ?? [],
    currencyRates: source.currencyRates ?? [{ id: `rate:${currency}`, currency, rateToMain: 1, updatedAt: new Date(0).toISOString() }],
    processedExperienceKeys: source.processedExperienceKeys ?? [],
  };
}

export function createBackupPayload(snapshot: FinanceSnapshot): BackupPayload {
  return { schemaVersion: 3, exportedAt: new Date().toISOString(), snapshot };
}

export function validateBackupPayload(value: unknown): value is BackupPayload {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<BackupPayload>;
  return candidate.schemaVersion === 3 && Boolean(candidate.snapshot) && isSnapshot(candidate.snapshot);
}

/** Merge favors imported versions by ID while retaining local records absent from the file. */
export function mergeFinanceSnapshots(current: FinanceSnapshot, imported: FinanceSnapshot): FinanceSnapshot {
  const mergeById = <T extends { id: string }>(local: T[], incoming: T[]) => [...local.filter((item) => !incoming.some((other) => other.id === item.id)), ...incoming];
  return {
    ...current,
    settings: { ...current.settings, ...imported.settings },
    transactions: mergeById(current.transactions, imported.transactions),
    bills: mergeById(current.bills, imported.bills),
    quickExpenseTemplates: mergeById(current.quickExpenseTemplates, imported.quickExpenseTemplates),
    savingsGoals: mergeById(current.savingsGoals, imported.savingsGoals),
    budgets: mergeById(current.budgets, imported.budgets),
    accounts: mergeById(current.accounts, imported.accounts),
    recurringExpenses: mergeById(current.recurringExpenses, imported.recurringExpenses),
    currencyRates: mergeById(current.currencyRates, imported.currencyRates),
    ignoredRecurringKeys: [...new Set([...current.ignoredRecurringKeys, ...imported.ignoredRecurringKeys])],
    processedExperienceKeys: [...new Set([...current.processedExperienceKeys, ...imported.processedExperienceKeys])],
  };
}

export async function loadFinanceSnapshot(): Promise<FinanceSnapshot> {
  const raw = await AsyncStorage.getItem(FINANCE_STORAGE_KEY);
  if (!raw) return migrateFinanceSnapshot(EMPTY_FINANCE_SNAPSHOT);
  try { return migrateFinanceSnapshot(JSON.parse(raw) as unknown); } catch { return migrateFinanceSnapshot(EMPTY_FINANCE_SNAPSHOT); }
}

export async function saveFinanceSnapshot(snapshot: FinanceSnapshot) { await AsyncStorage.setItem(FINANCE_STORAGE_KEY, JSON.stringify(snapshot)); }
export async function clearFinanceSnapshot() { await AsyncStorage.removeItem(FINANCE_STORAGE_KEY); }
