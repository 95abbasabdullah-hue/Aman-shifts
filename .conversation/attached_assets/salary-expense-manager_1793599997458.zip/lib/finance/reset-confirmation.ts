import type { ResetConfirmationStep } from "@/components/reset-everything-sheet";

/** Keeps the destructive reset flow deliberately two-step. */
export function nextResetConfirmationStep(step: ResetConfirmationStep): ResetConfirmationStep {
  return step === "review" ? "final" : "final";
}
