import type { SoundPreferences } from "./types";

export const RETAINED_FINANCE_SOUNDS = ["transactionAdded", "salaryReceived", "goalCompleted"] as const;

export type FinanceSound = (typeof RETAINED_FINANCE_SOUNDS)[number];

export function shouldPlayFinanceSound(sound: FinanceSound, preferences: SoundPreferences) {
  if (!preferences.enabled) return false;
  if (sound === "transactionAdded") return preferences.transactionSounds;
  if (sound === "salaryReceived") return preferences.salarySound;
  return preferences.goalCompletionSound;
}
