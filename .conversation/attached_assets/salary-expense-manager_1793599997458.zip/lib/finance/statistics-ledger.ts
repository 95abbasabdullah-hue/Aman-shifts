import type { FinanceTransaction } from "./types";

function amountInMainCurrency(transaction: FinanceTransaction) {
  return transaction.baseAmountMinor ?? transaction.amountMinor;
}

export function ledgerItemBreakdown(transactions: FinanceTransaction[], options?: { excludeIncome?: boolean }) {
  return transactions
    .filter((transaction) => !options?.excludeIncome || transaction.type !== "income")
    .reduce<Record<string, number>>(
    (totals, transaction) => {
      const itemName = transaction.description.trim() || transaction.category;
      return { ...totals, [itemName]: (totals[itemName] ?? 0) + amountInMainCurrency(transaction) };
    },
    {},
  );
}
