export type StatisticsPeriod = "current_cycle" | "previous_cycle" | "month" | "year";

const PERIODS: StatisticsPeriod[] = ["current_cycle", "previous_cycle", "month", "year"];

export function swipeStatisticsCategory(categories: string[], current: string, horizontalDelta: number): string | null {
  if (categories.length < 2 || Math.abs(horizontalDelta) < 40) return null;
  const currentIndex = Math.max(0, categories.indexOf(current));
  const nextIndex = horizontalDelta < 0 ? (currentIndex + 1) % categories.length : (currentIndex - 1 + categories.length) % categories.length;
  return categories[nextIndex];
}

export function statisticsTransactionsHref(type: string, category: string | undefined, period: StatisticsPeriod): string {
  const params = new URLSearchParams({ type, statisticsPeriod: period, statisticsReadOnly: "1" });
  if (category && category !== "All") params.set("category", category);
  return `/transaction-search?${params.toString()}`;
}

export function readStatisticsPeriod(value: string | undefined): StatisticsPeriod | undefined {
  return PERIODS.includes(value as StatisticsPeriod) ? value as StatisticsPeriod : undefined;
}
