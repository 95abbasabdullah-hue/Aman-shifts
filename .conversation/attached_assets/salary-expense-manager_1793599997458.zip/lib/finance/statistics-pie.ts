export type SpendingPieSlice = {
  category: string;
  amountMinor: number;
  percentage: number;
  startPercentage: number;
  chartPercentage: number;
};

export function spendingPieSlices(spending: Record<string, number>, percentageBaseMinor?: number): SpendingPieSlice[] {
  const entries = Object.entries(spending).filter(([, amount]) => amount > 0).sort(([, first], [, second]) => second - first);
  const totalMinor = entries.reduce((total, [, amount]) => total + amount, 0);
  const denominator = percentageBaseMinor ?? totalMinor;
  let startPercentage = 0;
  return entries.map(([category, amountMinor]) => {
    const percentage = denominator > 0 ? (amountMinor / denominator) * 100 : 0;
    const chartPercentage = Math.max(0, Math.min(percentage, 100 - startPercentage));
    const slice = { category, amountMinor, percentage, startPercentage, chartPercentage };
    startPercentage += chartPercentage;
    return slice;
  });
}

export function spendingPieTotal(spending: Record<string, number>): number {
  return Object.values(spending).reduce((total, amount) => total + amount, 0);
}

export function pieSliceAngles(slice: SpendingPieSlice) {
  const start = -90 + (slice.startPercentage / 100) * 360;
  const end = start + (slice.chartPercentage / 100) * 360;
  const middle = start + (end - start) / 2;
  return { start, end, middle };
}
