/** Chooses a safe post-delete destination for both normal and direct-link editor entry. */
export function transactionDeleteExit(canGoBack: boolean): "back" | "transactions" {
  return canGoBack ? "back" : "transactions";
}
