import type { FinanceSnapshot } from "./types";

/** Removes one local ledger row, or both linked rows of an internal transfer, without touching unrelated records. */
export function deleteTransactionFromSnapshot(snapshot: FinanceSnapshot, id: string): FinanceSnapshot {
  const deleted = snapshot.transactions.find((item) => item.id === id);
  if (!deleted) throw new Error("This transaction is no longer available.");
  const transferId = deleted.transferId;
  const ignoredRecurringKeys = deleted.recurringKey ? [...new Set([...snapshot.ignoredRecurringKeys, deleted.recurringKey])] : snapshot.ignoredRecurringKeys;
  return { ...snapshot, ignoredRecurringKeys, transactions: snapshot.transactions.filter((item) => item.id !== id && (!transferId || item.transferId !== transferId)) };
}
