import type { FinanceTransaction } from "./types";

/** Explains the exact local records affected before a long-press deletion is confirmed. */
export function transactionDeletePrompt(transaction: FinanceTransaction): string {
  return transaction.transferId
    ? "This permanently removes both linked sides of this account transfer and recalculates local balances."
    : "This permanently removes this transaction and recalculates local balances.";
}
