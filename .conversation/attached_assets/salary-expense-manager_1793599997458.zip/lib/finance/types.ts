export type TransactionType = "income" | "fixed_expense" | "variable_expense" | "savings" | "savings_withdrawal" | "transfer_out" | "transfer_in";
export type BillFrequency = "monthly" | "yearly";
export type RecurrenceFrequency = "weekly" | "monthly" | "yearly" | "custom";
export type AccountType = "bank" | "cash" | "savings" | "credit_card" | "other";

export type ExpenseCategory =
  | "Food"
  | "Groceries"
  | "Transportation"
  | "Shopping"
  | "Restaurants"
  | "Entertainment"
  | "Healthcare"
  | "Travel"
  | "Education"
  | "Family"
  | "Personal"
  | "Other";

export type QuickExpenseIcon = "bolt" | "local-cafe" | "local-gas-station" | "restaurant" | "shopping-bag" | "directions-car" | "local-grocery-store" | "medical-services";
export type QuickExpenseColor = "#956000" | "#198B73" | "#2563B8" | "#B45309" | "#B84E80" | "#6D5AB8";

export type BillCategory =
  | "Rent"
  | "Electricity"
  | "Water"
  | "Internet"
  | "Phone"
  | "Insurance"
  | "Loan"
  | "Subscription"
  | "Other";

export interface NotificationPreferences {
  enabled: boolean;
  salaryReceived: boolean;
  salaryReminderTiming: "day_of" | "day_before" | "both";
  notificationSound: boolean;
  vibration: boolean;
  billReminderDays: 0 | 1 | 2 | 3 | 7;
  upcomingBill: boolean;
  recurringPayment: boolean;
  budgetWarning: boolean;
  savingsGoal: boolean;
  salaryCycleReminder: boolean;
}

export interface SoundPreferences {
  enabled: boolean;
  hapticsEnabled: boolean;
  buttonSounds: boolean;
  selectionHaptics: boolean;
  transactionSounds: boolean;
  salarySound: boolean;
  goalCompletionSound: boolean;
}

export interface AppSettings {
  monthlySalaryMinor: number;
  currency: string;
  salaryPaymentDay: number;
  automaticSalaryEnabled: boolean;
  onboardingCompleted: boolean;
  themePreference: "system" | "light" | "dark";
  budgetWarningThresholdPercent: number;
  budgetExceededThresholdPercent: number;
  notificationPreferences: NotificationPreferences;
  soundPreferences: SoundPreferences;
  animationEffectsEnabled: boolean;
  /** Retained for compatibility with earlier local backups; Android exit confirmation is now always enabled. */
  exitConfirmationEnabled: boolean;
}

export interface FinanceTransaction {
  id: string;
  type: TransactionType;
  amountMinor: number;
  /** The amount translated to the selected main currency at entry time. */
  baseAmountMinor?: number;
  currency: string;
  category: string;
  date: string;
  description: string;
  note?: string;
  recurringKey?: string;
  sourceBillId?: string;
  sourceRecurringExpenseId?: string;
  savingsGoalId?: string;
  accountId?: string;
  transferId?: string;
  counterpartAccountId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface FinancialAccount {
  id: string;
  name: string;
  type: AccountType;
  currency: string;
  openingBalanceMinor: number;
  openingBalanceBaseMinor: number;
  createdAt: string;
  updatedAt: string;
}

export interface FixedBill {
  id: string;
  name: string;
  amountMinor: number;
  currency: string;
  dueDate: string;
  frequency: BillFrequency;
  category: BillCategory;
  note?: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface RecurringExpense {
  id: string;
  name: string;
  amountMinor: number;
  currency: string;
  category: ExpenseCategory;
  frequency: RecurrenceFrequency;
  customIntervalDays?: number;
  startDate: string;
  accountId?: string;
  note?: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SavingsGoal {
  id: string;
  name: string;
  targetMinor: number;
  monthlyTargetMinor: number;
  automaticAllocationMinor: number;
  active: boolean;
  note?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CategoryBudget {
  id: string;
  category: ExpenseCategory;
  limitMinor: number;
  createdAt: string;
  updatedAt: string;
}

/** A reusable local draft for a common one-off variable expense. */
export interface QuickExpenseTemplate {
  id: string;
  name: string;
  amountMinor: number;
  currency: string;
  category: ExpenseCategory;
  accountId?: string;
  icon: QuickExpenseIcon;
  color: QuickExpenseColor;
  createdAt: string;
  updatedAt: string;
}

export interface ManualCurrencyRate {
  id: string;
  currency: string;
  /** Main-currency minor units per one source-currency minor unit. */
  rateToMain: number;
  updatedAt: string;
}

export interface FinanceSnapshot {
  settings: AppSettings;
  transactions: FinanceTransaction[];
  bills: FixedBill[];
  quickExpenseTemplates: QuickExpenseTemplate[];
  ignoredRecurringKeys: string[];
  savingsGoals: SavingsGoal[];
  budgets: CategoryBudget[];
  accounts: FinancialAccount[];
  recurringExpenses: RecurringExpense[];
  currencyRates: ManualCurrencyRate[];
  /** Stable keys prevent a milestone, celebration, or scheduled reminder from being repeated. */
  processedExperienceKeys: string[];
}

export interface BackupPayload {
  schemaVersion: 3;
  exportedAt: string;
  snapshot: FinanceSnapshot;
}

export interface SalaryCycle { id: string; start: string; end: string; }

export interface CycleSummary {
  cycle: SalaryCycle;
  salaryMinor: number;
  fixedBillsMinor: number;
  variableExpensesMinor: number;
  savingsMinor: number;
  savingsWithdrawalsMinor: number;
  availableMinor: number;
}

export interface SavingsGoalSummary extends SavingsGoal { savedMinor: number; remainingMinor: number; progressPercent: number; }
export interface BudgetStatus { budget: CategoryBudget; spentMinor: number; remainingMinor: number; usedPercent: number; state: "normal" | "warning" | "exceeded"; }
export interface DailySpendingSummary { daysRemaining: number; safeDailySpendingMinor: number; }
export interface FinancialSummary {
  totalIncomeMinor: number;
  totalFixedExpensesMinor: number;
  totalVariableExpensesMinor: number;
  totalSavingsMinor: number;
  availableSpendingMinor: number;
  averageDailySpendingMinor: number;
  highestSpendingCategory: string | null;
  highestSpendingCategoryMinor: number;
}

export interface PremiumFeedbackEvent {
  key: string;
  kind: "salary" | "goal";
  title: string;
  detail: string;
  amountMinor: number;
}

export interface AccountSummary extends FinancialAccount { balanceMinor: number; balanceBaseMinor: number; }

export const EXPENSE_CATEGORIES: ExpenseCategory[] = ["Food", "Groceries", "Transportation", "Shopping", "Restaurants", "Entertainment", "Healthcare", "Travel", "Education", "Family", "Personal", "Other"];
export const BILL_CATEGORIES: BillCategory[] = ["Rent", "Electricity", "Water", "Internet", "Phone", "Insurance", "Loan", "Subscription", "Other"];

export const DEFAULT_NOTIFICATION_PREFERENCES: NotificationPreferences = {
  enabled: false,
  salaryReceived: true,
  salaryReminderTiming: "day_of",
  notificationSound: true,
  vibration: false,
  billReminderDays: 1,
  upcomingBill: true,
  recurringPayment: true,
  budgetWarning: true,
  savingsGoal: true,
  salaryCycleReminder: true,
};

export const DEFAULT_SOUND_PREFERENCES: SoundPreferences = {
  enabled: true,
  hapticsEnabled: true,
  buttonSounds: true,
  selectionHaptics: true,
  transactionSounds: true,
  salarySound: true,
  goalCompletionSound: true,
};

export const DEFAULT_SETTINGS: AppSettings = {
  monthlySalaryMinor: 0,
  currency: "QAR",
  salaryPaymentDay: 1,
  automaticSalaryEnabled: true,
  onboardingCompleted: false,
  themePreference: "system",
  budgetWarningThresholdPercent: 80,
  budgetExceededThresholdPercent: 100,
  notificationPreferences: DEFAULT_NOTIFICATION_PREFERENCES,
  soundPreferences: DEFAULT_SOUND_PREFERENCES,
  animationEffectsEnabled: true,
  exitConfirmationEnabled: true,
};

export const EMPTY_FINANCE_SNAPSHOT: FinanceSnapshot = {
  settings: DEFAULT_SETTINGS,
  transactions: [],
  bills: [],
  quickExpenseTemplates: [],
  ignoredRecurringKeys: [],
  savingsGoals: [],
  budgets: [],
  accounts: [],
  recurringExpenses: [],
  currencyRates: [],
  processedExperienceKeys: [],
};
