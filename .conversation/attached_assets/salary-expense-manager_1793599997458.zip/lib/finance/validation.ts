import type { AppSettings, CategoryBudget, FixedBill, FinanceTransaction, SavingsGoal } from "./types";

export type FieldErrors = Record<string, string>;

function isValidIsoDate(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}

function validateMoney(amountMinor: number, label: string, errors: FieldErrors) {
  if (!Number.isInteger(amountMinor) || amountMinor <= 0) {
    errors.amount = `Enter a valid ${label.toLowerCase()} amount.`;
  }
}

export function validateSalary(settings: Pick<AppSettings, "monthlySalaryMinor" | "currency" | "salaryPaymentDay">) {
  const errors: FieldErrors = {};
  validateMoney(settings.monthlySalaryMinor, "salary", errors);
  if (!/^[A-Z]{3}$/.test(settings.currency.trim().toUpperCase())) {
    errors.currency = "Select a three-letter currency code.";
  }
  if (!Number.isInteger(settings.salaryPaymentDay) || settings.salaryPaymentDay < 1 || settings.salaryPaymentDay > 31) {
    errors.salaryPaymentDay = "Choose a payment day between 1 and 31.";
  }
  return errors;
}

export function validateTransaction(
  transaction: Pick<FinanceTransaction, "amountMinor" | "currency" | "date" | "description">,
  configuredCurrency?: string,
) {
  const errors: FieldErrors = {};
  validateMoney(transaction.amountMinor, "transaction", errors);
  if (!isValidIsoDate(transaction.date)) errors.date = "Choose a valid transaction date.";
  if (configuredCurrency && transaction.currency !== configuredCurrency) {
    errors.currency = `Use ${configuredCurrency}; currency conversion is not available offline.`;
  }
  return errors;
}

export function validateBill(
  bill: Pick<FixedBill, "name" | "amountMinor" | "currency" | "dueDate" | "frequency">,
  configuredCurrency?: string,
) {
  const errors: FieldErrors = {};
  if (!bill.name.trim()) errors.name = "Enter a bill name.";
  validateMoney(bill.amountMinor, "bill", errors);
  if (!isValidIsoDate(bill.dueDate)) errors.dueDate = "Choose a valid due date.";
  if (bill.frequency !== "monthly" && bill.frequency !== "yearly") {
    errors.frequency = "Choose a valid frequency.";
  }
  if (configuredCurrency && bill.currency !== configuredCurrency) {
    errors.currency = `Use ${configuredCurrency}; currency conversion is not available offline.`;
  }
  return errors;
}

export function validateSavingsGoal(
  goal: Pick<SavingsGoal, "name" | "targetMinor" | "monthlyTargetMinor" | "automaticAllocationMinor">,
) {
  const errors: FieldErrors = {};
  if (!goal.name.trim()) errors.name = "Enter a savings goal name.";
  if (!Number.isInteger(goal.targetMinor) || goal.targetMinor <= 0) {
    errors.target = "Enter a target greater than zero.";
  }
  if (!Number.isInteger(goal.monthlyTargetMinor) || goal.monthlyTargetMinor < 0) {
    errors.monthlyTarget = "Enter a valid monthly target.";
  }
  if (!Number.isInteger(goal.automaticAllocationMinor) || goal.automaticAllocationMinor < 0) {
    errors.automaticAllocation = "Enter a valid automatic allocation.";
  }
  return errors;
}

export function validateBudget(budget: Pick<CategoryBudget, "category" | "limitMinor">) {
  const errors: FieldErrors = {};
  if (!budget.category) errors.category = "Choose a category.";
  if (!Number.isInteger(budget.limitMinor) || budget.limitMinor <= 0) {
    errors.limit = "Enter a budget greater than zero.";
  }
  return errors;
}
