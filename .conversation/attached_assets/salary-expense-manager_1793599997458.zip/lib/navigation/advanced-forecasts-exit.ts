export function advancedForecastsExitRoute(hasHistory: boolean) {
  return hasHistory ? "back" : "premium";
}
