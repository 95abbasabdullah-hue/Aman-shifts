export const BOTTOM_TAB_ROUTES = ["/", "/transactions", "/bills", "/savings", "/accounts", "/more"] as const;

export function adjacentBottomTabRoute(currentPath: string, horizontalDelta: number): (typeof BOTTOM_TAB_ROUTES)[number] | null {
  if (Math.abs(horizontalDelta) < 65) return null;
  const currentIndex = BOTTOM_TAB_ROUTES.indexOf(currentPath as (typeof BOTTOM_TAB_ROUTES)[number]);
  if (currentIndex < 0) return null;
  const nextIndex = horizontalDelta < 0 ? currentIndex + 1 : currentIndex - 1;
  return BOTTOM_TAB_ROUTES[nextIndex] ?? null;
}
