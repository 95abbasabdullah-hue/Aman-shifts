export function budgetSettingsExitAction(canGoBack: boolean) {
  return canGoBack ? "back" : "more";
}
