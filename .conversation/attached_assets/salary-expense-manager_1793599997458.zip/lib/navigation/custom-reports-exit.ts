export function customReportsExitRoute(hasHistory: boolean) {
  return hasHistory ? "back" : "premium";
}
