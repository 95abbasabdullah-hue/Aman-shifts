/** Uses normal history after a delete, with a safe fallback for direct-link entry. */
export function deleteReturnAction(canGoBack: boolean): "back" | "fallback" {
  return canGoBack ? "back" : "fallback";
}
