/** Keeps the exit confirmation perceptible but unobtrusive, and honors the app’s motion preference. */
export function exitConfirmationFadeDuration(animationEffectsEnabled: boolean): number {
  return animationEffectsEnabled ? 180 : 0;
}
