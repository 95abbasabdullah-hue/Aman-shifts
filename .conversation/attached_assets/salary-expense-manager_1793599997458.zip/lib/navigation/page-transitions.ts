export type PageTransition = "fade" | "none";

/** Keeps route changes calm, while allowing the saved motion preference and the
 * operating-system reduced-motion setting to disable decorative movement. */
export function pageTransition(enabled: boolean, reducedMotion: boolean): PageTransition {
  return enabled && !reducedMotion ? "fade" : "none";
}
