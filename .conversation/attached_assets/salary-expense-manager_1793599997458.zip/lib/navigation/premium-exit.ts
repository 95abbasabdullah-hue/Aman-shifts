/** Premium is reachable from More and always has a safe destination when opened directly. */
export function premiumExitRoute() {
  return "/more";
}
