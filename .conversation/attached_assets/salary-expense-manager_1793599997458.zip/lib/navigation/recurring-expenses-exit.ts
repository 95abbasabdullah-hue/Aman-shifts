/** Returns to the prior screen when possible, otherwise uses Bills as the safe recurring-expenses fallback. */
export function recurringExpensesExitAction(canGoBack: boolean): "back" | "bills" {
  return canGoBack ? "back" : "bills";
}
