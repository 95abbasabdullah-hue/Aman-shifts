export type RootBackAction = "delegate" | "consume" | "confirm-exit";

/** Only Android Back at a route with no history may request an app-exit confirmation. */
export function resolveRootBackAction(platform: string, exitDialogOpen: boolean, canGoBack = false): RootBackAction {
  if (platform !== "android" || canGoBack) return "delegate";
  return exitDialogOpen ? "consume" : "confirm-exit";
}
