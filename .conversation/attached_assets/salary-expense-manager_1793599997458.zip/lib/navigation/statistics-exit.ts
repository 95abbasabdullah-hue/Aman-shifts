export function statisticsExitHref() {
  return "/(tabs)/more";
}
