export type PremiumFeature = "forecasts" | "reports" | "statistics" | "quick_expenses" | "remove_ads";

export interface PremiumEntitlementInput {
  storeEntitled: boolean;
}

/**
 * Premium is granted only by the active RevenueCat store entitlement.
 * Local finance preferences and backups must never grant billing access.
 */
export function resolvePremiumEntitlement({ storeEntitled }: PremiumEntitlementInput) {
  return storeEntitled;
}

export function premiumFeatureLabel(feature: PremiumFeature) {
  const labels: Record<PremiumFeature, string> = {
    forecasts: "Advanced forecasts",
    reports: "Custom reports & export",
    statistics: "Statistics",
    quick_expenses: "Quick expense templates",
    remove_ads: "Remove ads",
  };
  return labels[feature];
}

export function permittedColorScheme(preference: "system" | "light" | "dark") {
  return preference === "dark" ? "dark" : "light";
}

export type PremiumComparisonAvailability = "included" | "locked" | "preview" | "ad_supported";

export function premiumComparisonRows() {
  return [
    { label: "Salary, bills & budgets", free: "included" as const, premium: "included" as const },
    { label: "Local backup & restore", free: "included" as const, premium: "included" as const },
    { label: "Dark appearance", free: "included" as const, premium: "included" as const },
    { label: "Statistics & insights", free: "locked" as const, premium: "included" as const },
    { label: "Forecasts & exports", free: "preview" as const, premium: "included" as const },
    { label: "Quick expense templates", free: "locked" as const, premium: "included" as const },
    { label: "Ad-free experience", free: "ad_supported" as const, premium: "included" as const },
  ];
}
