import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type PropsWithChildren } from "react";
import { AppState } from "react-native";
import { resolvePremiumEntitlement } from "./access";
import {
  getRevenueCatState,
  isRevenueCatPremium,
  isRevenueCatCancellation,
  revenueCatErrorMessage,
  purchaseRevenueCatPackage,
  restoreRevenueCatPurchases,
  subscribeToRevenueCatCustomerInfo,
  supportsRevenueCatPurchases,
  type RevenueCatOffer,
  type RevenueCatPackageId,
} from "./revenuecat";

type PremiumAccessContextValue = {
  isReady: boolean;
  isPremium: boolean;
  isSupported: boolean;
  offers: RevenueCatOffer[];
  isPurchasing: boolean;
  isRefreshing: boolean;
  error: string | null;
  message: string | null;
  purchase: (packageId: RevenueCatPackageId) => Promise<void>;
  restore: () => Promise<void>;
  refresh: () => Promise<void>;
};

const PremiumAccessContext = createContext<PremiumAccessContextValue | undefined>(undefined);

export function PremiumAccessProvider({ children }: PropsWithChildren) {
  const [isReady, setIsReady] = useState(false);
  const [storeEntitled, setStoreEntitled] = useState(false);
  const [offers, setOffers] = useState<RevenueCatOffer[]>([]);
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  // Refs block rapid double taps before React has committed the busy state.
  const busy = useRef(false);
  const mounted = useRef(true);
  const entitlementRevision = useRef(0);
  const isSupported = supportsRevenueCatPurchases();

  const refresh = useCallback(async () => {
    if (busy.current) return;
    busy.current = true;
    const revision = entitlementRevision.current;
    setIsRefreshing(true);
    setError(null);
    setMessage(null);
    try {
      const state = await getRevenueCatState();
      if (!mounted.current) return;
      // Prefer a newer SDK notification over an in-flight snapshot.
      if (revision === entitlementRevision.current) setStoreEntitled(state.isPremium);
      setOffers(state.offers);
      setError(state.offeringsError);
    } catch (reason) {
      if (!mounted.current) return;
      if (revision === entitlementRevision.current) setStoreEntitled(false);
      setOffers([]);
      setError(revenueCatErrorMessage(reason, "RevenueCat could not be reached."));
    } finally {
      busy.current = false;
      if (mounted.current) {
        setIsReady(true);
        setIsRefreshing(false);
      }
    }
  }, []);

  useEffect(() => {
    mounted.current = true;
    let disposed = false;
    let unsubscribe: (() => void) | undefined;
    void subscribeToRevenueCatCustomerInfo((customerInfo) => {
      if (!disposed) {
        entitlementRevision.current += 1;
        setStoreEntitled(isRevenueCatPremium(customerInfo));
      }
    }).then((removeListener) => {
      if (disposed) removeListener();
      else unsubscribe = removeListener;
    }).catch(() => undefined);

    void refresh();
    const appState = AppState.addEventListener("change", (state) => {
      if (state === "active") void refresh();
    });
    return () => {
      disposed = true;
      mounted.current = false;
      unsubscribe?.();
      appState.remove();
    };
  }, [refresh]);

  const transact = useCallback(async (packageId?: RevenueCatPackageId) => {
    if (busy.current) return;
    busy.current = true;
    setIsPurchasing(true);
    setError(null);
    setMessage(null);
    const revision = entitlementRevision.current;
    try {
      const state = packageId
        ? await purchaseRevenueCatPackage(packageId)
        : await restoreRevenueCatPurchases();
      if (!mounted.current) return;
      if (revision === entitlementRevision.current) setStoreEntitled(state.isPremium);
      setOffers(state.offers);
      setError(state.offeringsError);
      setMessage(state.isPremium
        ? (packageId ? "Premium is now active." : "Premium purchases restored.")
        : (packageId
          ? "The purchase returned without active Premium access. Try restoring purchases or contact support."
          : "No active Premium subscription was found for this Google Play account."));
    } catch (reason) {
      if (!mounted.current) return;
      if (isRevenueCatCancellation(reason)) setMessage("Purchase cancelled. No changes were made.");
      else setError(revenueCatErrorMessage(reason, "The store request could not be completed."));
    } finally {
      busy.current = false;
      if (mounted.current) setIsPurchasing(false);
    }
  }, []);

  const purchase = useCallback((packageId: RevenueCatPackageId) => transact(packageId), [transact]);
  const restore = useCallback(() => transact(), [transact]);
  const value = useMemo(() => ({
    isReady,
    isPremium: resolvePremiumEntitlement({ storeEntitled }),
    isSupported,
    offers,
    isPurchasing,
    isRefreshing,
    error,
    message,
    purchase,
    restore,
    refresh,
  }), [error, isPurchasing, isReady, isRefreshing, isSupported, message, offers, purchase, refresh, restore, storeEntitled]);

  return <PremiumAccessContext.Provider value={value}>{children}</PremiumAccessContext.Provider>;
}

export function usePremiumAccess() {
  const context = useContext(PremiumAccessContext);
  if (!context) throw new Error("usePremiumAccess must be used within PremiumAccessProvider");
  return context;
}
