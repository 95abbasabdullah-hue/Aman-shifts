import { Platform } from "react-native";
import Constants from "expo-constants";
import type { CustomerInfo, PurchasesPackage } from "react-native-purchases";

export const REVENUECAT_ENTITLEMENT_ID = "salary_manager_pro";
export const REVENUECAT_OFFERING_ID = "default";
export const REVENUECAT_MONTHLY_PACKAGE_ID = "$rc_monthly";
export const REVENUECAT_ANNUAL_PACKAGE_ID = "$rc_annual";

// RevenueCat public SDK keys are intended to be embedded in native clients.
// The key is not a secret; RevenueCat protects access through store entitlements.
const REVENUECAT_ANDROID_PUBLIC_API_KEY = "goog_iLTMMJxDNYkcVbiVCmNsvDCAgez";

export type RevenueCatPackageId =
  | typeof REVENUECAT_MONTHLY_PACKAGE_ID
  | typeof REVENUECAT_ANNUAL_PACKAGE_ID;

export type RevenueCatOffer = {
  identifier: RevenueCatPackageId;
  packageIdentifier: string;
  priceString: string;
  title: string;
  description: string;
};

export type RevenueCatState = {
  isConfigured: boolean;
  isPremium: boolean;
  offers: RevenueCatOffer[];
  offeringsError: string | null;
};

type CustomerInfoListener = (customerInfo: CustomerInfo) => void;
type PurchasesModule = typeof import("react-native-purchases").default;

let purchasesModule: PurchasesModule | null = null;
let initialization: Promise<PurchasesModule> | null = null;
let sdkListenerRegistered = false;
const customerInfoListeners = new Set<CustomerInfoListener>();

export function supportsRevenueCatPurchases() {
  return Platform.OS === "android" && Constants.executionEnvironment !== "storeClient";
}

async function getPurchases(): Promise<PurchasesModule | null> {
  // Never use a Google Play key on iOS or Expo Go's preview/mock store.
  if (!supportsRevenueCatPurchases()) return null;

  if (!initialization) {
    initialization = (async () => {
      const module = await import("react-native-purchases");
      module.default.configure({ apiKey: REVENUECAT_ANDROID_PUBLIC_API_KEY });
      purchasesModule = module.default;
      return module.default;
    })().catch((reason) => {
      initialization = null;
      throw reason;
    });
  }
  return initialization;
}

function hasPremiumEntitlement(customerInfo: CustomerInfo) {
  return Boolean(customerInfo.entitlements.active[REVENUECAT_ENTITLEMENT_ID]);
}

function packageIdFor(packageItem: PurchasesPackage): RevenueCatPackageId | null {
  if (packageItem.identifier === REVENUECAT_MONTHLY_PACKAGE_ID) {
    return REVENUECAT_MONTHLY_PACKAGE_ID;
  }
  if (packageItem.identifier === REVENUECAT_ANNUAL_PACKAGE_ID) {
    return REVENUECAT_ANNUAL_PACKAGE_ID;
  }
  return null;
}

function offerFromPackage(packageItem: PurchasesPackage): RevenueCatOffer | null {
  const identifier = packageIdFor(packageItem);
  if (!identifier) return null;

  return {
    identifier,
    packageIdentifier: packageItem.identifier,
    priceString: packageItem.product.priceString,
    title: packageItem.product.title,
    description: packageItem.product.description,
  };
}

async function getCurrentPackages() {
  const purchases = await getPurchases();
  if (!purchases) return { purchases: null, packages: [] as PurchasesPackage[] };

  const offerings = await purchases.getOfferings();
  const offering = offerings.all[REVENUECAT_OFFERING_ID];
  return { purchases, packages: offering?.availablePackages ?? [] };
}

function offersFromPackages(packages: PurchasesPackage[]) {
  return packages
    .map(offerFromPackage)
    .filter((offer): offer is RevenueCatOffer => offer !== null)
    .sort((a, b) => (a.identifier === REVENUECAT_MONTHLY_PACKAGE_ID ? -1 : b.identifier === REVENUECAT_MONTHLY_PACKAGE_ID ? 1 : 0));
}

export async function getRevenueCatState(): Promise<RevenueCatState> {
  const purchases = await getPurchases();
  if (!purchases) return unavailableState();

  // A broken Offering must not prevent an existing subscriber from accessing Premium.
  const [customerInfo, offerState] = await Promise.all([
    purchases.getCustomerInfo(),
    getOfferState(),
  ]);
  return {
    isConfigured: true,
    isPremium: hasPremiumEntitlement(customerInfo),
    ...offerState,
  };
}

function unavailableState(): RevenueCatState {
  return { isConfigured: false, isPremium: false, offers: [], offeringsError: null };
}

async function getOfferState() {
  try {
    const { packages } = await getCurrentPackages();
    const offers = offersFromPackages(packages);
    return {
      offers,
      offeringsError: offers.length ? null : "Subscription plans are unavailable. Please try again later.",
    };
  } catch {
    return { offers: [], offeringsError: "Could not load subscription prices. Check your connection and retry." };
  }
}

export async function purchaseRevenueCatPackage(packageId: RevenueCatPackageId): Promise<RevenueCatState> {
  const { purchases, packages } = await getCurrentPackages();
  if (!purchases) throw new Error("Purchases require the Android app installed from Google Play.");

  const packageItem = packages.find((item) => item.identifier === packageId);
  if (!packageItem) {
    throw new Error(`${packageId} is not available in the current RevenueCat offering.`);
  }

  const result = await purchases.purchasePackage(packageItem);
  return {
    isConfigured: true,
    isPremium: hasPremiumEntitlement(result.customerInfo),
    offers: offersFromPackages(packages),
    offeringsError: null,
  };
}

export async function restoreRevenueCatPurchases(): Promise<RevenueCatState> {
  const purchases = await getPurchases();
  if (!purchases) throw new Error("Restore purchases in the Android app installed from Google Play.");

  const customerInfo = await purchases.restorePurchases();
  const offerState = await getOfferState();
  return {
    isConfigured: true,
    isPremium: hasPremiumEntitlement(customerInfo),
    ...offerState,
  };
}

export async function subscribeToRevenueCatCustomerInfo(listener: CustomerInfoListener) {
  const purchases = await getPurchases();

  if (!purchases) {
    return () => undefined;
  }
  customerInfoListeners.add(listener);

  if (!sdkListenerRegistered) {
    purchases.addCustomerInfoUpdateListener((customerInfo: CustomerInfo) => {
      for (const registeredListener of customerInfoListeners) {
        registeredListener(customerInfo);
      }
    });
    sdkListenerRegistered = true;
  }

  return () => {
    customerInfoListeners.delete(listener);
  };
}

export function isRevenueCatPremium(customerInfo: CustomerInfo) {
  return hasPremiumEntitlement(customerInfo);
}

export function isRevenueCatCancellation(reason: unknown) {
  if (!reason || typeof reason !== "object") return false;
  const error = reason as { userCancelled?: boolean; code?: string | number };
  return error.userCancelled === true ||
    (purchasesModule !== null && String(error.code) === purchasesModule.PURCHASES_ERROR_CODE.PURCHASE_CANCELLED_ERROR);
}

export function revenueCatErrorMessage(reason: unknown, fallback: string) {
  if (!reason || typeof reason !== "object") return fallback;
  const error = reason as { code?: string | number; message?: string };
  if (purchasesModule && String(error.code) === purchasesModule.PURCHASES_ERROR_CODE.PAYMENT_PENDING_ERROR) {
    return "Your payment is pending. Premium will unlock after Google Play confirms it.";
  }
  return typeof error.message === "string" && error.message ? error.message : fallback;
}
