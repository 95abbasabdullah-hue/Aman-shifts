const { withAndroidManifest, AndroidConfig } = require("expo/config-plugins");

// Preserve a checkout that opens a banking/verification app and then returns.
module.exports = function withRevenueCatAndroid(config) {
  return withAndroidManifest(config, (config) => {
    const mainActivity = AndroidConfig.Manifest.getMainActivityOrThrow(config.modResults);
    mainActivity.$["android:launchMode"] = "singleTop";
    return config;
  });
};
