from __future__ import annotations

from array import array
from math import exp, pi, sin
from pathlib import Path
import wave


SAMPLE_RATE = 22_050
OUTPUT = Path(__file__).resolve().parent.parent / "assets" / "sounds"


def write_wave(name: str, duration: float, sampler) -> None:
    frames = array("h")
    for index in range(int(SAMPLE_RATE * duration)):
        time = index / SAMPLE_RATE
        value = max(-1.0, min(1.0, sampler(time)))
        frames.append(int(value * 32_767))
    with wave.open(str(OUTPUT / name), "wb") as target:
        target.setnchannels(1)
        target.setsampwidth(2)
        target.setframerate(SAMPLE_RATE)
        target.writeframes(frames.tobytes())


def bill_confirmation(time: float) -> float:
    envelope = exp(-8.5 * time)
    attack = min(1.0, time / 0.012)
    tone = 0.58 * sin(2 * pi * 440 * time) + 0.28 * sin(2 * pi * 660 * time)
    return 0.38 * attack * envelope * tone


def coin_drop(time: float) -> float:
    impact = 0.20 * exp(-95 * time) * sin(2 * pi * 175 * time)
    ring = (
        0.55 * sin(2 * pi * 1_760 * time)
        + 0.28 * sin(2 * pi * 2_640 * time)
        + 0.16 * sin(2 * pi * 3_510 * time)
    )
    envelope = exp(-10.5 * time) * min(1.0, time / 0.006)
    return impact + 0.26 * envelope * ring


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    write_wave("bill-deducted.wav", 0.38, bill_confirmation)
    write_wave("savings-deposit.wav", 0.52, coin_drop)


if __name__ == "__main__":
    main()
