from pathlib import Path

from PIL import Image


ASSET_DIR = Path("/home/ubuntu/salary-expense-manager/assets/images")
ICON_NAMES = [
    "icon.png",
    "splash-icon.png",
    "favicon.png",
    "android-icon-foreground.png",
]


def optimize_icon(path: Path) -> None:
    with Image.open(path) as image:
        rgb = image.convert("RGB")
        rgb.thumbnail((768, 768), Image.Resampling.LANCZOS)
        optimized = rgb.quantize(colors=256, method=Image.Quantize.MEDIANCUT)
        optimized.save(path, format="PNG", optimize=True, compress_level=9)


for icon_name in ICON_NAMES:
    optimize_icon(ASSET_DIR / icon_name)
