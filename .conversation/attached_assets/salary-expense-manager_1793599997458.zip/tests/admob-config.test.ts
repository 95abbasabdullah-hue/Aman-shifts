import { describe, expect, it } from "vitest";
import {
  ADMOB_ANDROID_APP_ID,
  ADMOB_PRODUCTION_BANNER_UNIT_ID,
  ADMOB_TEST_ADAPTIVE_BANNER_UNIT_ID,
  canShowHomeBanner,
  resolveBannerAdUnitId,
} from "../lib/ads/admob-config";

describe("AdMob banner configuration", () => {
  it("keeps the supplied Android App ID and production placement in one configuration module", () => {
    expect(ADMOB_ANDROID_APP_ID).toBe("ca-app-pub-2707556796843955~3786835750");
    expect(ADMOB_PRODUCTION_BANNER_UNIT_ID).toBe("ca-app-pub-2707556796843955/3459532691");
  });

  it("uses Google's official adaptive banner test unit for development and testing", () => {
    expect(resolveBannerAdUnitId(true)).toBe(ADMOB_TEST_ADAPTIVE_BANNER_UNIT_ID);
    expect(resolveBannerAdUnitId(true)).not.toBe(ADMOB_PRODUCTION_BANNER_UNIT_ID);
    expect(resolveBannerAdUnitId(false)).toBe(ADMOB_PRODUCTION_BANNER_UNIT_ID);
  });

  it("shows the Home banner only to non-Premium Android users after SDK initialization", () => {
    expect(canShowHomeBanner({ isAndroid: true, isPremium: false, isSdkReady: true })).toBe(true);
    expect(canShowHomeBanner({ isAndroid: true, isPremium: true, isSdkReady: true })).toBe(false);
    expect(canShowHomeBanner({ isAndroid: false, isPremium: false, isSdkReady: true })).toBe(false);
    expect(canShowHomeBanner({ isAndroid: true, isPremium: false, isSdkReady: false })).toBe(false);
  });
});
