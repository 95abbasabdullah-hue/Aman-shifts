import { describe, expect, it } from "vitest";
import { applyForecastScenario, buildAdvancedForecast } from "../lib/finance/advanced-forecasts";
import { EMPTY_FINANCE_SNAPSHOT, type FinanceTransaction } from "../lib/finance/types";
import { advancedForecastsExitRoute } from "../lib/navigation/advanced-forecasts-exit";

const ledger = (overrides: Partial<FinanceTransaction>): FinanceTransaction => ({ id: "entry", type: "income", amountMinor: 0, baseAmountMinor: 0, currency: "QAR", category: "Salary", date: "2026-09-01", description: "Entry", createdAt: "2026-09-01T00:00:00.000Z", updatedAt: "2026-09-01T00:00:00.000Z", ...overrides });

describe("Advanced forecasts", () => {
  it("uses the local cycle ledger to project balance, spending room, and upcoming bills and savings", () => {
    const snapshot = { ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 1 }, transactions: [ledger({ id: "income", type: "income", amountMinor: 100_000, date: "2026-09-01" }), ledger({ id: "bill", type: "fixed_expense", amountMinor: 20_000, date: "2026-09-20", description: "Water" }), ledger({ id: "saving", type: "savings", amountMinor: 10_000, date: "2026-09-25", description: "Car fund" }), ledger({ id: "spend", type: "variable_expense", amountMinor: 15_000, date: "2026-09-05" })] };
    expect(buildAdvancedForecast(snapshot, "2026-09-10")).toMatchObject({ projectedEndBalanceMinor: 55_000, plannedBillsMinor: 20_000, plannedSavingsMinor: 10_000, variableSpendingMinor: 15_000, timeline: [{ label: "Water", kind: "bill" }, { label: "Car fund", kind: "savings" }] });
  });

  it("returns through history when available and otherwise falls back to Premium", () => {
    expect(advancedForecastsExitRoute(true)).toBe("back");
    expect(advancedForecastsExitRoute(false)).toBe("premium");
  });

  it("adjusts only the temporary projection for extra income and a planned expense", () => {
    const base = buildAdvancedForecast({ ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 1 }, transactions: [ledger({ amountMinor: 100_000 })] }, "2026-09-10");
    expect(applyForecastScenario(base, { extraIncomeMinor: 20_000, plannedExpenseMinor: 5_000 })).toMatchObject({ projectedEndBalanceMinor: base.projectedEndBalanceMinor + 15_000, extraIncomeMinor: 20_000, plannedExpenseMinor: 5_000 });
  });
});
