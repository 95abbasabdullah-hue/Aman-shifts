import { describe, expect, it } from "vitest";
import { buildAvailableToSpendAdjustment } from "../lib/finance/available-to-spend-adjustment";

describe("available-to-spend dashboard adjustments", () => {
  it("creates a labeled income adjustment when the requested target is higher", () => {
    expect(buildAvailableToSpendAdjustment({ currentAvailableMinor: 5000, targetAvailableMinor: 9000, currency: "QAR", date: "2026-08-27", accountId: "cash" })).toMatchObject({ type: "income", amountMinor: 4000, category: "Other", description: "Available to spend adjustment", accountId: "cash" });
  });

  it("creates a labeled expense adjustment when the requested target is lower", () => {
    expect(buildAvailableToSpendAdjustment({ currentAvailableMinor: 9000, targetAvailableMinor: 2500, currency: "QAR", date: "2026-08-27" })).toMatchObject({ type: "variable_expense", amountMinor: 6500, category: "Other" });
  });

  it("does not add a ledger record for an unchanged target and rejects a negative target", () => {
    expect(buildAvailableToSpendAdjustment({ currentAvailableMinor: 5000, targetAvailableMinor: 5000, currency: "QAR", date: "2026-08-27" })).toBeNull();
    expect(() => buildAvailableToSpendAdjustment({ currentAvailableMinor: 5000, targetAvailableMinor: -1, currency: "QAR", date: "2026-08-27" })).toThrow("valid available-to-spend");
  });
});
