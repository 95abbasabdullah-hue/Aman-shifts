import { describe, expect, it } from "vitest";
import { deleteReturnAction } from "../lib/navigation/delete-return";

describe("bill deletion return behavior", () => {
  it("returns through normal navigation after a persisted bill deletion", () => {
    expect(deleteReturnAction(true)).toBe("back");
  });

  it("uses a safe list fallback when a bill editor was opened directly", () => {
    expect(deleteReturnAction(false)).toBe("fallback");
  });
});
