import { describe, expect, it } from "vitest";
import { adjacentBottomTabRoute } from "../lib/navigation/bottom-tab-swipe";

describe("bottom-tab swipe navigation", () => {
  it("moves to the next tab on a deliberate left swipe and previous tab on a deliberate right swipe", () => {
    expect(adjacentBottomTabRoute("/", -70)).toBe("/transactions");
    expect(adjacentBottomTabRoute("/bills", 70)).toBe("/transactions");
  });

  it("does not wrap outside the first or last tab and ignores small drags", () => {
    expect(adjacentBottomTabRoute("/", 70)).toBeNull();
    expect(adjacentBottomTabRoute("/more", -70)).toBeNull();
    expect(adjacentBottomTabRoute("/bills", 20)).toBeNull();
  });
});
