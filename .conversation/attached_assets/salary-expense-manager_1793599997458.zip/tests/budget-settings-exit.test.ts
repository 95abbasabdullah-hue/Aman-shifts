import { describe, expect, it } from "vitest";
import { budgetSettingsExitAction } from "../lib/navigation/budget-settings-exit";

describe("Budget Management exit", () => {
  it("uses normal history when available and returns to More for a direct-open screen", () => {
    expect(budgetSettingsExitAction(true)).toBe("back");
    expect(budgetSettingsExitAction(false)).toBe("more");
  });
});
