import { describe, expect, it } from "vitest";
import { calendarMonthCells, parseCalendarDate, shiftCalendarMonth, toCalendarIsoDate } from "../lib/finance/calendar";

describe("shared calendar control", () => {
  it("preserves an ISO calendar day without UTC drift", () => {
    const date = parseCalendarDate("2024-02-29");
    expect(toCalendarIsoDate(date)).toBe("2024-02-29");
  });

  it("builds a complete leap-year month grid with selectable dates", () => {
    const cells = calendarMonthCells(new Date(2024, 1, 1, 12));
    expect(cells).toHaveLength(35);
    expect(cells.find((cell) => cell?.isoDate === "2024-02-29")).toEqual({ day: 29, isoDate: "2024-02-29" });
  });

  it("moves the visible calendar between year boundaries", () => {
    expect(toCalendarIsoDate(shiftCalendarMonth(new Date(2026, 0, 1, 12), -1))).toBe("2025-12-01");
    expect(toCalendarIsoDate(shiftCalendarMonth(new Date(2026, 11, 1, 12), 1))).toBe("2027-01-01");
  });
});
