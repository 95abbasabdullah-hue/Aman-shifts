import { describe, expect, it } from "vitest";
import { accountSummaries } from "../lib/finance/phase3";
import { EMPTY_FINANCE_SNAPSHOT, type FinanceSnapshot, type FinanceTransaction } from "../lib/finance/types";

function transaction(overrides: Partial<FinanceTransaction>): FinanceTransaction {
  return {
    id: "transaction", type: "variable_expense", amountMinor: 1, baseAmountMinor: 1, currency: "QAR", category: "Other", date: "2026-09-01", description: "Test", accountId: "cash", createdAt: "2026-09-01T00:00:00.000Z", updatedAt: "2026-09-01T00:00:00.000Z", ...overrides,
  };
}

describe("effective-date account balances", () => {
  it("excludes future dated expenses until their stated due date arrives", () => {
    const snapshot: FinanceSnapshot = {
      ...EMPTY_FINANCE_SNAPSHOT,
      accounts: [{ id: "cash", name: "Cash", type: "cash", currency: "QAR", openingBalanceMinor: 1_000_000, openingBalanceBaseMinor: 1_000_000, createdAt: "2026-08-01T00:00:00.000Z", updatedAt: "2026-08-01T00:00:00.000Z" }],
      transactions: [
        transaction({ id: "due-now", amountMinor: 100_000, baseAmountMinor: 100_000, date: "2026-09-01" }),
        transaction({ id: "future", amountMinor: 200_000, baseAmountMinor: 200_000, date: "2026-09-10" }),
      ],
    };

    expect(accountSummaries(snapshot, "2026-09-01")[0]?.balanceMinor).toBe(900_000);
    expect(accountSummaries(snapshot, "2026-09-10")[0]?.balanceMinor).toBe(700_000);
  });
});
