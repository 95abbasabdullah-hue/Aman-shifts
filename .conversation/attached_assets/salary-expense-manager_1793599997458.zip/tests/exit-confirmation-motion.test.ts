import { describe, expect, it } from "vitest";
import { exitConfirmationFadeDuration } from "../lib/navigation/exit-confirmation-motion";

describe("exit confirmation motion", () => {
  it("uses a subtle fade duration when interface effects are enabled", () => {
    expect(exitConfirmationFadeDuration(true)).toBe(180);
  });

  it("does not animate the dialog when interface effects are disabled", () => {
    expect(exitConfirmationFadeDuration(false)).toBe(0);
  });
});
