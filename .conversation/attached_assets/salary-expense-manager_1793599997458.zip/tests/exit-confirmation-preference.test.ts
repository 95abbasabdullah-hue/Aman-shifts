import { describe, expect, it } from "vitest";
import { migrateFinanceSnapshot } from "../lib/finance/repository";
import { EMPTY_FINANCE_SNAPSHOT } from "../lib/finance/types";

describe("legacy exit confirmation preference compatibility", () => {
  it("keeps confirmation enabled by default for new and legacy local snapshots", () => {
    expect(EMPTY_FINANCE_SNAPSHOT.settings.exitConfirmationEnabled).toBe(true);
    expect(migrateFinanceSnapshot({ ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, exitConfirmationEnabled: undefined } }).settings.exitConfirmationEnabled).toBe(true);
  });

  it("preserves the historical field for backup compatibility; runtime exit guards no longer use it", () => {
    expect(migrateFinanceSnapshot({ ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, exitConfirmationEnabled: false } }).settings.exitConfirmationEnabled).toBe(false);
  });
});
