import { describe, expect, it } from "vitest";
import { getSalaryCycle } from "../lib/finance/cycle";
import { financialSummary } from "../lib/finance/insights";
import { applyRecurringEntries } from "../lib/finance/recurrence";
import { createBackupPayload, mergeFinanceSnapshots, migrateFinanceSnapshot, validateBackupPayload } from "../lib/finance/repository";
import { EMPTY_FINANCE_SNAPSHOT, type FinanceTransaction } from "../lib/finance/types";
import { validateTransaction } from "../lib/finance/validation";

const time = "2026-01-01T00:00:00.000Z";
const ledger = (overrides: Partial<FinanceTransaction>): FinanceTransaction => ({ id: "row", type: "variable_expense", amountMinor: 1, baseAmountMinor: 1, currency: "QAR", category: "Other", date: "2026-09-05", description: "Test", accountId: "cash", createdAt: time, updatedAt: time, ...overrides });

describe("final financial calculation audit", () => {
  it("reconciles the documented salary, bills, savings, and variable-expense example", () => {
    const snapshot = { ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 27 }, transactions: [
      ledger({ id: "salary", type: "income", amountMinor: 1_000_000, baseAmountMinor: 1_000_000, category: "Salary", date: "2026-08-27" }),
      ledger({ id: "fixed", type: "fixed_expense", amountMinor: 300_000, baseAmountMinor: 300_000, category: "Rent", date: "2026-09-01" }),
      ledger({ id: "savings", type: "savings", amountMinor: 150_000, baseAmountMinor: 150_000, category: "Savings", date: "2026-09-02" }),
      ledger({ id: "expense", type: "variable_expense", amountMinor: 100_000, baseAmountMinor: 100_000, category: "Food", date: "2026-09-03" }),
      ledger({ id: "out", type: "transfer_out", amountMinor: 50_000, baseAmountMinor: 50_000, category: "Transfer", date: "2026-09-04", transferId: "move" }),
      ledger({ id: "in", type: "transfer_in", amountMinor: 50_000, baseAmountMinor: 50_000, category: "Transfer", date: "2026-09-04", transferId: "move" }),
    ] };
    expect(financialSummary(snapshot, "2026-09-10")).toMatchObject({ totalIncomeMinor: 1_000_000, totalFixedExpensesMinor: 300_000, totalSavingsMinor: 150_000, totalVariableExpensesMinor: 100_000, availableSpendingMinor: 450_000 });
  });

  it("continues to recalculate safely after transaction edit, deletion, zero balance, and very large values", () => {
    const base = { ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 1 }, transactions: [ledger({ id: "income", type: "income", amountMinor: 9_000_000_000_000, baseAmountMinor: 9_000_000_000_000, date: "2026-09-01" }), ledger({ id: "expense", amountMinor: 9_000_000_000_000, baseAmountMinor: 9_000_000_000_000, date: "2026-09-02" })] };
    expect(financialSummary(base, "2026-09-03").availableSpendingMinor).toBe(0);
    const deleted = { ...base, transactions: base.transactions.filter((item) => item.id !== "expense") };
    expect(financialSummary(deleted, "2026-09-03").availableSpendingMinor).toBe(9_000_000_000_000);
  });
});

describe("final salary cycle and recurrence audit", () => {
  it("clamps salary cycles consistently for 28/29 February and 30/31-day boundaries", () => {
    expect(getSalaryCycle("2023-02-28", 1)).toMatchObject({ start: "2023-02-01", end: "2023-02-28" });
    expect(getSalaryCycle("2024-02-29", 28)).toMatchObject({ start: "2024-02-28", end: "2024-03-27" });
    expect(getSalaryCycle("2023-03-01", 29)).toMatchObject({ start: "2023-02-28", end: "2023-03-28" });
    expect(getSalaryCycle("2024-03-01", 30)).toMatchObject({ start: "2024-02-29", end: "2024-03-29" });
    expect(getSalaryCycle("2024-03-01", 31)).toMatchObject({ start: "2024-02-29", end: "2024-03-30" });
    expect(getSalaryCycle("2026-09-15", 15)).toMatchObject({ start: "2026-09-15", end: "2026-10-14" });
    expect(getSalaryCycle("2026-09-15", 27)).toMatchObject({ start: "2026-08-27", end: "2026-09-26" });
  });

  it("does not duplicate salary, bills, or recurring expenses when the app rehydrates", () => {
    const snapshot = { ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, monthlySalaryMinor: 500_000, salaryPaymentDay: 1, automaticSalaryEnabled: true }, accounts: [{ id: "cash", name: "Cash", type: "cash" as const, currency: "QAR", openingBalanceMinor: 0, openingBalanceBaseMinor: 0, createdAt: time, updatedAt: time }], bills: [{ id: "internet", name: "Internet", amountMinor: 20_000, currency: "QAR", dueDate: "2026-09-02", frequency: "monthly" as const, category: "Internet" as const, active: true, createdAt: time, updatedAt: time }], recurringExpenses: [{ id: "gym", name: "Gym", amountMinor: 10_000, currency: "QAR", category: "Healthcare" as const, frequency: "monthly" as const, startDate: "2026-09-03", accountId: "cash", active: true, createdAt: time, updatedAt: time }] };
    const once = applyRecurringEntries(snapshot, "2026-09-10"); const twice = applyRecurringEntries(once, "2026-09-10");
    expect(twice.transactions.filter((item) => item.type === "income")).toHaveLength(1);
    expect(twice.transactions.filter((item) => item.sourceBillId === "internet")).toHaveLength(1);
    expect(twice.transactions.filter((item) => item.sourceRecurringExpenseId === "gym")).toHaveLength(1);
  });
});

describe("final local integrity and error audit", () => {
  it("preserves stored records through migration and merges only after a valid backup payload", () => {
    const original = { ...EMPTY_FINANCE_SNAPSHOT, transactions: [ledger({ id: "keep", amountMinor: 123 })] };
    const migrated = migrateFinanceSnapshot(original);
    const backup = createBackupPayload(migrated);
    expect(validateBackupPayload(backup)).toBe(true);
    expect(migrateFinanceSnapshot(original).transactions.find((item) => item.id === "keep")?.amountMinor).toBe(123);
    expect(mergeFinanceSnapshots(migrated, backup.snapshot).transactions.find((item) => item.id === "keep")?.amountMinor).toBe(123);
    expect(validateBackupPayload({ schemaVersion: 3, exportedAt: "", snapshot: { settings: {} } })).toBe(false);
  });

  it("rejects zero, negative, and invalid-date transaction input without mutating stored data", () => {
    expect(validateTransaction({ amountMinor: 0, currency: "QAR", date: "2026-09-01", description: "Zero" }, "QAR")).toHaveProperty("amount");
    expect(validateTransaction({ amountMinor: -1, currency: "QAR", date: "invalid", description: "Bad" }, "QAR")).toMatchObject({ amount: expect.any(String), date: expect.any(String) });
  });
});
