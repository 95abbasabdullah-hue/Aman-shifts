import { describe, expect, it } from "vitest";
import { cycleTransactions, getSalaryCycle, totalByType } from "../lib/finance/cycle";
import { EMPTY_FINANCE_SNAPSHOT, type FinanceTransaction } from "../lib/finance/types";
import { validateBill, validateSalary, validateTransaction } from "../lib/finance/validation";

const sampleTransactions: FinanceTransaction[] = [
  {
    id: "income-1", type: "income", amountMinor: 1_000_000, currency: "QAR", category: "Salary", date: "2026-08-27", description: "Monthly salary", createdAt: "2026-08-27T00:00:00.000Z", updatedAt: "2026-08-27T00:00:00.000Z",
  },
  {
    id: "bill-1", type: "fixed_expense", amountMinor: 350_000, currency: "QAR", category: "Rent", date: "2026-09-01", description: "Rent", createdAt: "2026-09-01T00:00:00.000Z", updatedAt: "2026-09-01T00:00:00.000Z",
  },
  {
    id: "expense-1", type: "variable_expense", amountMinor: 120_000, currency: "QAR", category: "Groceries", date: "2026-09-05", description: "Groceries", createdAt: "2026-09-05T00:00:00.000Z", updatedAt: "2026-09-05T00:00:00.000Z",
  },
  {
    id: "later", type: "variable_expense", amountMinor: 99_999, currency: "QAR", category: "Other", date: "2026-09-27", description: "Next cycle", createdAt: "2026-09-27T00:00:00.000Z", updatedAt: "2026-09-27T00:00:00.000Z",
  },
];

describe("available balance calculation", () => {
  it("includes only the current salary cycle and yields the requested accounting result", () => {
    const cycle = getSalaryCycle("2026-09-15", 27);
    const transactions = cycleTransactions({ ...EMPTY_FINANCE_SNAPSHOT, transactions: sampleTransactions }, cycle);
    const salary = totalByType(transactions, "income");
    const bills = totalByType(transactions, "fixed_expense");
    const expenses = totalByType(transactions, "variable_expense");

    expect(salary).toBe(1_000_000);
    expect(bills).toBe(350_000);
    expect(expenses).toBe(120_000);
    expect(salary - bills - expenses).toBe(530_000);
  });
});

describe("offline input validation", () => {
  it("rejects missing or invalid salary configuration", () => {
    expect(validateSalary({ monthlySalaryMinor: 0, currency: "qa", salaryPaymentDay: 32 })).toMatchObject({
      amount: expect.any(String),
      currency: expect.any(String),
      salaryPaymentDay: expect.any(String),
    });
  });

  it("rejects an invalid expense while preserving a clear error field", () => {
    expect(validateTransaction({ amountMinor: Number.NaN, currency: "QAR", date: "not-a-date", description: "" }, "QAR")).toMatchObject({
      amount: expect.any(String),
      date: expect.any(String),
    });
  });

  it("rejects an incorrectly configured recurring bill", () => {
    expect(validateBill({ name: "", amountMinor: -1, currency: "USD", dueDate: "2026-99-99", frequency: "weekly" as "monthly" }, "QAR")).toMatchObject({
      name: expect.any(String),
      amount: expect.any(String),
      dueDate: expect.any(String),
      frequency: expect.any(String),
      currency: expect.any(String),
    });
  });
});
