import { describe, expect, it } from "vitest";
import { dueOccurrences, getSalaryCycle } from "../lib/finance/cycle";
import { applyRecurringEntries, ensureCurrentSalary } from "../lib/finance/recurrence";
import { EMPTY_FINANCE_SNAPSHOT, type FixedBill } from "../lib/finance/types";

describe("salary cycle calculations", () => {
  it("uses the prior payment day before the current month's payday", () => {
    expect(getSalaryCycle("2026-09-26", 27)).toEqual({
      id: "cycle:2026-08-27",
      start: "2026-08-27",
      end: "2026-09-26",
    });
  });

  it("safely clamps the 31st to February's final day", () => {
    expect(getSalaryCycle("2024-02-29", 31)).toEqual({
      id: "cycle:2024-02-29",
      start: "2024-02-29",
      end: "2024-03-30",
    });
    expect(getSalaryCycle("2025-02-28", 31)).toEqual({
      id: "cycle:2025-02-28",
      start: "2025-02-28",
      end: "2025-03-30",
    });
  });

  it("finds only monthly occurrences inside a salary cycle", () => {
    expect(dueOccurrences("2026-01-01", "monthly", "2026-08-27", "2026-09-26")).toEqual([
      "2026-09-01",
    ]);
  });
});

describe("recurring transaction safeguards", () => {
  const rent: FixedBill = {
    id: "bill-rent",
    name: "Rent",
    amountMinor: 350000,
    currency: "QAR",
    dueDate: "2026-01-01",
    frequency: "monthly",
    category: "Rent",
    active: true,
    createdAt: "2026-01-01T00:00:00.000Z",
    updatedAt: "2026-01-01T00:00:00.000Z",
  };

  it("does not duplicate automatic salary or recurring bills", () => {
    const configured = {
      ...EMPTY_FINANCE_SNAPSHOT,
      settings: {
        ...EMPTY_FINANCE_SNAPSHOT.settings,
        monthlySalaryMinor: 1000000,
        salaryPaymentDay: 27,
        automaticSalaryEnabled: true,
      },
      bills: [rent],
    };
    const once = applyRecurringEntries(configured, "2026-09-01");
    const twice = applyRecurringEntries(once, "2026-09-01");

    expect(once.transactions).toHaveLength(2);
    expect(twice.transactions).toHaveLength(2);
  });

  it("creates a current salary only once after setup", () => {
    const configured = {
      ...EMPTY_FINANCE_SNAPSHOT,
      settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, monthlySalaryMinor: 1000000, salaryPaymentDay: 27 },
    };
    expect(ensureCurrentSalary(ensureCurrentSalary(configured, "2026-09-01"), "2026-09-01").transactions)
      .toHaveLength(1);
  });
});
