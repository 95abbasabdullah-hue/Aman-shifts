import { describe, expect, it } from "vitest";
import { homeFixedBillInput, isHomeFixedBillFlow } from "../lib/finance/home-fixed-bill";

describe("Home fixed-bill creation", () => {
  it("shows the Active choice only for a new fixed bill selected from the Home expense flow", () => {
    expect(isHomeFixedBillFlow("home", "fixed_expense")).toBe(true);
    expect(isHomeFixedBillFlow("home", "variable_expense")).toBe(false);
    expect(isHomeFixedBillFlow(undefined, "fixed_expense")).toBe(false);
  });

  it("preserves the user-selected Active value when preparing a local monthly fixed bill", () => {
    expect(homeFixedBillInput({ name: "Rent", amountMinor: 450000, currency: "QAR", category: "Rent", dueDate: "2026-09-01", active: false })).toMatchObject({ name: "Rent", active: false, frequency: "monthly", category: "Rent" });
  });
});
