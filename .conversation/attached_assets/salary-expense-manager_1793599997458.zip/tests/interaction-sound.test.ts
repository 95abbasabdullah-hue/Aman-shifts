import { describe, expect, it } from "vitest";
import { RETAINED_FINANCE_SOUNDS } from "../lib/finance/sound-policy";

describe("interaction sound removal", () => {
  it("does not retain click, typing, or selection sound events", () => {
    expect(RETAINED_FINANCE_SOUNDS).not.toContain("button");
    expect(RETAINED_FINANCE_SOUNDS).not.toContain("typing");
    expect(RETAINED_FINANCE_SOUNDS).not.toContain("selection");
  });
});
