import { describe, expect, it } from "vitest";
import { RETAINED_FINANCE_SOUNDS, shouldPlayFinanceSound } from "../lib/finance/sound-policy";
import { DEFAULT_SOUND_PREFERENCES } from "../lib/finance/types";

describe("retained finance sound policy", () => {
  it("retains only transaction, salary, and goal-completion feedback", () => {
    expect(RETAINED_FINANCE_SOUNDS).toEqual(["transactionAdded", "salaryReceived", "goalCompleted"]);
  });

  it("continues to respect the independent saved preferences for each retained sound", () => {
    expect(shouldPlayFinanceSound("transactionAdded", DEFAULT_SOUND_PREFERENCES)).toBe(true);
    expect(shouldPlayFinanceSound("salaryReceived", { ...DEFAULT_SOUND_PREFERENCES, salarySound: false })).toBe(false);
    expect(shouldPlayFinanceSound("goalCompleted", { ...DEFAULT_SOUND_PREFERENCES, enabled: false })).toBe(false);
  });
});
