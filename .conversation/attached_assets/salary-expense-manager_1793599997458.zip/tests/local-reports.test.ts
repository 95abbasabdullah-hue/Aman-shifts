import { describe, expect, it } from "vitest";
import { buildLocalFinanceReport, localReportCsv, localReportHtml } from "../lib/finance/report-content";
import { customReportsExitRoute } from "../lib/navigation/custom-reports-exit";
import { EMPTY_FINANCE_SNAPSHOT, type FinanceTransaction } from "../lib/finance/types";

const entry = (overrides: Partial<FinanceTransaction>): FinanceTransaction => ({ id: "entry", type: "income", amountMinor: 0, baseAmountMinor: 0, currency: "QAR", category: "Salary", date: "2026-09-01", description: "Entry", createdAt: "2026-09-01T00:00:00.000Z", updatedAt: "2026-09-01T00:00:00.000Z", ...overrides });

describe("local financial reports", () => {
  it("builds a period report where transfers do not change available-to-spend", () => {
    const snapshot = { ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 1 }, transactions: [entry({ id: "income", amountMinor: 100_000, baseAmountMinor: 100_000 }), entry({ id: "expense", type: "variable_expense", amountMinor: 25_000, baseAmountMinor: 25_000, description: "Food" }), entry({ id: "saving", type: "savings", amountMinor: 10_000, baseAmountMinor: 10_000, description: "Goal" }), entry({ id: "transfer", type: "transfer_in", amountMinor: 50_000, baseAmountMinor: 50_000, description: "Wallet" })] };
    expect(buildLocalFinanceReport(snapshot, "month", "2026-09-10").totals).toMatchObject({ incomeMinor: 100_000, variableExpensesMinor: 25_000, netSavingsMinor: 10_000, transferInMinor: 50_000, availableSpendingMinor: 65_000 });
  });

  it("creates escaped CSV and PDF markup from local ledger content", () => {
    const snapshot = { ...EMPTY_FINANCE_SNAPSHOT, transactions: [entry({ description: '"Private, item"', amountMinor: 1_234 })] };
    const report = buildLocalFinanceReport(snapshot, "month", "2026-09-10");
    expect(localReportCsv(report)).toContain('"""Private, item"""');
    expect(localReportHtml(report)).toContain("Salary Manager");
    expect(localReportHtml(report)).toContain("&quot;Private, item&quot;");
  });

  it("uses Premium as the direct-link-safe close destination", () => {
    expect(customReportsExitRoute(true)).toBe("back");
    expect(customReportsExitRoute(false)).toBe("premium");
  });
});
