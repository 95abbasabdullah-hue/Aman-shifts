import { describe, expect, it } from "vitest";
import { pageTransition } from "../lib/navigation/page-transitions";

describe("page transitions", () => {
  it("uses a subtle fade only when local animation and system motion settings allow it", () => {
    expect(pageTransition(true, false)).toBe("fade");
    expect(pageTransition(false, false)).toBe("none");
    expect(pageTransition(true, true)).toBe("none");
  });
});
