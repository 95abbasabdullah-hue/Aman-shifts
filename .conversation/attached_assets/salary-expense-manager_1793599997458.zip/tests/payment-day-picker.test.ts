import { describe, expect, it } from "vitest";
import { normalizeSalaryPaymentDay, SALARY_PAYMENT_DAYS } from "../lib/finance/payment-day-picker";

describe("salary payment-day calendar", () => {
  it("provides each valid calendar payment day once", () => {
    expect(SALARY_PAYMENT_DAYS).toHaveLength(31);
    expect(SALARY_PAYMENT_DAYS[0]).toBe(1);
    expect(SALARY_PAYMENT_DAYS[30]).toBe(31);
  });

  it("retains valid chosen days and safely normalizes invalid legacy values", () => {
    expect(normalizeSalaryPaymentDay(28)).toBe(28);
    expect(normalizeSalaryPaymentDay(0)).toBe(1);
    expect(normalizeSalaryPaymentDay(32)).toBe(1);
  });
});
