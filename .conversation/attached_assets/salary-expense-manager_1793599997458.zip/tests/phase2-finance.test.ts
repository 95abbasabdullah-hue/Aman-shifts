import { describe, expect, it } from "vitest";
import { dailySpendingSummary, budgetStatuses, financialSummary, savingsGoalSummaries } from "../lib/finance/insights";
import { applyRecurringEntries } from "../lib/finance/recurrence";
import { migrateFinanceSnapshot } from "../lib/finance/repository";
import { EMPTY_FINANCE_SNAPSHOT, type FinanceTransaction } from "../lib/finance/types";
import { validateBudget, validateSavingsGoal } from "../lib/finance/validation";

function transaction(overrides: Partial<FinanceTransaction>): FinanceTransaction {
  return {
    id: "txn", type: "variable_expense", amountMinor: 1, currency: "QAR", category: "Other", date: "2026-09-15", description: "Test", createdAt: "2026-09-15T00:00:00.000Z", updatedAt: "2026-09-15T00:00:00.000Z", ...overrides,
  };
}

describe("Phase 1 migration", () => {
  it("preserves prior records while safely adding absent Phase 2 fields", () => {
    const phaseOneData = {
      settings: { monthlySalaryMinor: 1_000_000, currency: "QAR", salaryPaymentDay: 27, automaticSalaryEnabled: true, onboardingCompleted: true, themePreference: "light" },
      transactions: [transaction({ id: "existing-expense", amountMinor: 12_500, category: "Food" })],
      bills: [],
      ignoredRecurringKeys: [],
    };
    const migrated = migrateFinanceSnapshot(phaseOneData);
    expect(migrated.transactions).toHaveLength(1);
    expect(migrated.transactions[0]).toMatchObject(phaseOneData.transactions[0]);
    expect(migrated.savingsGoals).toEqual([]);
    expect(migrated.budgets).toEqual([]);
    expect(migrated.settings.budgetWarningThresholdPercent).toBe(80);
    expect(migrated.settings.budgetExceededThresholdPercent).toBe(100);
  });
});

describe("savings calculations", () => {
  const goal = { id: "goal-car", name: "Car", targetMinor: 2_000_000, monthlyTargetMinor: 150_000, automaticAllocationMinor: 150_000, active: true, createdAt: "2026-01-01T00:00:00.000Z", updatedAt: "2026-01-01T00:00:00.000Z" };

  it("calculates deposits, withdrawals, remaining amount, and progress for multiple goals", () => {
    const snapshot = {
      ...EMPTY_FINANCE_SNAPSHOT,
      savingsGoals: [goal, { ...goal, id: "goal-trip", name: "Trip", targetMinor: 100_000 }],
      transactions: [
        transaction({ id: "deposit", type: "savings", amountMinor: 800_000, savingsGoalId: "goal-car", category: "Savings" }),
        transaction({ id: "withdrawal", type: "savings_withdrawal", amountMinor: 50_000, savingsGoalId: "goal-car", category: "Savings" }),
        transaction({ id: "trip", type: "savings", amountMinor: 10_000, savingsGoalId: "goal-trip", category: "Savings" }),
      ],
    };
    const summaries = savingsGoalSummaries(snapshot);
    expect(summaries.find((item) => item.id === "goal-car")).toMatchObject({ savedMinor: 750_000, remainingMinor: 1_250_000, progressPercent: 37.5 });
    expect(summaries.find((item) => item.id === "goal-trip")?.savedMinor).toBe(10_000);
  });

  it("automatically allocates one savings deposit per salary cycle without duplicates", () => {
    const configured = {
      ...EMPTY_FINANCE_SNAPSHOT,
      settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, monthlySalaryMinor: 1_000_000, salaryPaymentDay: 27, automaticSalaryEnabled: true },
      savingsGoals: [goal],
    };
    const once = applyRecurringEntries(configured, "2026-09-01");
    const twice = applyRecurringEntries(once, "2026-09-01");
    expect(once.transactions.filter((item) => item.type === "savings")).toHaveLength(1);
    expect(twice.transactions.filter((item) => item.type === "savings")).toHaveLength(1);
    expect(twice.transactions.find((item) => item.type === "savings")?.amountMinor).toBe(150_000);
  });
});

describe("budget and safe-spending calculations", () => {
  const budgetSnapshot = {
    ...EMPTY_FINANCE_SNAPSHOT,
    settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, budgetWarningThresholdPercent: 80, budgetExceededThresholdPercent: 100, salaryPaymentDay: 27 },
    budgets: [
      { id: "food", category: "Food" as const, limitMinor: 100_000, createdAt: "2026-01-01T00:00:00.000Z", updatedAt: "2026-01-01T00:00:00.000Z" },
      { id: "transport", category: "Transportation" as const, limitMinor: 50_000, createdAt: "2026-01-01T00:00:00.000Z", updatedAt: "2026-01-01T00:00:00.000Z" },
    ],
    transactions: [
      transaction({ id: "food-one", amountMinor: 80_000, category: "Food", date: "2026-09-10" }),
      transaction({ id: "future-food", amountMinor: 10_000, category: "Food", date: "2026-09-20" }),
      transaction({ id: "transport-one", amountMinor: 60_000, category: "Transportation", date: "2026-09-12" }),
      transaction({ id: "old-food", amountMinor: 99_000, category: "Food", date: "2026-08-30" }),
    ],
  };

  it("states normal, warning, and exceeded budgets from current-month variable spending", () => {
    const statuses = budgetStatuses(budgetSnapshot, "2026-09-15");
    expect(statuses.find((item) => item.budget.category === "Food")).toMatchObject({ spentMinor: 80_000, remainingMinor: 20_000, state: "warning" });
    expect(statuses.find((item) => item.budget.category === "Transportation")).toMatchObject({ spentMinor: 60_000, remainingMinor: -10_000, state: "exceeded" });
  });

  it("uses the days until the next salary cycle and never divides by zero", () => {
    expect(dailySpendingSummary(budgetSnapshot, 300_000, "2026-09-12")).toEqual({ daysRemaining: 15, safeDailySpendingMinor: 20_000 });
    expect(dailySpendingSummary(budgetSnapshot, 300_000, "2026-09-27").daysRemaining).toBeGreaterThan(0);
    expect(dailySpendingSummary(budgetSnapshot, -1, "2026-09-12").safeDailySpendingMinor).toBe(0);
  });

  it("rejects negative or zero savings and budget amounts", () => {
    expect(validateSavingsGoal({ name: "", targetMinor: 0, monthlyTargetMinor: -1, automaticAllocationMinor: -1 })).toMatchObject({
      name: expect.any(String), target: expect.any(String), monthlyTarget: expect.any(String), automaticAllocation: expect.any(String),
    });
    expect(validateBudget({ category: "Food", limitMinor: 0 })).toMatchObject({ limit: expect.any(String) });
  });
});

describe("current-cycle financial summary", () => {
  it("keeps savings transfers separate from expenses and reduces available spending only by net savings", () => {
    const snapshot = {
      ...EMPTY_FINANCE_SNAPSHOT,
      settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 27 },
      transactions: [
        transaction({ id: "salary", type: "income", amountMinor: 1_000_000, category: "Salary", date: "2026-08-27" }),
        transaction({ id: "bill", type: "fixed_expense", amountMinor: 350_000, category: "Rent", date: "2026-09-01" }),
        transaction({ id: "expense", type: "variable_expense", amountMinor: 120_000, category: "Food", date: "2026-09-05" }),
        transaction({ id: "saving", type: "savings", amountMinor: 150_000, category: "Savings", date: "2026-08-27" }),
        transaction({ id: "withdraw", type: "savings_withdrawal", amountMinor: 20_000, category: "Savings", date: "2026-09-06" }),
      ],
    };
    expect(financialSummary(snapshot, "2026-09-15")).toMatchObject({
      totalIncomeMinor: 1_000_000,
      totalFixedExpensesMinor: 350_000,
      totalVariableExpensesMinor: 120_000,
      totalSavingsMinor: 130_000,
      availableSpendingMinor: 400_000,
      highestSpendingCategory: "Food",
    });
  });

  it("recalculates available spending after an expense edit or deletion", () => {
    const baseline = {
      ...EMPTY_FINANCE_SNAPSHOT,
      settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 27 },
      transactions: [
        transaction({ id: "salary", type: "income", amountMinor: 500_000, category: "Salary", date: "2026-08-27" }),
        transaction({ id: "expense", type: "variable_expense", amountMinor: 50_000, category: "Food", date: "2026-09-05" }),
      ],
    };
    const edited = { ...baseline, transactions: baseline.transactions.map((item) => item.id === "expense" ? { ...item, amountMinor: 70_000 } : item) };
    const deleted = { ...baseline, transactions: baseline.transactions.filter((item) => item.id !== "expense") };
    expect(financialSummary(baseline, "2026-09-15").availableSpendingMinor).toBe(450_000);
    expect(financialSummary(edited, "2026-09-15").availableSpendingMinor).toBe(430_000);
    expect(financialSummary(deleted, "2026-09-15").availableSpendingMinor).toBe(500_000);
  });

  it("does not deduct bills or expenses before their scheduled date", () => {
    const snapshot = {
      ...EMPTY_FINANCE_SNAPSHOT,
      settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 27 },
      transactions: [
        transaction({ id: "salary", type: "income", amountMinor: 1_000_000, category: "Salary", date: "2026-08-27" }),
        transaction({ id: "due-today", type: "fixed_expense", amountMinor: 350_000, category: "Rent", date: "2026-09-01" }),
        transaction({ id: "future-bill", type: "fixed_expense", amountMinor: 120_000, category: "Internet", date: "2026-09-15" }),
        transaction({ id: "future-expense", type: "variable_expense", amountMinor: 80_000, category: "Food", date: "2026-09-05" }),
      ],
    };

    expect(financialSummary(snapshot, "2026-09-01")).toMatchObject({
      totalIncomeMinor: 1_000_000,
      totalFixedExpensesMinor: 350_000,
      totalVariableExpensesMinor: 0,
      availableSpendingMinor: 650_000,
    });
    expect(financialSummary(snapshot, "2026-09-15")).toMatchObject({
      totalFixedExpensesMinor: 470_000,
      totalVariableExpensesMinor: 80_000,
      availableSpendingMinor: 450_000,
    });
  });
});
