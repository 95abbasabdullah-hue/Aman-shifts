import { describe, expect, it } from "vitest";
import { accountSummaries, filterTransactions, recurringExpenseOccurrences } from "../lib/finance/phase3";
import { applyRecurringEntries } from "../lib/finance/recurrence";
import { createBackupPayload, mergeFinanceSnapshots, migrateFinanceSnapshot, validateBackupPayload } from "../lib/finance/repository";
import { EMPTY_FINANCE_SNAPSHOT, type FinanceTransaction } from "../lib/finance/types";

const now = "2026-09-01T00:00:00.000Z";
const transaction = (overrides: Partial<FinanceTransaction>): FinanceTransaction => ({ id: "transaction", type: "variable_expense", amountMinor: 100, baseAmountMinor: 100, currency: "QAR", category: "Food", date: "2026-09-10", description: "Test", accountId: "cash", createdAt: now, updatedAt: now, ...overrides });

describe("Phase 3 migration and accounts", () => {
  it("adds a local cash account and account references without changing Phase 2 amounts", () => {
    const { accountId: _accountId, baseAmountMinor: _baseAmountMinor, ...legacyTransaction } = transaction({ id: "legacy", amountMinor: 12345, baseAmountMinor: 12345, accountId: "cash" });
    const phaseTwo = { ...EMPTY_FINANCE_SNAPSHOT, transactions: [legacyTransaction] } as unknown as Record<string, unknown>;
    delete phaseTwo.accounts; delete phaseTwo.recurringExpenses; delete phaseTwo.currencyRates;
    const migrated = migrateFinanceSnapshot(phaseTwo);
    expect(migrated.accounts).toHaveLength(1);
    expect(migrated.transactions[0]).toMatchObject({ id: "legacy", amountMinor: 12345, accountId: migrated.accounts[0].id, baseAmountMinor: 12345 });
  });

  it("calculates opening balances and paired transfers without affecting spending accounting", () => {
    const snapshot = {
      ...EMPTY_FINANCE_SNAPSHOT,
      accounts: [
        { id: "bank", name: "Bank", type: "bank" as const, currency: "QAR", openingBalanceMinor: 100000, openingBalanceBaseMinor: 100000, createdAt: now, updatedAt: now },
        { id: "cash", name: "Cash", type: "cash" as const, currency: "QAR", openingBalanceMinor: 5000, openingBalanceBaseMinor: 5000, createdAt: now, updatedAt: now },
      ],
      transactions: [transaction({ id: "out", type: "transfer_out", amountMinor: 20000, baseAmountMinor: 20000, accountId: "bank", transferId: "move" }), transaction({ id: "in", type: "transfer_in", amountMinor: 20000, baseAmountMinor: 20000, accountId: "cash", transferId: "move" })],
    };
    expect(accountSummaries(snapshot, "2026-09-10").find((item) => item.id === "bank")?.balanceMinor).toBe(80000);
    expect(accountSummaries(snapshot, "2026-09-10").find((item) => item.id === "cash")?.balanceMinor).toBe(25000);
  });
});

describe("Phase 3 recurring expenses", () => {
  it("generates correct weekly and custom interval occurrences inside a salary cycle", () => {
    const cycle = { id: "cycle", start: "2026-09-01", end: "2026-09-30" };
    expect(recurringExpenseOccurrences({ startDate: "2026-08-29", frequency: "weekly" }, cycle)).toEqual(["2026-09-05", "2026-09-12", "2026-09-19", "2026-09-26"]);
    expect(recurringExpenseOccurrences({ startDate: "2026-08-30", frequency: "custom", customIntervalDays: 10 }, cycle)).toEqual(["2026-09-09", "2026-09-19", "2026-09-29"]);
  });

  it("does not duplicate automatic recurring expense transactions after repeat processing", () => {
    const configured = { ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 1 }, recurringExpenses: [{ id: "gym", name: "Gym", amountMinor: 20000, currency: "QAR", category: "Healthcare" as const, frequency: "monthly" as const, startDate: "2026-09-02", accountId: "cash", active: true, createdAt: now, updatedAt: now }], accounts: [{ id: "cash", name: "Cash", type: "cash" as const, currency: "QAR", openingBalanceMinor: 0, openingBalanceBaseMinor: 0, createdAt: now, updatedAt: now }] };
    const once = applyRecurringEntries(configured, "2026-09-15");
    const twice = applyRecurringEntries(once, "2026-09-15");
    expect(once.transactions.filter((item) => item.sourceRecurringExpenseId === "gym")).toHaveLength(1);
    expect(twice.transactions.filter((item) => item.sourceRecurringExpenseId === "gym")).toHaveLength(1);
  });
});

describe("Phase 3 ledger filters and backups", () => {
  it("filters and sorts a local ledger by account, type, date, and amount", () => {
    const items = [transaction({ id: "old", amountMinor: 200, date: "2026-09-01", accountId: "bank" }), transaction({ id: "new", amountMinor: 900, date: "2026-09-10", accountId: "cash", category: "Travel" }), transaction({ id: "income", type: "income", amountMinor: 1000, date: "2026-09-11", accountId: "cash" })];
    expect(filterTransactions(items, { accountId: "cash", type: "variable_expense", minAmountMinor: 500, startDate: "2026-09-05", sort: "highest" }).map((item) => item.id)).toEqual(["new"]);
    expect(filterTransactions(items, { sort: "oldest" }).map((item) => item.id)).toEqual(["old", "new", "income"]);
  });

  it("validates versioned local backups and merges imported records safely by ID", () => {
    const local = migrateFinanceSnapshot({ ...EMPTY_FINANCE_SNAPSHOT, transactions: [transaction({ id: "local" })] });
    const imported = migrateFinanceSnapshot({ ...EMPTY_FINANCE_SNAPSHOT, transactions: [transaction({ id: "local", amountMinor: 500 }), transaction({ id: "imported", amountMinor: 700 })] });
    const backup = createBackupPayload(imported);
    expect(validateBackupPayload(backup)).toBe(true);
    const merged = mergeFinanceSnapshots(local, backup.snapshot);
    expect(merged.transactions.map((item) => item.id).sort()).toEqual(["imported", "local"]);
    expect(merged.transactions.find((item) => item.id === "local")?.amountMinor).toBe(500);
    expect(validateBackupPayload({ schemaVersion: 2, snapshot: imported })).toBe(false);
  });
});
