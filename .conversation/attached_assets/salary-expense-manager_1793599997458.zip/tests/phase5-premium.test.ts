import { describe, expect, it } from "vitest";
import { processPremiumFeedback } from "../lib/finance/premium-events";
import { buildLocalReminderPlan } from "../lib/finance/reminder-plan";
import { migrateFinanceSnapshot } from "../lib/finance/repository";
import { EMPTY_FINANCE_SNAPSHOT, type FinanceTransaction } from "../lib/finance/types";

const now = "2026-09-01T00:00:00.000Z";
const transaction = (overrides: Partial<FinanceTransaction>): FinanceTransaction => ({ id: "row", type: "variable_expense", amountMinor: 100, baseAmountMinor: 100, currency: "QAR", category: "Food", date: "2026-09-10", description: "Test", accountId: "cash", createdAt: now, updatedAt: now, ...overrides });

describe("Phase 5 preference migration", () => {
  it("adds sound, animation, notification schedule, and event-state defaults without changing prior finance data", () => {
    const legacy = { ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, notificationPreferences: { enabled: true } }, transactions: [transaction({ id: "keep", amountMinor: 4567 })] } as unknown as Record<string, unknown>;
    delete (legacy as { processedExperienceKeys?: unknown }).processedExperienceKeys;
    const migrated = migrateFinanceSnapshot(legacy);
    expect(migrated.transactions.find((item) => item.id === "keep")?.amountMinor).toBe(4567);
    expect(migrated.settings.soundPreferences).toMatchObject({ enabled: true, buttonSounds: true, selectionHaptics: true, transactionSounds: true });
    expect(migrated.settings.animationEffectsEnabled).toBe(true);
    expect(migrated.settings.notificationPreferences).toMatchObject({ salaryReminderTiming: "day_of", billReminderDays: 1, notificationSound: true, vibration: false });
    expect(migrated.processedExperienceKeys).toEqual([]);
  });
});

describe("Phase 5 local reminder plan", () => {
  it("schedules salary-day, salary-eve, and selected bill lead-time reminders with stable local identifiers", () => {
    const snapshot = migrateFinanceSnapshot({ ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 27, notificationPreferences: { ...EMPTY_FINANCE_SNAPSHOT.settings.notificationPreferences, enabled: true, salaryReceived: true, salaryCycleReminder: true, salaryReminderTiming: "both", upcomingBill: true, billReminderDays: 2 } }, bills: [{ id: "power", name: "Electricity", amountMinor: 25000, currency: "QAR", dueDate: "2026-09-20", frequency: "monthly" as const, category: "Electricity" as const, active: true, createdAt: now, updatedAt: now }] });
    const plan = buildLocalReminderPlan(snapshot, "2026-09-10");
    expect(plan.map((item) => item.id)).toEqual(["bill:power:2026-09-20", "salary-eve:2026-09-27", "salary-day:2026-09-27", "bill:power:2026-10-20"]);
    expect(plan.find((item) => item.id === "bill:power:2026-09-20")).toMatchObject({ date: "2026-09-18", channelId: "finance-bills" });
    expect(plan.find((item) => item.id === "salary-day:2026-09-27")).toMatchObject({ date: "2026-09-27", channelId: "finance-salary" });
  });

  it("does not produce any plan when local reminders are disabled", () => {
    expect(buildLocalReminderPlan(migrateFinanceSnapshot(EMPTY_FINANCE_SNAPSHOT), "2026-09-10")).toEqual([]);
  });
});

describe("Phase 5 premium feedback safeguards", () => {
  it("emits salary feedback only for a newly created recurring salary transaction", () => {
    const previous = migrateFinanceSnapshot(EMPTY_FINANCE_SNAPSHOT);
    const candidate = migrateFinanceSnapshot({ ...previous, transactions: [transaction({ id: "salary", type: "income", amountMinor: 500000, recurringKey: "salary:cycle:2026-09-01", category: "Salary", date: "2026-09-01" })] });
    const first = processPremiumFeedback(previous, candidate, "2026-09-05");
    const second = processPremiumFeedback(first.snapshot, first.snapshot, "2026-09-05");
    expect(first.feedback).toMatchObject({ kind: "salary", amountMinor: 500000 });
    expect(second.feedback).toBeNull();
  });

  it("celebrates a savings goal completion once and separately surfaces a budget threshold crossing", () => {
    const seed = migrateFinanceSnapshot({ ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 1, notificationPreferences: { ...EMPTY_FINANCE_SNAPSHOT.settings.notificationPreferences, enabled: true, savingsGoal: true, budgetWarning: true } }, savingsGoals: [{ id: "goal", name: "Car Fund", targetMinor: 1000, monthlyTargetMinor: 0, automaticAllocationMinor: 0, active: true, createdAt: now, updatedAt: now }], budgets: [{ id: "food", category: "Food" as const, limitMinor: 1000, createdAt: now, updatedAt: now }], transactions: [transaction({ id: "old-save", type: "savings", amountMinor: 400, savingsGoalId: "goal", category: "Savings", date: "2026-09-02" })] });
    const candidate = migrateFinanceSnapshot({ ...seed, transactions: [transaction({ id: "new-save", type: "savings", amountMinor: 600, savingsGoalId: "goal", category: "Savings", date: "2026-09-03" }), transaction({ id: "food-spend", type: "variable_expense", amountMinor: 800, category: "Food", date: "2026-09-04" }), ...seed.transactions] });
    const first = processPremiumFeedback(seed, candidate, "2026-09-05");
    const second = processPremiumFeedback(first.snapshot, first.snapshot, "2026-09-05");
    expect(first.feedback).toMatchObject({ kind: "goal", detail: "Car Fund" });
    expect(first.notifications.map((item) => item.kind)).toContain("budget");
    expect(second.feedback).toBeNull();
    expect(second.notifications).toEqual([]);
  });
});
