import { describe, expect, it } from "vitest";
import { getSalaryCycle } from "../lib/finance/cycle";
import { resolveTextInputEditable } from "../lib/finance/input-behavior";
import { buildLocalReminderPlan } from "../lib/finance/reminder-plan";
import { migrateFinanceSnapshot } from "../lib/finance/repository";
import { ensureCurrentSalary } from "../lib/finance/recurrence";
import { EMPTY_FINANCE_SNAPSHOT } from "../lib/finance/types";
import { validateTransaction } from "../lib/finance/validation";

describe("Phase 6 optional input and calendar safeguards", () => {
  it("keeps shared finance text fields editable by default while respecting deliberate disablement", () => {
    expect(resolveTextInputEditable(undefined)).toBe(true);
    expect(resolveTextInputEditable(true)).toBe(true);
    expect(resolveTextInputEditable(false)).toBe(false);
  });

  it("accepts a transaction with no user-entered description", () => {
    expect(validateTransaction({ amountMinor: 25000, currency: "QAR", date: "2026-08-27", description: "" }, "QAR")).toEqual({});
  });

  it("accepts leap-day dates and rejects impossible calendar dates", () => {
    expect(validateTransaction({ amountMinor: 1, currency: "QAR", date: "2024-02-29", description: "" }, "QAR")).toEqual({});
    expect(validateTransaction({ amountMinor: 1, currency: "QAR", date: "2024-02-30", description: "" }, "QAR").date).toBeDefined();
    expect(validateTransaction({ amountMinor: 1, currency: "QAR", date: "2023-02-29", description: "" }, "QAR").date).toBeDefined();
    expect(validateTransaction({ amountMinor: 1, currency: "QAR", date: "2026-04-31", description: "" }, "QAR").date).toBeDefined();
  });
});

describe("Phase 6 calculation and reset preservation", () => {
  it("updates the configured salary for the current cycle without adding a duplicate salary entry", () => {
    const configured = migrateFinanceSnapshot({ ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, monthlySalaryMinor: 1000000, salaryPaymentDay: 27, automaticSalaryEnabled: true } });
    const first = ensureCurrentSalary(configured, "2026-08-27");
    const edited = ensureCurrentSalary({ ...first, settings: { ...first.settings, monthlySalaryMinor: 1100000 } }, "2026-08-27");
    const cycle = getSalaryCycle("2026-08-27", 27);
    const salaryRows = edited.transactions.filter((item) => item.recurringKey === `salary:${cycle.id}`);
    expect(salaryRows).toHaveLength(1);
    expect(salaryRows[0].amountMinor).toBe(1100000);
  });

  it("produces a clean onboarding-ready state with no future local reminders after reset data is cleared", () => {
    const reset = EMPTY_FINANCE_SNAPSHOT;
    expect(reset.settings.onboardingCompleted).toBe(false);
    expect(reset.transactions).toEqual([]);
    expect(reset.bills).toEqual([]);
    expect(reset.recurringExpenses).toEqual([]);
    expect(reset.savingsGoals).toEqual([]);
    expect(reset.budgets).toEqual([]);
    expect(reset.accounts).toEqual([]);
    expect(buildLocalReminderPlan(reset, "2026-08-27")).toEqual([]);
  });
});
