import { describe, expect, it } from "vitest";
import { getSalaryCycle, totalByType, cycleTransactions } from "../lib/finance/cycle";
import { deleteTransactionFromSnapshot } from "../lib/finance/transaction-delete";
import { transactionDeleteExit } from "../lib/finance/transaction-delete-navigation";
import { EMPTY_FINANCE_SNAPSHOT, type FinanceTransaction } from "../lib/finance/types";

const timestamp = "2026-08-27T00:00:00.000Z";
const entry = (overrides: Partial<FinanceTransaction>): FinanceTransaction => ({ id: "row", type: "variable_expense", amountMinor: 10000, currency: "QAR", category: "Food", date: "2026-08-27", description: "Expense", createdAt: timestamp, updatedAt: timestamp, ...overrides });

describe("Phase 7 transaction deletion", () => {
  it("removes a standalone expense and immediately removes it from the current-cycle total", () => {
    const snapshot = { ...EMPTY_FINANCE_SNAPSHOT, settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 27 }, transactions: [entry({ id: "income", type: "income", amountMinor: 100000, category: "Salary" }), entry({ id: "expense", amountMinor: 25000 })] };
    const deleted = deleteTransactionFromSnapshot(snapshot, "expense");
    const cycle = getSalaryCycle("2026-08-27", 27);
    expect(deleted.transactions.map((item) => item.id)).toEqual(["income"]);
    expect(totalByType(cycleTransactions(deleted, cycle), "variable_expense")).toBe(0);
    expect(totalByType(cycleTransactions(deleted, cycle), "income")).toBe(100000);
  });

  it("removes both entries from an internal transfer but preserves unrelated records", () => {
    const snapshot = { ...EMPTY_FINANCE_SNAPSHOT, transactions: [entry({ id: "out", type: "transfer_out", transferId: "move-1", amountMinor: 5000, category: "Transfer" }), entry({ id: "in", type: "transfer_in", transferId: "move-1", amountMinor: 5000, category: "Transfer" }), entry({ id: "keep", amountMinor: 1200 })] };
    const deleted = deleteTransactionFromSnapshot(snapshot, "out");
    expect(deleted.transactions.map((item) => item.id)).toEqual(["keep"]);
  });

  it("records a recurring key as ignored so an explicitly deleted automatic record is not recreated", () => {
    const snapshot = { ...EMPTY_FINANCE_SNAPSHOT, transactions: [entry({ id: "bill-row", type: "fixed_expense", recurringKey: "bill:rent:2026-08-27" })] };
    const deleted = deleteTransactionFromSnapshot(snapshot, "bill-row");
    expect(deleted.ignoredRecurringKeys).toContain("bill:rent:2026-08-27");
    expect(deleted.transactions).toEqual([]);
  });

  it("does not silently persist when the requested record does not exist", () => {
    expect(() => deleteTransactionFromSnapshot(EMPTY_FINANCE_SNAPSHOT, "missing")).toThrow("no longer available");
  });

  it("returns to a ledger screen after a direct-link delete, while preserving normal back navigation", () => {
    expect(transactionDeleteExit(true)).toBe("back");
    expect(transactionDeleteExit(false)).toBe("transactions");
  });
});
