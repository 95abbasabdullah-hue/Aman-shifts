import { describe, expect, it } from "vitest";
import { resolveRootBackAction } from "../lib/navigation/root-back";

describe("Phase 7 root back navigation", () => {
  it("delegates non-Android navigation to the normal route stack", () => {
    expect(resolveRootBackAction("ios", false)).toBe("delegate");
    expect(resolveRootBackAction("web", false)).toBe("delegate");
  });

  it("requests exit confirmation at an Android app root and consumes repeated back presses while that dialog is open", () => {
    expect(resolveRootBackAction("android", false)).toBe("confirm-exit");
    expect(resolveRootBackAction("android", true)).toBe("consume");
  });

  it("delegates Android Back to normal navigation while a nested route can still go back", () => {
    expect(resolveRootBackAction("android", false, true)).toBe("delegate");
  });

  it("always requests confirmation when Android Back would exit the app", () => {
    expect(resolveRootBackAction("android", false, false)).toBe("confirm-exit");
  });
});
