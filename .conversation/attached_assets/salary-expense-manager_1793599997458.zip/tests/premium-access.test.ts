import { describe, expect, it } from "vitest";
import { permittedColorScheme, premiumComparisonRows, premiumFeatureLabel, resolvePremiumEntitlement } from "../lib/premium/access";

describe("Premium access policy", () => {
  it("uses only a verified store entitlement to unlock Premium", () => {
    expect(resolvePremiumEntitlement({ storeEntitled: false })).toBe(false);
    expect(resolvePremiumEntitlement({ storeEntitled: true })).toBe(true);
  });

  it("uses clear labels for each gated feature in the safe unlock interface", () => {
    expect(premiumFeatureLabel("statistics")).toBe("Statistics");
    expect(premiumFeatureLabel("quick_expenses")).toBe("Quick expense templates");
    expect(premiumFeatureLabel("remove_ads")).toBe("Remove ads");
  });

  it("allows saved dark appearance without Premium access", () => {
    expect(permittedColorScheme("dark")).toBe("dark");
    expect(permittedColorScheme("system")).toBe("light");
    expect(permittedColorScheme("light")).toBe("light");
  });

  it("identifies Free, preview, and Premium-only capabilities for the locked-screen comparison", () => {
    expect(premiumComparisonRows()).toEqual(expect.arrayContaining([
      expect.objectContaining({ label: "Dark appearance", free: "included", premium: "included" }),
      expect.objectContaining({ label: "Forecasts & exports", free: "preview", premium: "included" }),
      expect.objectContaining({ label: "Quick expense templates", free: "locked", premium: "included" }),
      expect.objectContaining({ label: "Ad-free experience", free: "ad_supported", premium: "included" }),
    ]));
  });
});
