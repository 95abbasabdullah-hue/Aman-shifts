import { describe, expect, it } from "vitest";
import { premiumExitRoute } from "../lib/navigation/premium-exit";

describe("Premium preview navigation", () => {
  it("returns safely to More when the preview is closed, including direct-link entry", () => {
    expect(premiumExitRoute()).toBe("/more");
  });
});
