import { describe, expect, it } from "vitest";
import { DEFAULT_QUICK_EXPENSE_APPEARANCE, quickExpenseAppearance } from "../lib/finance/quick-expense-appearance";
import { quickExpenseTemplateRoute } from "../lib/finance/quick-expenses";
import { LOCKED_QUICK_EXPENSE_PREVIEW_NAMES, usesLockedTemplatePreview } from "../lib/finance/locked-quick-expense-preview";
import { mergeFinanceSnapshots, migrateFinanceSnapshot } from "../lib/finance/repository";
import { EMPTY_FINANCE_SNAPSHOT } from "../lib/finance/types";

const template = { id: "coffee", name: "Coffee", amountMinor: 1500, currency: "QAR", category: "Food" as const, icon: "local-cafe" as const, color: "#B45309" as const, createdAt: "2026-08-01T00:00:00.000Z", updatedAt: "2026-08-01T00:00:00.000Z" };

describe("quick expense templates", () => {
  it("migrates older local snapshots with an empty template list", () => {
    const older = { ...EMPTY_FINANCE_SNAPSHOT } as Record<string, unknown>;
    delete older.quickExpenseTemplates;
    expect(migrateFinanceSnapshot(older).quickExpenseTemplates).toEqual([]);
  });

  it("merges locally stored templates by identifier", () => {
    const current = { ...EMPTY_FINANCE_SNAPSHOT, quickExpenseTemplates: [template] };
    const imported = { ...EMPTY_FINANCE_SNAPSHOT, quickExpenseTemplates: [{ ...template, name: "Coffee shop", updatedAt: "2026-08-02T00:00:00.000Z" }] };
    expect(mergeFinanceSnapshots(current, imported).quickExpenseTemplates).toEqual([expect.objectContaining({ name: "Coffee shop" })]);
  });

  it("opens the normal variable-expense form with an encoded template identifier", () => {
    expect(quickExpenseTemplateRoute("coffee & tea")).toBe("/transaction-form?type=variable_expense&quickTemplateId=coffee%20%26%20tea");
  });

  it("adds a stable default appearance to older saved templates", () => {
    expect(quickExpenseAppearance({} as Pick<typeof template, "icon" | "color">)).toEqual(DEFAULT_QUICK_EXPENSE_APPEARANCE);
    const legacy = { ...EMPTY_FINANCE_SNAPSHOT, quickExpenseTemplates: [{ ...template, icon: undefined, color: undefined }] };
    expect(migrateFinanceSnapshot(legacy).quickExpenseTemplates[0]).toMatchObject(DEFAULT_QUICK_EXPENSE_APPEARANCE);
  });

  it("uses static examples for the locked dashboard preview without reading saved template data", () => {
    expect(LOCKED_QUICK_EXPENSE_PREVIEW_NAMES).toEqual(["Coffee", "Fuel", "Lunch"]);
    expect(usesLockedTemplatePreview(4, false)).toBe(true);
    expect(usesLockedTemplatePreview(4, true)).toBe(false);
  });
});
