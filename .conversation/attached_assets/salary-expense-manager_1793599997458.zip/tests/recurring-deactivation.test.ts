import { describe, expect, it } from "vitest";
import { financialSummary } from "../lib/finance/insights";
import { applyRecurringEntries, reconcileCurrentCycleBillEntries, removeCurrentCycleGeneratedEntries } from "../lib/finance/recurrence";
import { EMPTY_FINANCE_SNAPSHOT, type FinanceSnapshot } from "../lib/finance/types";

const timestamp = "2026-09-01T00:00:00.000Z";

describe("recurring rule deactivation", () => {
  it("removes the current-cycle generated bill when its active rule is turned off", () => {
    const snapshot: FinanceSnapshot = {
      ...EMPTY_FINANCE_SNAPSHOT,
      settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 1 },
      bills: [{ id: "rent", name: "Rent", amountMinor: 100_000, currency: "QAR", dueDate: "2026-09-05", frequency: "monthly", category: "Rent", active: true, createdAt: timestamp, updatedAt: timestamp }],
    };
    const generated = applyRecurringEntries(snapshot, "2026-09-10");
    const deactivated = removeCurrentCycleGeneratedEntries(generated, { billId: "rent" }, "2026-09-10");

    expect(generated.transactions.some((item) => item.sourceBillId === "rent")).toBe(true);
    expect(deactivated.transactions.some((item) => item.sourceBillId === "rent")).toBe(false);
  });

  it("removes only the current-cycle recurring-expense charge and retains earlier history", () => {
    const snapshot: FinanceSnapshot = {
      ...EMPTY_FINANCE_SNAPSHOT,
      settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, salaryPaymentDay: 1 },
      recurringExpenses: [{ id: "streaming", name: "Streaming", amountMinor: 5_000, currency: "QAR", category: "Entertainment", frequency: "monthly", startDate: "2026-08-03", active: true, createdAt: timestamp, updatedAt: timestamp }],
      transactions: [{ id: "past", type: "variable_expense", amountMinor: 5_000, baseAmountMinor: 5_000, currency: "QAR", category: "Entertainment", date: "2026-08-03", description: "Streaming", sourceRecurringExpenseId: "streaming", createdAt: timestamp, updatedAt: timestamp }],
    };
    const generated = applyRecurringEntries(snapshot, "2026-09-10");
    const deactivated = removeCurrentCycleGeneratedEntries(generated, { recurringExpenseId: "streaming" }, "2026-09-10");

    expect(deactivated.transactions.map((item) => item.id)).toEqual(["past"]);
  });

  it("reconciles an edited bill to one generated entry with the new date and amount", () => {
    const snapshot: FinanceSnapshot = {
      ...EMPTY_FINANCE_SNAPSHOT,
      settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, monthlySalaryMinor: 1_000_000, salaryPaymentDay: 1 },
      bills: [{ id: "rent", name: "Rent", amountMinor: 100_000, currency: "QAR", dueDate: "2026-09-05", frequency: "monthly", category: "Rent", active: true, createdAt: timestamp, updatedAt: timestamp }],
    };
    const generated = applyRecurringEntries(snapshot, "2026-09-05");
    const edited = reconcileCurrentCycleBillEntries({
      ...generated,
      bills: [{ ...snapshot.bills[0], dueDate: "2026-09-06", amountMinor: 125_000, updatedAt: "2026-09-06T00:00:00.000Z" }],
    }, "rent", "2026-09-06");
    const billEntries = edited.transactions.filter((item) => item.sourceBillId === "rent");

    expect(billEntries).toHaveLength(1);
    expect(billEntries[0]).toMatchObject({ date: "2026-09-06", amountMinor: 125_000, recurringKey: "bill:rent:2026-09-06" });
  });

  it("keeps a future bill out of balance until today, then includes it today and after", () => {
    const snapshot: FinanceSnapshot = {
      ...EMPTY_FINANCE_SNAPSHOT,
      settings: { ...EMPTY_FINANCE_SNAPSHOT.settings, monthlySalaryMinor: 1_000_000, salaryPaymentDay: 1 },
      bills: [{ id: "rent", name: "Rent", amountMinor: 100_000, currency: "QAR", dueDate: "2026-09-05", frequency: "monthly", category: "Rent", active: true, createdAt: timestamp, updatedAt: timestamp }],
    };
    const generated = applyRecurringEntries(snapshot, "2026-09-04");

    expect(financialSummary(generated, "2026-09-04").availableSpendingMinor).toBe(1_000_000);
    expect(financialSummary(generated, "2026-09-05").availableSpendingMinor).toBe(900_000);
    expect(financialSummary(generated, "2026-09-06").availableSpendingMinor).toBe(900_000);
  });
});
