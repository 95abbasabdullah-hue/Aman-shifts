import { describe, expect, it } from "vitest";
import { recurringExpensesExitAction } from "../lib/navigation/recurring-expenses-exit";

describe("Recurring expenses exit navigation", () => {
  it("uses prior navigation when the page was opened from within the app", () => {
    expect(recurringExpensesExitAction(true)).toBe("back");
  });

  it("returns to Bills when a direct link has no prior screen", () => {
    expect(recurringExpensesExitAction(false)).toBe("bills");
  });
});
