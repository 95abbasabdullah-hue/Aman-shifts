import { describe, expect, it } from "vitest";
import { nextResetConfirmationStep } from "../lib/finance/reset-confirmation";

describe("Reset Everything confirmation", () => {
  it("requires a final confirmation after the initial data-removal warning", () => {
    expect(nextResetConfirmationStep("review")).toBe("final");
  });

  it("does not expose an action that skips the final confirmation", () => {
    expect(nextResetConfirmationStep("final")).toBe("final");
  });
});
