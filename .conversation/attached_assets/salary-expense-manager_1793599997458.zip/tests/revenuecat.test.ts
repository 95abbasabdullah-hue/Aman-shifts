import { beforeEach, describe, expect, it, vi } from "vitest";
import type { CustomerInfo, PurchasesPackage } from "react-native-purchases";

const mocks = vi.hoisted(() => ({
  platform: { OS: "android" },
  constants: { executionEnvironment: "standalone" },
  sdk: {
    configure: vi.fn(),
    getCustomerInfo: vi.fn(),
    getOfferings: vi.fn(),
    purchasePackage: vi.fn(),
    restorePurchases: vi.fn(),
    addCustomerInfoUpdateListener: vi.fn(),
    PURCHASES_ERROR_CODE: { PURCHASE_CANCELLED_ERROR: "1", PAYMENT_PENDING_ERROR: "20" },
  },
}));
vi.mock("react-native", () => ({ Platform: mocks.platform }));
vi.mock("expo-constants", () => ({ default: mocks.constants }));
vi.mock("react-native-purchases", () => ({ default: mocks.sdk }));

function info(active = true, id = "salary_manager_pro"): CustomerInfo {
  return { entitlements: { active: active ? { [id]: { isActive: true } } : {} } } as CustomerInfo;
}
function pkg(identifier: string): PurchasesPackage {
  return { identifier, product: { identifier: `store-${identifier}`, priceString: "QAR 10.99", title: "Premium", description: "Subscription" } } as PurchasesPackage;
}
const monthly = pkg("$rc_monthly");
const annual = pkg("$rc_annual");

beforeEach(() => {
  vi.resetModules();
  vi.resetAllMocks();
  mocks.platform.OS = "android";
  mocks.constants.executionEnvironment = "standalone";
  mocks.sdk.getCustomerInfo.mockResolvedValue(info(false));
  mocks.sdk.getOfferings.mockResolvedValue({ all: { default: { availablePackages: [annual, monthly] } }, current: null });
  mocks.sdk.purchasePackage.mockResolvedValue({ customerInfo: info() });
  mocks.sdk.restorePurchases.mockResolvedValue(info());
});

describe("RevenueCat billing integration", () => {
  it("configures once even when startup listeners and reads run concurrently", async () => {
    const rc = await import("../lib/premium/revenuecat");
    await Promise.all([rc.getRevenueCatState(), rc.getRevenueCatState(), rc.subscribeToRevenueCatCustomerInfo(vi.fn())]);
    expect(mocks.sdk.configure).toHaveBeenCalledTimes(1);
    expect(mocks.sdk.configure).toHaveBeenCalledWith({ apiKey: expect.stringMatching(/^goog_/) });
  });

  it.each(["web", "ios"])("never configures the Google Play SDK on %s", async (platform) => {
    mocks.platform.OS = platform;
    const rc = await import("../lib/premium/revenuecat");
    expect(await rc.getRevenueCatState()).toMatchObject({ isConfigured: false, isPremium: false, offers: [] });
    await expect(rc.purchaseRevenueCatPackage("$rc_monthly")).rejects.toThrow("Google Play");
    await expect(rc.restoreRevenueCatPurchases()).rejects.toThrow("Google Play");
    expect(mocks.sdk.configure).not.toHaveBeenCalled();
  });

  it("does not grant mock purchases in Expo Go", async () => {
    mocks.constants.executionEnvironment = "storeClient";
    const rc = await import("../lib/premium/revenuecat");
    expect((await rc.getRevenueCatState()).isPremium).toBe(false);
    expect(mocks.sdk.configure).not.toHaveBeenCalled();
  });

  it("reads store prices and uses only the exact configured entitlement", async () => {
    const rc = await import("../lib/premium/revenuecat");
    const state = await rc.getRevenueCatState();
    expect(state.offers.map((offer) => offer.identifier)).toEqual(["$rc_monthly", "$rc_annual"]);
    expect(state.offers[0].priceString).toBe("QAR 10.99");
    expect(state.isPremium).toBe(false);
    expect(rc.isRevenueCatPremium(info(true, "premium"))).toBe(false);
    expect(rc.isRevenueCatPremium(info())).toBe(true);
    expect(rc.isRevenueCatPremium(info(false))).toBe(false);
  });

  it("preserves active Premium when loading offerings fails", async () => {
    mocks.sdk.getCustomerInfo.mockResolvedValue(info());
    mocks.sdk.getOfferings.mockRejectedValue(new Error("Offline"));
    const rc = await import("../lib/premium/revenuecat");
    expect(await rc.getRevenueCatState()).toMatchObject({ isPremium: true, offers: [], offeringsError: expect.any(String) });
  });

  it("does not hide customer-info failures or grant Premium", async () => {
    mocks.sdk.getCustomerInfo.mockRejectedValue(new Error("Customer request failed"));
    const rc = await import("../lib/premium/revenuecat");
    await expect(rc.getRevenueCatState()).rejects.toThrow("Customer request failed");
  });

  it("restores an existing entitlement even if offerings fail", async () => {
    mocks.sdk.getOfferings.mockRejectedValue(new Error("Offering misconfigured"));
    const rc = await import("../lib/premium/revenuecat");
    expect((await rc.restoreRevenueCatPurchases()).isPremium).toBe(true);
    expect(mocks.sdk.restorePurchases).toHaveBeenCalledTimes(1);
  });

  it("does not silently purchase a different offering when default is missing", async () => {
    mocks.sdk.getOfferings.mockResolvedValue({ all: {}, current: { availablePackages: [monthly] } });
    const rc = await import("../lib/premium/revenuecat");
    expect((await rc.getRevenueCatState()).offers).toEqual([]);
    await expect(rc.purchaseRevenueCatPackage("$rc_monthly")).rejects.toThrow("not available");
    expect(mocks.sdk.purchasePackage).not.toHaveBeenCalled();
  });

  it.each(["$rc_monthly", "$rc_annual"] as const)("purchases the selected %s package and checks the returned entitlement", async (id) => {
    const rc = await import("../lib/premium/revenuecat");
    expect((await rc.purchaseRevenueCatPackage(id)).isPremium).toBe(true);
    expect(mocks.sdk.purchasePackage).toHaveBeenCalledWith(id === "$rc_monthly" ? monthly : annual);
    mocks.sdk.purchasePackage.mockResolvedValue({ customerInfo: info(false) });
    expect((await rc.purchaseRevenueCatPackage(id)).isPremium).toBe(false);
  });

  it("returns no access when restoration finds no active subscription", async () => {
    mocks.sdk.restorePurchases.mockResolvedValue(info(false));
    const rc = await import("../lib/premium/revenuecat");
    expect((await rc.restoreRevenueCatPurchases()).isPremium).toBe(false);
  });

  it("propagates cancellation and pending payment without granting access", async () => {
    const rc = await import("../lib/premium/revenuecat");
    const cancelled = { code: "1", message: "Cancelled" };
    mocks.sdk.purchasePackage.mockRejectedValue(cancelled);
    await expect(rc.purchaseRevenueCatPackage("$rc_monthly")).rejects.toBe(cancelled);
    expect(rc.isRevenueCatCancellation(cancelled)).toBe(true);
    expect(rc.isRevenueCatCancellation({ userCancelled: true })).toBe(true);
    expect(rc.isRevenueCatCancellation({ code: "20" })).toBe(false);
    const pending = { code: "20", message: "Pending" };
    mocks.sdk.purchasePackage.mockRejectedValue(pending);
    await expect(rc.purchaseRevenueCatPackage("$rc_monthly")).rejects.toBe(pending);
    expect(rc.revenueCatErrorMessage(pending, "Failed")).toContain("payment is pending");
    expect(rc.revenueCatErrorMessage({ message: "Network unavailable" }, "Failed")).toBe("Network unavailable");
  });

  it("can retry SDK configuration after a failure", async () => {
    mocks.sdk.configure.mockImplementationOnce(() => { throw new Error("Native module not ready"); });
    const rc = await import("../lib/premium/revenuecat");
    await expect(rc.getRevenueCatState()).rejects.toThrow("Native module not ready");
    expect((await rc.getRevenueCatState()).isConfigured).toBe(true);
    expect(mocks.sdk.configure).toHaveBeenCalledTimes(2);
  });

  it("registers one native listener and detaches JS subscribers on cleanup", async () => {
    const rc = await import("../lib/premium/revenuecat");
    const first = vi.fn();
    const second = vi.fn();
    const [removeFirst, removeSecond] = await Promise.all([
      rc.subscribeToRevenueCatCustomerInfo(first), rc.subscribeToRevenueCatCustomerInfo(second),
    ]);
    expect(mocks.sdk.addCustomerInfoUpdateListener).toHaveBeenCalledTimes(1);
    const emit = mocks.sdk.addCustomerInfoUpdateListener.mock.calls[0][0];
    emit(info());
    expect(first).toHaveBeenCalledTimes(1);
    expect(second).toHaveBeenCalledTimes(1);
    removeFirst();
    emit(info(false));
    expect(first).toHaveBeenCalledTimes(1);
    expect(second).toHaveBeenCalledTimes(2);
    removeSecond();
  });
});
