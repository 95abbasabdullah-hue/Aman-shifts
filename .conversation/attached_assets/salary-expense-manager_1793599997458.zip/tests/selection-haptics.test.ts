import { describe, expect, it } from "vitest";
import { areSelectionHapticsEnabled } from "../lib/finance/interaction-haptics";
import { DEFAULT_SOUND_PREFERENCES } from "../lib/finance/types";

describe("selection haptic preference", () => {
  it("requires the independent haptics master and the dedicated selection choice", () => {
    expect(areSelectionHapticsEnabled(DEFAULT_SOUND_PREFERENCES)).toBe(true);
    expect(areSelectionHapticsEnabled({ ...DEFAULT_SOUND_PREFERENCES, selectionHaptics: false })).toBe(false);
    expect(areSelectionHapticsEnabled({ ...DEFAULT_SOUND_PREFERENCES, hapticsEnabled: false })).toBe(false);
    expect(areSelectionHapticsEnabled({ ...DEFAULT_SOUND_PREFERENCES, enabled: false })).toBe(true);
  });
});
