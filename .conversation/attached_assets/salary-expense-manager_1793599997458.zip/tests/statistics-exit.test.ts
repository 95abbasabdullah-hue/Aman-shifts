import { describe, expect, it } from "vitest";
import { statisticsExitHref } from "../lib/navigation/statistics-exit";

describe("Statistics exit", () => {
  it("always returns directly to More without depending on prior router history", () => {
    expect(statisticsExitHref()).toBe("/(tabs)/more");
  });
});
