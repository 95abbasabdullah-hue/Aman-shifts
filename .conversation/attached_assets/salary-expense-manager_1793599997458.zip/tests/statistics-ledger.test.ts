import { describe, expect, it } from "vitest";
import { ledgerItemBreakdown } from "../lib/finance/statistics-ledger";
import type { FinanceTransaction, TransactionType } from "../lib/finance/types";

function transaction(type: TransactionType, category: string, baseAmountMinor: number): FinanceTransaction {
  return { id: `${type}-${category}`, type, category, amountMinor: baseAmountMinor, baseAmountMinor, currency: "QAR", date: "2026-08-01", description: category, createdAt: "2026-08-01", updatedAt: "2026-08-01" };
}

describe("item-based Ledger Statistics", () => {
  it("combines transactions and applied bills by their individual item names, not broad categories", () => {
    const waterBill = { ...transaction("fixed_expense", "Water", 25000), description: "Water" };
    const carExpense = { ...transaction("variable_expense", "Transportation", 12000), description: "Car" };
    const secondWaterBill = { ...transaction("fixed_expense", "Water", 7000), id: "fixed-expense-water-second", description: "Water" };
    expect(ledgerItemBreakdown([waterBill, carExpense, secondWaterBill])).toEqual({ Water: 32000, Car: 12000 });
  });

  it("uses the category only when a legacy record has no item description", () => {
    expect(ledgerItemBreakdown([{ ...transaction("fixed_expense", "Internet", 7000), description: "" }])).toEqual({ Internet: 7000 });
  });

  it("excludes income when building a salary-based allocation breakdown", () => {
    expect(ledgerItemBreakdown([
      transaction("income", "Salary", 500_000),
      transaction("fixed_expense", "Rent", 150_000),
      transaction("variable_expense", "Food", 50_000),
    ], { excludeIncome: true })).toEqual({ Rent: 150_000, Food: 50_000 });
  });
});
