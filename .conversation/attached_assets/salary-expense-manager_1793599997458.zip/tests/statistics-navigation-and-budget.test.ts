import { describe, expect, it } from "vitest";
import { parseBudgetThresholds } from "../lib/finance/budget-thresholds";
import { readStatisticsPeriod, statisticsTransactionsHref, swipeStatisticsCategory } from "../lib/finance/statistics-navigation";

describe("connected Statistics and budget thresholds", () => {
  it("cycles categories in either direction only after a deliberate horizontal swipe", () => {
    const categories = ["All", "Food", "Travel"];
    expect(swipeStatisticsCategory(categories, "All", -80)).toBe("Food");
    expect(swipeStatisticsCategory(categories, "Food", 80)).toBe("All");
    expect(swipeStatisticsCategory(categories, "Travel", -80)).toBe("All");
    expect(swipeStatisticsCategory(categories, "Food", 12)).toBeNull();
  });

  it("builds a Statistics-to-Transactions link with the selected ledger type, category, and period", () => {
    expect(statisticsTransactionsHref("fixed_expense", "Rent", "month")).toBe("/transaction-search?type=fixed_expense&statisticsPeriod=month&statisticsReadOnly=1&category=Rent");
    expect(readStatisticsPeriod("month")).toBe("month");
    expect(readStatisticsPeriod("invalid")).toBeUndefined();
  });

  it("accepts valid thresholds and rejects invalid or inverted threshold saves", () => {
    expect(parseBudgetThresholds("80", "100")).toEqual({ warning: 80, exceeded: 100 });
    expect(parseBudgetThresholds("120", "100")).toHaveProperty("error");
    expect(parseBudgetThresholds("80", "70")).toHaveProperty("error");
  });
});
