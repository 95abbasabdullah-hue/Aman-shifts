import { describe, expect, it } from "vitest";
import { pieSliceAngles, spendingPieSlices, spendingPieTotal } from "../lib/finance/statistics-pie";

describe("statistics spending pie chart", () => {
  it("calculates item percentages from salary while keeping unallocated salary visible in the chart", () => {
    const slices = spendingPieSlices({ Food: 5000, Travel: 3000, Shopping: 2000 }, 20_000);
    expect(slices.map((slice) => slice.category)).toEqual(["Food", "Travel", "Shopping"]);
    expect(slices[0]).toMatchObject({ startPercentage: 0, percentage: 25, chartPercentage: 25 });
    expect(slices[1]).toMatchObject({ startPercentage: 25, percentage: 15, chartPercentage: 15 });
    expect(Math.round(slices.reduce((total, slice) => total + slice.percentage, 0))).toBe(50);
  });

  it("excludes zero categories and totals local variable spending", () => {
    expect(spendingPieSlices({ Food: 0, Travel: 1234 }, 10_000)).toEqual([{ category: "Travel", amountMinor: 1234, percentage: 12.34, startPercentage: 0, chartPercentage: 12.34 }]);
    expect(spendingPieTotal({ Food: 0, Travel: 1234 })).toBe(1234);
  });

  it("turns each live spending share into a deterministic pie-slice angle", () => {
    expect(pieSliceAngles({ category: "Food", amountMinor: 2500, percentage: 25, startPercentage: 50, chartPercentage: 25 })).toEqual({ start: 90, end: 180, middle: 135 });
  });
});
