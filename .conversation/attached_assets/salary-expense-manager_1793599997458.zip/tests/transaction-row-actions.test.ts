import { describe, expect, it } from "vitest";
import { transactionDeletePrompt } from "../lib/finance/transaction-row-actions";
import type { FinanceTransaction } from "../lib/finance/types";

const baseTransaction: FinanceTransaction = {
  id: "txn-1", type: "variable_expense", amountMinor: 1200, currency: "QAR", category: "Food", date: "2026-08-27", description: "Lunch", createdAt: "2026-08-27T12:00:00.000Z", updatedAt: "2026-08-27T12:00:00.000Z",
};

describe("transaction row long-press delete prompts", () => {
  it("explains standard transaction deletion", () => {
    expect(transactionDeletePrompt(baseTransaction)).toContain("removes this transaction");
  });

  it("warns that a linked account transfer deletes both sides", () => {
    expect(transactionDeletePrompt({ ...baseTransaction, transferId: "transfer-1", type: "transfer_out" })).toContain("both linked sides");
  });
});
