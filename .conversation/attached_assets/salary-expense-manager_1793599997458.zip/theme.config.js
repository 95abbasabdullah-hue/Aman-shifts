/** @type {const} */
const themeColors = {
  primary: { light: '#956000', dark: '#956000' },
  accent: { light: '#F6C94C', dark: '#F2B93A' },
  accentSoft: { light: '#FFF2BF', dark: '#3E3011' },
  background: { light: '#FFFCF3', dark: '#1C1812' },
  surface: { light: '#FFF8E3', dark: '#282117' },
  foreground: { light: '#2B2418', dark: '#FFF8E8' },
  muted: { light: '#756B56', dark: '#C7BFAE' },
  border: { light: '#EFDDA5', dark: '#4A3C25' },
  success: { light: '#2E8B6E', dark: '#69C9A4' },
  warning: { light: '#AF7000', dark: '#F1BF5B' },
  error: { light: '#C55750', dark: '#F18C82' },
};

module.exports = { themeColors };
